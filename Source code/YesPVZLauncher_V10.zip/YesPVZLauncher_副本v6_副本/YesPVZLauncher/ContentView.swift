import SwiftUI

import AppKit

import Foundation

import UniformTypeIdentifiers

import Combine
import ImageIO
import ObjectiveC

// MARK: - 资源链接配置 (V8: 已更新为最新下载源)

enum ResourceLinkConfig {
    //远古代码，得供着～！[｜｜｜]三根香
    
    //static let gameEnOriginal = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/01%20Win%20%E7%B3%BB%E7%BB%9F%E8%8B%B1%E6%96%87%E5%8E%9F%E7%89%88/"

    //static let gameCnOriginal = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/02%20Win%20%E7%B3%BB%E7%BB%9F%E4%B8%AD%E6%96%87%E5%8E%9F%E7%89%88/"

    //static let pakPatch = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/12%20%E6%B8%B8%E6%88%8F%20PAK/"

    // 新加的3个占位链接（记得自己替换成真实网址）

    static let link1 = "https://space.bilibili.com/3546728525466305?spm_id_from=333.1007.0.0"

    static let link2 = "https://github.com/nuomi4/YesPVZlauncher/tree/main"

    static let link3 = "https://github.com/nuomi4/YesPVZlauncher/issues/new?template=bug_report.md"
    
    static let link4 = "https://afdian.com/a/nuomi12"

    // V8 更新：最新的 Whisky 4.5.105-beta.1 引擎下载链接

    static let wineDownloadSources: [URL] = [

        URL(string: "https://github.com/frankea/Whisky/releases/download/v4.5.105-beta.1/Libraries.tar.gz")!

    ]

}

// MARK: - 数据模型

struct GameInfo: Codable {

    let gameId: String

    let gameType: String

    let mainExeName: String

    var useSeparateBottle: Bool

    // V10 新增（可选，兼容旧 gameinfo.json）
    var trackedSavePath: String?      // 已定位到的 userdata 绝对路径
    var trackingStatus: String?       // "neverLaunched" / "pending" / "tracked" / "shared" / "ambiguous"
    var lastTrackingUpdate: TimeInterval?  // 最后一次追踪更新时间戳
}

struct ToolInfo: Codable {

    let toolId: String

    let toolName: String

    let toolRealPath: String

    var bindGameIds: [String]

    var note: String

}

// MARK: - 下载错误

enum WineDownloadError: LocalizedError {

    case alreadyDownloading, destinationMissing, incompleteFile, cancelled

    var errorDescription: String? {

        switch self {

        case .alreadyDownloading: return "已有下载任务正在进行"

        case .destinationMissing: return "下载目标路径为空"

        case .incompleteFile: return "下载文件不完整"

        case .cancelled: return "已取消下载"

        }

    }

}

// MARK: - 下载管理器

final class WineDownloader: NSObject, ObservableObject, URLSessionDownloadDelegate {

    @Published var progress: Double = 0

    @Published var isDownloading: Bool = false

    private var task: URLSessionDownloadTask?

    private var destination: URL?

    private var completion: ((Result<URL, Error>) -> Void)?

    private var session: URLSession?

    private var hasFinished = false

    func download(url: URL, to file: URL, completion: @escaping (Result<URL, Error>) -> Void) {

        guard !isDownloading else {

            completion(.failure(WineDownloadError.alreadyDownloading)); return

        }

        resetState()

        destination = file

        self.completion = completion

        let config = URLSessionConfiguration.default

        config.timeoutIntervalForRequest = 60

        config.timeoutIntervalForResource = 600

        config.requestCachePolicy = .reloadIgnoringLocalCacheData

        let session = URLSession(configuration: config, delegate: self, delegateQueue: .main)

        self.session = session

        task = session.downloadTask(with: url)

        task?.resume()

    }

    func cancel() {

        guard isDownloading else { return }

        task?.cancel()

        finish(.failure(WineDownloadError.cancelled))

    }

    private func resetState() {

        progress = 0; isDownloading = true; hasFinished = false

    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {

        guard totalBytesExpectedToWrite > 0 else { return }

        progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)

    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {

        guard let destination else {

            finish(.failure(WineDownloadError.destinationMissing)); return

        }

        do {

            let fm = FileManager.default

            if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }

            try fm.copyItem(at: location, to: destination)

            let attrs = try fm.attributesOfItem(atPath: destination.path)

            let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0

            guard size >= 30 * 1024 * 1024 else {

                try? fm.removeItem(at: destination)

                finish(.failure(WineDownloadError.incompleteFile)); return

            }

            finish(.success(destination))

        } catch {

            finish(.failure(error))

        }

    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {

        if let error, !hasFinished {

            finish(.failure(error))

        }

    }

    private func finish(_ result: Result<URL, Error>) {

        guard !hasFinished else { return }

        hasFinished = true

        isDownloading = false

        task = nil

        let callback = completion

        completion = nil

        destination = nil

        session?.finishTasksAndInvalidate()

        session = nil

        callback?(result)

    }

}

// MARK: - 玻璃质感圆形按钮

struct GlassActionButton: View {//汤圆

    let systemIcon: String

    let tintColor: Color

    let isEnabled: Bool

    let action: () -> Void

    var body: some View {

        Button(action: action) {

            ZStack {

                Circle().fill(Color.black.opacity(0.1)).offset(y: 1)

                Circle().fill(.regularMaterial).environment(\.colorScheme, .light)

                Circle().stroke(Color.white.opacity(0.8), lineWidth: 1.2)

                Circle().stroke(Color.black.opacity(0.05), lineWidth: 1).padding(1.5)

                Image(systemName: systemIcon)

                    .font(.system(size: 15, weight: .medium))

                    .foregroundColor(isEnabled ? tintColor : Color.gray.opacity(0.4))

            }

            .frame(width: 34, height: 34)

        }

        .buttonStyle(.plain)

        .disabled(!isEnabled)

    }

}

// MARK: - Wine 引擎资源

private struct WineEngineResources {

    let wine: URL

    let server: URL

    let libraryPath: URL

}

// MARK: - 主界面 (V9.1.1：图片查看器 / 图片缓存 / 存档导出兜底)

struct ContentView: View {

    @State private var statusText = ""

    @State private var selectedTab = 0

    @State private var gameList: [String] = []

    @State private var selectedGameEntry: String?

    @State private var toolList: [ToolInfo] = []

    @State private var selectedToolId: String?

    @State private var wineReady = false

    @StateObject private var downloader = WineDownloader()

    @State private var runningProcesses: [String: Process] = [:]   // key = gameId
    
    @State private var caffeinateProcesses: [String: Process] = [:]  // key = gameId
    @State private var showHelp = false

    @State private var showAppDetail = false

    @State private var selectedGame: GameItem? = nil

    @State private var resetID = UUID()

    @StateObject private var sharedLibrary = RemoteGameLibrary()
    
    // 是否接收预发布版（测试版）更新
    @AppStorage("includePrerelease") private var includePrerelease = false

    // V8 恢复偏好设置：新游戏默认独立 Bottle

    @AppStorage("wine64Path") private var wine64Path: String = ""

    @AppStorage("defaultSeparateBottle") private var defaultSeparateBottle = false

    @AppStorage("wineDebug") private var wineDebug = false

    // V8 防冻结与老游戏兼容设置：保留 Caffeinate 和 OpenGL 强制渲染

    @AppStorage("enableKeepAlive") private var enableKeepAlive = true

    @AppStorage("forceOpenGLRender") private var forceOpenGLRender = false

    private var appSupport: URL {

        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!

            .appendingPathComponent("YesPVZLauncher")

    }

    private var globalBottle: URL { appSupport.appendingPathComponent("GlobalBottle") }

    private var wineFolder: URL { appSupport.appendingPathComponent("WineEngine") }

    private var toolsDir: URL { appSupport.appendingPathComponent("GameLibrary/Tools") }

    private var hasRunningWineProcess: Bool {

        runningProcesses.values.contains(where: { $0.isRunning })

    }

    // MARK: - 咖啡因保活

    private func startCaffeinate(for process: Process, id: String) {

        guard enableKeepAlive, process.isRunning else { return }

        let keepAlive = Process()

        keepAlive.executableURL = URL(fileURLWithPath: "/usr/bin/caffeinate")

        keepAlive.arguments = ["-dimsu", "-w", String(process.processIdentifier)]

        do {

            try keepAlive.run()

            caffeinateProcesses[id] = keepAlive

            if wineDebug { appendStatus("☕咖啡因保活已启动（跟随 PID \(process.processIdentifier)）") }

        } catch {

            if wineDebug { appendStatus("⚠️咖啡因保活启动失败: \(error.localizedDescription)") }

        }

    }

    private func stopCaffeinate(id: String) {
        guard let keepAlive = caffeinateProcesses.removeValue(forKey: id) else { return }

        if keepAlive.isRunning { keepAlive.terminate() }

    }

    private func stopAllCaffeinate() {

        for process in caffeinateProcesses.values where process.isRunning { process.terminate() }

        caffeinateProcesses.removeAll()

    }

    // MARK: - 通用工具

    private let maxVisibleLogCharacters = 30_000

    private func appendStatus(_ text: String) {

        statusText = statusText.isEmpty ? text : statusText + "\n\(text)"

        if statusText.count > maxVisibleLogCharacters {

            statusText = "…前面的日志已截断…\n" + String(statusText.suffix(maxVisibleLogCharacters))

        }

    }

    private func appendWineLogToUI(_ text: String) {

        guard !text.isEmpty else { return }

        statusText += text

        if statusText.count > maxVisibleLogCharacters {

            statusText = "…前面的 Wine 日志已截断…\n" + String(statusText.suffix(maxVisibleLogCharacters))

        }

    }

    private func openExactResourceLink(_ raw: String) {

        guard !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {

            statusText = "❌链接为空"; return

        }

        let process = Process()

        process.executableURL = URL(fileURLWithPath: "/usr/bin/open")

        process.arguments = [raw]

        do {

            try process.run()

            if wineDebug { statusText = "🔗原始链接已直接交给系统:\n\(raw)" }

        } catch {

            statusText = "❌打开链接失败: \(error.localizedDescription)"

        }

    }
    
    // MARK: - 版本号比较工具
    private func parseVersion(_ tag: String) -> [Int] {
        let cleaned = tag.lowercased()
            .replacingOccurrences(of: "v", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.split(separator: ".")
            .compactMap { part in
                Int(part.prefix(while: { $0.isNumber }))
            }
    }

    private func compareVersion(_ a: [Int], _ b: [Int]) -> ComparisonResult {
        let maxLen = max(a.count, b.count)
        for i in 0..<maxLen {
            let av = i < a.count ? a[i] : 0
            let bv = i < b.count ? b[i] : 0
            if av > bv { return .orderedDescending }
            if av < bv { return .orderedAscending }
        }
        return .orderedSame
    }

    // MARK: - 检查更新
    private func checkForUpdates() {
        statusText = "⏳ 正在检查更新..."
        // 从 App Bundle 读版本号（对应 Xcode 里的 Marketing Version）
        let currentVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.0.0"
        // 从 App Bundle 读 Build 号（对应 Xcode 里的 Current Project Version）
        let currentBuild = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0"
        let currentParsed = parseVersion(currentVersion)
        statusText = "⏳ 正在检查更新... 当前版本 \(currentVersion) (\(currentBuild))"

        let apiURL = URL(string: "https://api.github.com/repos/nuomi4/YesPVZlauncher/releases")!

        var request = URLRequest(url: apiURL)
        request.timeoutInterval = 10
        request.setValue("YesPVZLauncher", forHTTPHeaderField: "User-Agent")

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                if let error {
                    statusText = "❌ 检查更新失败：\(error.localizedDescription)"
                    return
                }
                guard let data,
                      let rawReleases = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
                    statusText = "❌ 无法解析 Release 数据"
                    return
                }

                // 1) 过滤 draft；prerelease 根据用户开关决定是否保留
                let validReleases = rawReleases.filter { r in
                    let isDraft = r["draft"] as? Bool ?? false
                    guard !isDraft else { return false }

                    let isPrerelease = r["prerelease"] as? Bool ?? false
                    if isPrerelease && !includePrerelease {
                        // 用户不要预发布版 → 过滤掉
                        return false
                    }
                    return true
                }

                guard !validReleases.isEmpty else {
                    statusText = "❌ 没有找到任何正式版本"
                    return
                }

                // 2) 解析出每个 release 的信息
                struct ReleaseInfo {
                    let tag: String
                    let url: String
                    let body: String
                    let publishedAt: String
                    let version: [Int]
                    let isPrerelease: Bool
                }
                let infos: [ReleaseInfo] = validReleases.compactMap { r in
                    let tag = (r["tag_name"] as? String)
                        ?? (r["name"] as? String)
                        ?? ""
                    guard !tag.isEmpty else { return nil }
                    let url = (r["html_url"] as? String) ?? ResourceLinkConfig.link2
                    let body = (r["body"] as? String) ?? "（该版本没有填写更新说明）"
                    let publishedAt = (r["published_at"] as? String) ?? ""
                    let isPrerelease = r["prerelease"] as? Bool ?? false
                    let ver = parseVersion(tag)
                    guard !ver.isEmpty else { return nil }
                    return ReleaseInfo(
                        tag: tag,
                        url: url,
                        body: body,
                        publishedAt: publishedAt,
                        version: ver,
                        isPrerelease: isPrerelease
                    )
                }

                guard !infos.isEmpty else {
                    statusText = "❌ 所有 Release 版本号都无法解析"
                    return
                }

                // 给版本号加"正式版/测试版"前缀，用于弹窗展示
                func displayTag(_ info: ReleaseInfo) -> String {
                    return info.isPrerelease ? "\(info.tag)（测试版）" : "\(info.tag)（正式版）"
                }

                // 3) 按版本号从新到旧排
                let sorted = infos.sorted { compareVersion($0.version, $1.version) == .orderedDescending }
                let latestOfficial = sorted[0]

                // 4) 筛出「比当前版本新」的
                let newer = sorted.filter { compareVersion($0.version, currentParsed) == .orderedDescending }

                // ========================
                // 情况 A：当前版本 >= 最新正式版
                // ========================
                if newer.isEmpty {
                    let isAheadOfLatest = compareVersion(currentParsed, latestOfficial.version) == .orderedDescending

                    let alert = NSAlert()
                    alert.messageText = "检查更新"

                    if isAheadOfLatest {
                        // A1：当前版本比最新正式版还高 → 提示测试版
                        alert.informativeText = """
                        你当前使用的版本：\(currentVersion)
                        GitHub 最新版本：\(displayTag(latestOfficial))

                        ⚠️ 你用的版本比 GitHub 上最新版本还高。

                        这通常是以下情况之一：
                        · 你使用的是【测试版 / 内部版】
                        · 该版本还没正式发布到 GitHub
                        · GitHub 上的版本还没更新到你这个版本

                        💡 如果你是普通用户，建议查看 GitHub 上最新版本：\(displayTag(latestOfficial))
                        """
                        alert.addButton(withTitle: "查看 \(latestOfficial.tag)")
                        alert.addButton(withTitle: "知道了")
                        let response = alert.runModal()
                        if response == .alertFirstButtonReturn {
                            showReleaseDetail(
                                title: displayTag(latestOfficial),
                                body: latestOfficial.body,
                                url: latestOfficial.url
                            )
                        }
                    } else {
                        // A2：当前版本 == 最新版本
                        alert.informativeText = """
                        当前已是最新版本：\(displayTag(latestOfficial))

                        如果想看看当前版本的更新说明，可以点「查看更新日志」。
                        """
                        alert.addButton(withTitle: "查看更新日志")
                        alert.addButton(withTitle: "确定")
                        let response = alert.runModal()
                        if response == .alertFirstButtonReturn {
                            showReleaseDetail(
                                title: displayTag(latestOfficial),
                                body: latestOfficial.body,
                                url: latestOfficial.url
                            )
                        }
                    }

                    statusText = "✅ 检查更新完成"
                    return
                }

                // ========================
                // 情况 B：有比当前更新的版本
                // ========================

                // B1：只有一个可选
                if newer.count == 1 {
                    let only = newer[0]

                    let alert = NSAlert()
                    alert.messageText = "发现新版本"
                    alert.informativeText = """
                    当前版本：\(currentVersion)
                    可更新到：\(displayTag(only))
                    """
                    alert.addButton(withTitle: "查看更新内容")
                    alert.addButton(withTitle: "稍后")
                    let response = alert.runModal()
                    if response == .alertFirstButtonReturn {
                        showReleaseDetail(title: displayTag(only), body: only.body, url: only.url)
                    } else {
                        statusText = "ℹ️ 已取消更新"
                    }
                    return
                }

                // B2：多个可选 → 让用户选
                let latest = newer[0]              // 版本号最高的
                let next = newer[newer.count - 1]  // 比当前新的里版本号最低的

                let alert = NSAlert()
                alert.messageText = "检查更新"
                alert.informativeText = """
                当前版本：\(currentVersion)

                可选更新目标：
                · 更新到最新版：\(displayTag(latest))
                · 更新到下一版本：\(displayTag(next))（最小跨度升级）
                """
                alert.addButton(withTitle: "更新到最新版")
                alert.addButton(withTitle: "更新到下一版本")
                alert.addButton(withTitle: "稍后")

                let response = alert.runModal()
                switch response {
                case .alertFirstButtonReturn:
                    showReleaseDetail(title: displayTag(latest), body: latest.body, url: latest.url)
                case .alertSecondButtonReturn:
                    showReleaseDetail(title: displayTag(next), body: next.body, url: next.url)
                default:
                    statusText = "ℹ️ 已取消更新"
                }
            }
        }.resume()
    }

    // MARK: - 显示更新日志弹窗
    private func showReleaseDetail(title: String, body: String, url: String) {
        // NSAlert 的 informativeText 长度有限，太长会显示不下，
        // 所以这里做一个保护：超过 2000 字符就截断，提示去 GitHub 看完整。
        let maxBodyLength = 2000
        let displayBody: String
        if body.count > maxBodyLength {
            displayBody = String(body.prefix(maxBodyLength))
                + "\n\n…（更新说明过长，已截断。点「前往下载」查看完整说明）"
        } else {
            displayBody = body
        }

        let alert = NSAlert()
        alert.messageText = "更新到 \(title)"
        alert.informativeText = """
        ───────── 更新内容 ─────────

        \(displayBody)

        ─────────────────────────────
        """
        alert.addButton(withTitle: "前往下载")
        alert.addButton(withTitle: "取消")
        let response = alert.runModal()
        if response == .alertFirstButtonReturn {
            openExactResourceLink(url)
            statusText = "🔗 已打开 \(title) 下载页"
        } else {
            statusText = "ℹ️ 已取消更新"
        }
    }

    private func runSystemProcess(executable: String, arguments: [String], wait: Bool = true) -> Int32? {

        let process = Process()

        process.executableURL = URL(fileURLWithPath: executable)

        process.arguments = arguments

        do {

            try process.run()

            if wait { process.waitUntilExit(); return process.terminationStatus }

            return 0

        } catch { return nil }

    }

    private func removeQuarantine(in url: URL) {

        guard FileManager.default.fileExists(atPath: url.path) else { return }

        _ = runSystemProcess(executable: "/usr/bin/xattr", arguments: ["-cr", url.path])

    }

    private func ensureExecutablePermissions(in url: URL) {

        guard FileManager.default.fileExists(atPath: url.path) else { return }

        _ = runSystemProcess(executable: "/bin/chmod", arguments: ["-R", "755", url.path])

    }

    private func getBottle(_ game: GameInfo, storage: URL) -> URL {
        game.useSeparateBottle ? storage.appendingPathComponent("GameBottle") : globalBottle
    }



    // MARK: - 存档导入导出

    private func resolveGameExePath(for game: GameInfo, storage: URL) -> URL? {

        guard let realFolder = resolveSymlink(storage) else { return nil }

        let exe = realFolder.appendingPathComponent(game.mainExeName)

        guard FileManager.default.fileExists(atPath: exe.path) else { return nil }

        return exe

    }

    private func findUserdataPath(for game: GameInfo, storage: URL) -> URL? {

        let fm = FileManager.default

        let bottle = getBottle(game, storage: storage)

        let driveC = bottle.appendingPathComponent("drive_c")

        guard let exePath = resolveGameExePath(for: game, storage: storage) else {

            return nil

        }

        // 1. 游戏主程序目录下的 userdata（最优先）

        let primaryPath = exePath.deletingLastPathComponent().appendingPathComponent("userdata")

        if fm.fileExists(atPath: primaryPath.path) {

            return primaryPath

        }

        // 2. Windows Vista+ 路径

        let programData = driveC.appendingPathComponent("ProgramData")

        let vistaPath = programData

            .appendingPathComponent("PopCap Games")

            .appendingPathComponent("PlantsVsZombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: vistaPath.path) {

            return vistaPath

        }

        // 3. Steam 本地路径

        let steamPath = programData

            .appendingPathComponent("Steam")

            .appendingPathComponent("PlantsVsZombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: steamPath.path) {

            return steamPath

        }

        // 4. Zoo 日文版路径

        let zooPath = programData

            .appendingPathComponent("Zoo")

            .appendingPathComponent("Plants vs Zombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: zooPath.path) {

            return zooPath

        }

        return nil

    }

    // V9.1.3：仅用于“导出存档”的智能路径搜索。
    // 重要：明确区分“软链接导入”和“复制导入”，同时再区分独立 Bottle / 全局 Bottle。
    // 导入存档逻辑仍保持 V9 原样，不使用这里的全盘扫描。

    private func isGameStorageSymbolicLink(_ storage: URL) -> Bool {
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: storage.path) else {
            return false
        }
        return attrs[.type] as? FileAttributeType == .typeSymbolicLink
    }

    private func firstExistingUserdataDirectory(in parent: URL) -> URL? {
        let fm = FileManager.default

        // 兼容大小写不同的改版：userdata / UserData / USERDATA。
        let names = ["userdata", "UserData", "USERDATA"]
        for name in names {
            let candidate = parent.appendingPathComponent(name)
            var isDirectory: ObjCBool = false
            if fm.fileExists(atPath: candidate.path, isDirectory: &isDirectory),
               isDirectory.boolValue {
                return candidate
            }
        }

        // 对大小写敏感磁盘再做一次目录枚举匹配。
        guard let children = try? fm.contentsOfDirectory(
            at: parent,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }

        for child in children {
            guard child.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }
            let values = try? child.resourceValues(forKeys: [.isDirectoryKey])
            if values?.isDirectory == true {
                return child
            }
        }

        return nil
    }

    private func knownUserdataPathInsideBottle(_ bottle: URL) -> URL? {
        let fm = FileManager.default
        let driveC = bottle.appendingPathComponent("drive_c")

        var driveCIsDirectory: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &driveCIsDirectory),
              driveCIsDirectory.boolValue else {
            return nil
        }

        // 已知常见位置仍然优先，避免每次都遍历整个 C 盘。
        let parentCandidates: [URL] = [
            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("PopCap Games")
                .appendingPathComponent("PlantsVsZombies"),

            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("Steam")
                .appendingPathComponent("PlantsVsZombies"),

            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("Zoo")
                .appendingPathComponent("Plants vs Zombies")
        ]

        for parent in parentCandidates {
            if let userdata = firstExistingUserdataDirectory(in: parent) {
                return userdata
            }
        }

        return nil
    }

    private func scanDriveCForUserdata(_ driveC: URL) -> URL? {
        let fm = FileManager.default

        var driveCIsDirectory: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &driveCIsDirectory),
              driveCIsDirectory.boolValue else {
            return nil
        }

        guard let enumerator = fm.enumerator(
            at: driveC,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles],
            errorHandler: { _, _ in true }
        ) else {
            return nil
        }

        var candidates: [(url: URL, score: Int)] = []

        for case let url as URL in enumerator {
            guard url.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }

            let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values?.isDirectory == true,
                  values?.isSymbolicLink != true else {
                continue
            }

            var score = 0
            let path = url.path.lowercased()

            // PVZ / PopCap 相关路径优先。
            if path.contains("plants") { score += 120 }
            if path.contains("zombie") { score += 120 }
            if path.contains("popcap") { score += 80 }
            if path.contains("programdata") { score += 30 }
            if path.contains("steam") { score += 20 }
            if path.contains("zoo") { score += 10 }

            // 存档内容特征加权，避免误选其他 Windows 软件的 userdata。
            if let children = try? fm.contentsOfDirectory(
                at: url,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
            ) {
                let lowerNames = children.map { $0.lastPathComponent.lowercased() }
                if lowerNames.contains(where: { $0.hasSuffix(".dat") }) { score += 60 }
                if lowerNames.contains(where: { $0.contains("user") }) { score += 25 }
                if lowerNames.contains(where: { $0.contains("game") }) { score += 20 }
            }

            candidates.append((url, score))
            enumerator.skipDescendants()
        }

        return candidates.max(by: { $0.score < $1.score })?.url
    }

    private func findUserdataPathForExport(for game: GameInfo, storage: URL) -> URL? {
        let fm = FileManager.default
        let isSymlinkImport = isGameStorageSymbolicLink(storage)
        let bottle = getBottle(game, storage: storage)
        let driveC = bottle.appendingPathComponent("drive_c")

        // ─────────────────────────────────────────────
        // A. 软链接导入
        // storage 只是启动器里的链接；真正游戏本体由软链接目标决定。
        // 所以先直接检查“真实游戏本体/userdata”。
        // ─────────────────────────────────────────────
        if isSymlinkImport {
            if let realGameFolder = resolveSymlink(storage),
               fm.fileExists(atPath: realGameFolder.path),
               let userdata = firstExistingUserdataDirectory(in: realGameFolder) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，命中游戏本体 userdata")
                }
                return userdata
            }

            // 游戏本体没找到，再查这个游戏实际使用的 Bottle。
            if let known = knownUserdataPathInsideBottle(bottle) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，命中 Bottle 已知路径")
                }
                return known
            }

            if let scanned = scanDriveCForUserdata(driveC) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，C 盘全盘扫描命中 userdata")
                }
                return scanned
            }

            return nil
        }

        // ─────────────────────────────────────────────
        // B. 复制导入
        // storage 是启动器内部保存的实体副本，不把它当成外部“原始游戏本体”去追踪。
        // 按用户实际运行环境，优先查它真正使用的 GameBottle / GlobalBottle。
        // ─────────────────────────────────────────────

        // useSeparateBottle == true  → storage/GameBottle/drive_c
        // useSeparateBottle == false → Application Support/YesPVZLauncher/GlobalBottle/drive_c
        if let known = knownUserdataPathInsideBottle(bottle) {
            if wineDebug {
                let mode = game.useSeparateBottle ? "GameBottle" : "GlobalBottle"
                appendStatus("💾存档导出：复制模式，命中 \(mode) 已知路径")
            }
            return known
        }

        // 固定位置没有，再扫描“这个复制游戏真正使用的 C 盘”。
        if let scanned = scanDriveCForUserdata(driveC) {
            if wineDebug {
                let mode = game.useSeparateBottle ? "GameBottle" : "GlobalBottle"
                appendStatus("💾存档导出：复制模式，\(mode) C 盘全盘扫描命中 userdata")
            }
            return scanned
        }

        return nil
    }

    private func selectGamesFromList(title: String, message: String) -> [String] {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.addButton(withTitle: "确认")
        alert.addButton(withTitle: "取消")

        // 外层容器：全选 + 列表
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 280))

        // 全选复选框
        let selectAllCheckbox = NSButton(checkboxWithTitle: "全选", target: nil, action: nil)
        selectAllCheckbox.state = .off
        selectAllCheckbox.frame = NSRect(x: 8, y: 256, width: 360, height: 20)
        container.addSubview(selectAllCheckbox)

        // 列表
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.frame = NSRect(x: 0, y: 0, width: 380, height: 248)

        let tableView = NSTableView()
        tableView.headerView = nil
        tableView.rowHeight = 24
        tableView.allowsMultipleSelection = false
        tableView.selectionHighlightStyle = .none

        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("game"))
        column.width = 360
        tableView.addTableColumn(column)

        let dataSource = GameCheckboxDataSource(entries: gameList)
        dataSource.tableView = tableView
        tableView.dataSource = dataSource
        tableView.delegate = dataSource

        scroll.documentView = tableView
        container.addSubview(scroll)

        alert.accessoryView = container

        dataSource.selectAllCheckbox = selectAllCheckbox
        selectAllCheckbox.target = dataSource
        selectAllCheckbox.action = #selector(GameCheckboxDataSource.selectAllToggled(_:))

        objc_setAssociatedObject(alert, AssociatedKeys.gameCheckboxDataSource, dataSource, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)

        guard alert.runModal() == .alertFirstButtonReturn else { return [] }
        return dataSource.selectedEntries
    }

    // MARK: 导出存档（V10：基于追踪结果）

    private func exportSaveData() {
        let selected = selectGamesFromList(title: "选择要导出的游戏", message: "请选择要导出存档的游戏（可多选）")
        guard !selected.isEmpty else { return }

        struct ExportPlan {
            let entry: String
            let storage: URL
            let game: GameInfo
            let status: SaveTrackingStatus
            let path: String?
        }
        var plans: [ExportPlan] = []

        for entry in selected {
            guard let storage = gameStorage(entry),
                  let game = loadGameInfo(storage) else {
                continue
            }
            let status = SaveTrackingStatus(rawValue: game.trackingStatus ?? "") ?? .neverLaunched
            plans.append(ExportPlan(entry: entry, storage: storage, game: game, status: status, path: game.trackedSavePath))
        }

        // ─────────────────────────────────────────────
        // 兜底：追踪路径失效 / pending → 用旧的智能扫描找路径
        // ─────────────────────────────────────────────
        var effectiveTracked: [ExportPlan] = []
        var stillPending: [String] = []
        var resolvedByFallback: [String] = []
        var sharedByFallback: [String] = []
        let fm = FileManager.default

        for plan in plans {
            // 1) tracked 且路径有效 → 直接用
            if plan.status == .tracked,
               let p = plan.path, !p.isEmpty,
               fm.fileExists(atPath: p) {
                effectiveTracked.append(plan)
                continue
            }

            // ⭐️ 记下：tracked 但路径已失效
            let trackedButPathDead = (plan.status == .tracked)

            // 2) shared → 不导出
            if plan.status == .shared { continue }

            // 3) 兜底扫描
            guard let fallbackURL = findUserdataPathForExport(for: plan.game, storage: plan.storage) else {
                // ⭐️ 兜底也失败 → 如果是失效的 tracked，改回 pending
                if trackedButPathDead,
                   let storage = gameStorage(plan.entry),
                   var g = loadGameInfo(storage) {
                    g.trackingStatus = SaveTrackingStatus.pending.rawValue
                    g.lastTrackingUpdate = Date().timeIntervalSince1970
                    saveGameInfo(storage, g)
                    appendStatus("⚠️ \(plan.entry) 的追踪路径已失效，状态已重置为「待定位」")
                }
                stillPending.append(plan.entry)
                continue
            }

            var conflict: String? = nil
            for other in gameList where other != plan.entry {
                guard let s = gameStorage(other), let g2 = loadGameInfo(s) else { continue }
                if g2.trackedSavePath == fallbackURL.path {
                    conflict = other
                    break
                }
            }

            if let storage = gameStorage(plan.entry), var g = loadGameInfo(storage) {
                g.trackedSavePath = fallbackURL.path
                if conflict != nil {
                    g.trackingStatus = SaveTrackingStatus.shared.rawValue
                } else {
                    g.trackingStatus = SaveTrackingStatus.tracked.rawValue
                }
                g.lastTrackingUpdate = Date().timeIntervalSince1970
                saveGameInfo(storage, g)

                if conflict != nil {
                    sharedByFallback.append(plan.entry)
                } else {
                    resolvedByFallback.append(plan.entry)
                    effectiveTracked.append(ExportPlan(
                        entry: plan.entry, storage: storage, game: g,
                        status: .tracked, path: fallbackURL.path
                    ))
                }
            }
        }

        let sharedPlans = plans.filter { $0.status == .shared }.map { $0.entry } + sharedByFallback
        let pendingPlans = stillPending

        if effectiveTracked.isEmpty {
            showExportResultAlert(
                success: 0, shared: sharedPlans, notTracked: pendingPlans,
                targetDirName: nil, failedCopy: []
            )
            return
        }

        let panel = NSOpenPanel()
        panel.title = "选择导出位置"
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.message = "选择存档导出的目标文件夹"
        guard panel.runModal() == .OK, let targetDir = panel.url else {
            statusText = "❌未选择导出位置"
            return
        }

        var successCount = 0
        var failedCopy: [String] = []

        for plan in effectiveTracked {
            guard let pathStr = plan.path else { continue }
            let userdataPath = URL(fileURLWithPath: pathStr)
            guard fm.fileExists(atPath: userdataPath.path) else {
                failedCopy.append(plan.entry)
                continue
            }
            let folderName = plan.storage.lastPathComponent + "_存档"
            let destFolder = targetDir.appendingPathComponent(folderName)
            do {
                if fm.fileExists(atPath: destFolder.path) {
                    try fm.removeItem(at: destFolder)
                }
                try fm.createDirectory(at: destFolder, withIntermediateDirectories: true)
                let destUserdata = destFolder.appendingPathComponent("userdata")
                try fm.copyItem(at: userdataPath, to: destUserdata)
                successCount += 1
            } catch {
                if fm.fileExists(atPath: destFolder.path) {
                    try? fm.removeItem(at: destFolder)
                }
                failedCopy.append(plan.entry)
                if wineDebug {
                    appendStatus("❌导出 \(plan.entry) 失败: \(error.localizedDescription)")
                }
            }
        }

        showExportResultAlert(
            success: successCount, shared: sharedPlans, notTracked: pendingPlans,
            targetDirName: targetDir.lastPathComponent, failedCopy: failedCopy
        )

        if !resolvedByFallback.isEmpty {
            appendStatus("🛟 兜底扫描命中 \(resolvedByFallback.count) 个：\(resolvedByFallback.joined(separator: "、"))")
        }
        if !sharedByFallback.isEmpty {
            appendStatus("🔗 兜底扫描发现共用：\(sharedByFallback.joined(separator: "、"))")
        }
    }

    /// 导出结果弹窗
    private func showExportResultAlert(
        success: Int,
        shared: [String],
        notTracked: [String],
        targetDirName: String?,
        failedCopy: [String]
    ) {
        var lines: [String] = []

        if success > 0, let dir = targetDirName {
            lines.append("✅ 成功导出 \(success) 个存档到 \(dir)")
        }

        if !failedCopy.isEmpty {
            lines.append("")
            lines.append("⚠️ 复制失败（可能路径失效或磁盘满）：")
            lines.append(contentsOf: failedCopy.map { "  • \($0)" })
        }

        if !notTracked.isEmpty {
            lines.append("")
            lines.append("📭 尚未识别存档位置（请先启动一次游戏让启动器记录）：")
            lines.append(contentsOf: notTracked.map { "  • \($0)" })
        }

        if !shared.isEmpty {
            lines.append("")
            lines.append("🔗 与其他游戏共用存档，无法区分：")
            lines.append(contentsOf: shared.map { "  • \($0)" })
            lines.append("")
            lines.append("说明：这些游戏物理上共享同一个 userdata 目录，导出会连带其他游戏存档。")
        }

        if lines.isEmpty {
            lines.append("❌ 没有可导出的内容。")
        }

        statusText = lines.joined(separator: "\n")

        let alert = NSAlert()
        alert.messageText = success > 0 ? "导出完成" : "无法导出"
        alert.informativeText = lines.joined(separator: "\n")
        alert.addButton(withTitle: "确定")
        alert.runModal()
    }
    // MARK: 导入存档

    // MARK: 导入存档（V10：优先用追踪路径）

    private func importSaveData() {
        if hasRunningWineProcess {
            let alert = NSAlert()
            alert.messageText = "游戏正在运行"
            alert.informativeText = "检测到有游戏正在运行，请先关闭游戏再导入存档，否则会导致导入失败。"
            alert.addButton(withTitle: "确定")
            alert.runModal()
            return
        }

        let panel = NSOpenPanel()
        panel.title = "选择要导入的存档文件夹"
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.message = "请选择之前导出的存档文件夹（格式：xxx_存档）"
        guard panel.runModal() == .OK, let sourceFolder = panel.url else {
            statusText = "❌未选择存档"
            return
        }

        let sourceUserdata = sourceFolder.appendingPathComponent("userdata")
        guard FileManager.default.fileExists(atPath: sourceUserdata.path) else {
            statusText = "❌所选文件夹不包含 userdata，不是有效的存档"
            return
        }

        let selected = selectGamesFromList(title: "选择要导入的游戏", message: "请选择要导入存档的游戏（可多选）")
        guard !selected.isEmpty else { return }

        let fm = FileManager.default
        var successCount = 0
        var failedEntries: [String] = []
        var notTrackedEntries: [String] = []
        var fallbackEntries: [String] = []

        for entry in selected {
            guard let storage = gameStorage(entry),
                  let game = loadGameInfo(storage) else {
                failedEntries.append(entry)
                continue
            }

            // ─────────────────────────────────────────────
            // 目标路径优先级：
            // 1) trackedSavePath 有效 → 用它
            // 2) 无效 → findUserdataPathForExport（全盘扫描兜底）
            // 3) 都找不到 → findUserdataPath（固定路径猜测）
            // ─────────────────────────────────────────────
            var targetUserdata: URL? = nil
            var usedFallback = false

            if let trackedPath = game.trackedSavePath, !trackedPath.isEmpty {
                let u = URL(fileURLWithPath: trackedPath)
                if fm.fileExists(atPath: u.deletingLastPathComponent().path) {
                    targetUserdata = u
                }
            }

            if targetUserdata == nil,
               let scanned = findUserdataPathForExport(for: game, storage: storage) {
                targetUserdata = scanned
                usedFallback = true
            }

            if targetUserdata == nil {
                targetUserdata = findUserdataPath(for: game, storage: storage)
                if targetUserdata != nil { usedFallback = true }
            }

            guard let target = targetUserdata else {
                notTrackedEntries.append(entry)
                continue
            }

            // 覆盖确认
            if fm.fileExists(atPath: target.path) {
                let alert = NSAlert()
                alert.messageText = "覆盖确认"
                alert.informativeText = "游戏「\(entry)」的存档已存在，是否覆盖？"
                alert.addButton(withTitle: "覆盖")
                alert.addButton(withTitle: "跳过")
                guard alert.runModal() == .alertFirstButtonReturn else { continue }

                do {
                    try fm.removeItem(at: target)
                } catch {
                    appendStatus("❌删除旧存档失败: \(error.localizedDescription)")
                    failedEntries.append(entry)
                    continue
                }
            }

            // 确保父目录存在
            do {
                try fm.createDirectory(
                    at: target.deletingLastPathComponent(),
                    withIntermediateDirectories: true
                )
            } catch {
                failedEntries.append(entry)
                continue
            }

            // 拷贝
            do {
                try fm.copyItem(at: sourceUserdata, to: target)
                successCount += 1

                // 兜底命中 → 写回 gameInfo
                if usedFallback,
                   let s = gameStorage(entry), var g = loadGameInfo(s) {
                    g.trackedSavePath = target.path
                    if g.trackingStatus != SaveTrackingStatus.tracked.rawValue
                        && g.trackingStatus != SaveTrackingStatus.shared.rawValue {
                        g.trackingStatus = SaveTrackingStatus.tracked.rawValue
                    }
                    g.lastTrackingUpdate = Date().timeIntervalSince1970
                    saveGameInfo(s, g)
                    fallbackEntries.append(entry)
                }
            } catch {
                appendStatus("❌导入 \(entry) 失败: \(error.localizedDescription)")
                failedEntries.append(entry)
            }
        }

        // 汇总弹窗
        var lines: [String] = []
        if successCount > 0 {
            lines.append("✅ 成功导入 \(successCount) 个存档")
        }
        if !fallbackEntries.isEmpty {
            lines.append("🛟 其中 \(fallbackEntries.count) 个通过兜底扫描定位：\(fallbackEntries.joined(separator: "、"))")
        }
        if !failedEntries.isEmpty {
            lines.append("⚠️ \(failedEntries.count) 个游戏导入失败：")
            lines.append(contentsOf: failedEntries.map { "  • \($0)" })
        }
        if !notTrackedEntries.isEmpty {
            lines.append("📭 \(notTrackedEntries.count) 个游戏未找到目标路径：")
            lines.append(contentsOf: notTrackedEntries.map { "  • \($0)" })
            lines.append("（请先启动一次游戏，让启动器记录存档位置）")
        }
        if lines.isEmpty {
            lines.append("❌ 没有导入任何内容。")
        }

        statusText = lines.joined(separator: "\n")

        let alert = NSAlert()
        alert.messageText = successCount > 0 ? "导入完成" : "导入失败"
        alert.informativeText = lines.joined(separator: "\n")
        alert.addButton(withTitle: "确定")
        alert.runModal()
    }

//本来这里有一堆换行很空

    // MARK: - JSON 数据

    private func loadGameInfo(_ url: URL) -> GameInfo? {

        let file = url.appendingPathComponent("gameinfo.json")

        guard FileManager.default.fileExists(atPath: file.path) else { return nil }

        do { return try JSONDecoder().decode(GameInfo.self, from: Data(contentsOf: file)) }

        catch { statusText = "⚠️读取配置失败: \(error.localizedDescription)"; return nil }

    }

    private func saveGameInfo(_ url: URL, _ info: GameInfo) {

        do { try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true); try JSONEncoder().encode(info).write(to: url.appendingPathComponent("gameinfo.json"), options: .atomic) }

        catch { statusText = "⚠️写入失败: \(error.localizedDescription)" }

    }

    private func saveTool(_ tool: ToolInfo) {

        do { try FileManager.default.createDirectory(at: toolsDir, withIntermediateDirectories: true); try JSONEncoder().encode(tool).write(to: toolsDir.appendingPathComponent("\(tool.toolId).json"), options: .atomic) }

        catch { statusText = "⚠️保存工具失败: \(error.localizedDescription)" }

    }

    private func loadTools() {

        toolList.removeAll()

        guard FileManager.default.fileExists(atPath: toolsDir.path) else { return }

        do {

            let files = try FileManager.default.contentsOfDirectory(at: toolsDir, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

            var loaded: [ToolInfo] = []

            for file in files where file.pathExtension.lowercased() == "json" {

                do { loaded.append(try JSONDecoder().decode(ToolInfo.self, from: Data(contentsOf: file))) }

                catch { appendStatus("⚠️修改器记录损坏，已跳过: \(file.lastPathComponent)") }

            }

            toolList = loaded.sorted { $0.toolName.localizedStandardCompare($1.toolName) == .orderedAscending }

        } catch { appendStatus("⚠️读取修改器列表失败: \(error.localizedDescription)") }

    }

    // MARK: - 游戏目录

    private func gameStorage(_ entry: String) -> URL? {

        let parts = entry.split(separator: "|", maxSplits: 1).map(String.init)

        guard parts.count == 2 else { return nil }

        let subDirectory: String

        switch parts[0] {

        case "原版": subDirectory = "Original"

        case "魔改": subDirectory = "Modded"

        default: return nil

        }

        return appSupport.appendingPathComponent("Games").appendingPathComponent(subDirectory).appendingPathComponent(parts[1])

    }

    private func resolveSymlink(_ url: URL) -> URL? {

        let fm = FileManager.default

        do {

            let attributes = try fm.attributesOfItem(atPath: url.path)

            guard attributes[.type] as? FileAttributeType == .typeSymbolicLink else { return url }

            let destination = try fm.destinationOfSymbolicLink(atPath: url.path)

            if destination.hasPrefix("/") { return URL(fileURLWithPath: destination).standardizedFileURL }

            return url.deletingLastPathComponent().appendingPathComponent(destination).standardizedFileURL

        } catch { return nil }

    }

    private func openGameFolder(_ entry: String) {

        guard let storage = gameStorage(entry) else {
            statusText = "❌游戏记录无效"
            return
        }

        guard let realURL = resolveSymlink(storage),
              FileManager.default.fileExists(atPath: realURL.path) else {

            let alert = NSAlert()
            alert.messageText = "找不到游戏文件"
            alert.informativeText = """
            该游戏可能已经被移动或删除，当前启动器记录已经失效。

            是否从管理列表中移除这条记录？
            """
            alert.addButton(withTitle: "移除记录")
            alert.addButton(withTitle: "保留")

            if alert.runModal() == .alertFirstButtonReturn {
                removeBrokenGameRecord(entry)
            } else {
                statusText = "⚠️游戏文件已被移动或删除，已保留当前记录"
            }
            return
        }

        NSWorkspace.shared.open(realURL)
        statusText = "✅已打开目录"
    }

    private func removeBrokenGameRecord(_ entry: String) {

        guard let storage = gameStorage(entry) else {
            statusText = "❌游戏记录无效"
            return
        }

        do {
            let fm = FileManager.default

            // 断开的软链接虽然 fileExists(atPath:) 会返回 false，
            // 但链接节点本身仍然存在，所以这里直接尝试 removeItem。
            do {
                try fm.removeItem(at: storage)
            } catch CocoaError.fileNoSuchFile {
                // 如果记录节点本身已经不存在，就视为已经清理完成。
            }

            if selectedGameEntry == entry {
                selectedGameEntry = nil
            }

            refreshGames()
            statusText = "✅已移除失效的游戏记录"

        } catch {
            statusText = "❌移除失效记录失败: \(error.localizedDescription)"
        }
    }

    private func toolsForGame() -> [ToolInfo] {

        guard let entry = selectedGameEntry, let storage = gameStorage(entry), let game = loadGameInfo(storage) else { return [] }

        return toolList.filter { $0.bindGameIds.contains(game.gameId) }

    }

    private func refreshGames() {

        var result: [String] = []

        func scan(tag: String, root: URL) {

            guard FileManager.default.fileExists(atPath: root.path) else { return }

            do {

                let items = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

                for item in items {
                    result.append("\(tag)|\(item.lastPathComponent)")
                }

            } catch { appendStatus("⚠️扫描游戏目录失败: \(error.localizedDescription)") }

        }

        scan(tag: "原版", root: appSupport.appendingPathComponent("Games/Original"))

        scan(tag: "魔改", root: appSupport.appendingPathComponent("Games/Modded"))

        gameList = result.sorted { $0.localizedStandardCompare($1) == .orderedAscending }

    }

    // MARK: - Wine 引擎路径探测

    private func isRealExecutableFile(_ url: URL) -> Bool {

        let fm = FileManager.default

        let resolved = url.resolvingSymlinksInPath()

        var isDirectory: ObjCBool = false

        guard fm.fileExists(atPath: resolved.path, isDirectory: &isDirectory), !isDirectory.boolValue else { return false }

        return fm.isExecutableFile(atPath: resolved.path)

    }

    private func wineCandidateScore(_ url: URL) -> Int {

        let name = url.lastPathComponent.lowercased()

        let parent = url.deletingLastPathComponent().lastPathComponent.lowercased()

        let path = url.path.lowercased()

        var score = 0

        if parent == "bin" { score += 10_000 }

        if path.contains("/bin/") { score += 2_000 }

        if name == "wine64" { score += 500 }

        if name == "wine" { score += 300 }

        if path.contains("/lib/") || path.contains("/lib64/") { score -= 5_000 }

        return score

    }

    private func libraryCandidateScore(_ url: URL, wine: URL) -> Int {

        let path = url.standardizedFileURL.path.lowercased()

        let wineRoot = wine.deletingLastPathComponent().deletingLastPathComponent().standardizedFileURL.path.lowercased()

        var score = 0

        if path == "\(wineRoot)/lib" { score += 20_000 }

        if path == "\(wineRoot)/lib64" { score += 18_000 }

        if url.lastPathComponent.lowercased() == "lib" { score += 1_000 }

        if url.lastPathComponent.lowercased() == "lib64" { score += 800 }

        if path.contains("/lib/wine/") || path.contains("/lib64/wine/") { score -= 10_000 }

        return score

    }

    private func buildEngineResources(wine: URL, serverCandidates: [URL], libraryCandidates: [URL]) -> WineEngineResources? {

        let fm = FileManager.default

        let wineEntry = wine.standardizedFileURL

        let binDirectory = wineEntry.deletingLastPathComponent()

        let server = serverCandidates.first(where: { $0.deletingLastPathComponent().standardizedFileURL == binDirectory.standardizedFileURL }) ?? serverCandidates.first

        guard let server, isRealExecutableFile(server) else { return nil }

        guard let libraryPath = libraryCandidates.max(by: { libraryCandidateScore($0, wine: wineEntry) < libraryCandidateScore($1, wine: wineEntry) }) else { return nil }

        guard fm.fileExists(atPath: libraryPath.path) else { return nil }

        return WineEngineResources(wine: wineEntry, server: server.standardizedFileURL, libraryPath: libraryPath.standardizedFileURL)

    }

    private func resolveEngineResources(from root: URL) -> WineEngineResources? {

        let fm = FileManager.default

        guard fm.fileExists(atPath: root.path) else { return nil }

        guard let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .isExecutableKey], options: [.skipsHiddenFiles], errorHandler: { _, _ in true }) else { return nil }

        var wineCandidates: [URL] = []

        var serverCandidates: [URL] = []

        var libraryCandidates: [URL] = []

        for case let file as URL in enumerator {

            let name = file.lastPathComponent.lowercased()

            if (name == "wine64" || name == "wine"), isRealExecutableFile(file) { wineCandidates.append(file); continue }

            if name == "wineserver", isRealExecutableFile(file) { serverCandidates.append(file); continue }

            if name == "lib" || name == "lib64" {

                var isDirectory: ObjCBool = false

                if fm.fileExists(atPath: file.path, isDirectory: &isDirectory), isDirectory.boolValue { libraryCandidates.append(file) }

            }

        }

        guard let bestWine = wineCandidates.max(by: { wineCandidateScore($0) < wineCandidateScore($1) }) else { return nil }

        return buildEngineResources(wine: bestWine, serverCandidates: serverCandidates, libraryCandidates: libraryCandidates)

    }

    private func resolveStoredWineResources() -> WineEngineResources? {

        let fm = FileManager.default

        if !wine64Path.isEmpty {

            let stored = URL(fileURLWithPath: wine64Path).standardizedFileURL

            if isRealExecutableFile(stored), let scanned = resolveEngineResources(from: wineFolder) {

                return WineEngineResources(wine: stored, server: scanned.server, libraryPath: scanned.libraryPath)

            }

        }

        if let resources = resolveEngineResources(from: wineFolder) {

            wine64Path = resources.wine.path

            return resources

        }

        if !wine64Path.isEmpty && !fm.fileExists(atPath: wine64Path) { wine64Path = "" }

        return nil

    }

    private func checkWineReady() -> Bool {

        guard let resources = resolveStoredWineResources() else { wineReady = false; return false }

        wine64Path = resources.wine.path

        wineReady = true

        return true

    }
    // MARK: - 启动静默清理（只清下载残留 + 不完整 WineEngine）
    // 不碰存档 / 不碰 Bottle / 不碰游戏本体。
    private func silentCleanupOnLaunch() {
        let fm = FileManager.default

        // 1) 临时下载残留
        var removedTemp = 0
        let tmp = fm.temporaryDirectory
        if let files = try? fm.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil) {
            for file in files where file.lastPathComponent.hasPrefix("yespvz_wine_") {
                if (try? fm.removeItem(at: file)) != nil { removedTemp += 1 }
            }
        }

        // 2) 不完整的 WineEngine：目录在，但 resolveEngineResources 找不到有效 wine64
        var removedWine = false
        if fm.fileExists(atPath: wineFolder.path) {
            if resolveEngineResources(from: wineFolder) == nil {
                if (try? fm.removeItem(at: wineFolder)) != nil {
                    removedWine = true
                    wineReady = false
                    wine64Path = ""
                }
            }
        }

        // 只有真清了东西才提示
        if removedTemp > 0 || removedWine {
            var parts: [String] = []
            if removedTemp > 0 { parts.append("临时下载文件 \(removedTemp) 个") }
            if removedWine { parts.append("不完整的 WineEngine") }
            appendStatus("🧹 启动清理：已清除 " + parts.joined(separator: "、"))
        }
    }
    // MARK: - V10 存档追踪：接入层

    /// 追踪定时器集合：key = gameId
    private static var trackingTimers: [String: Timer] = [:]

    /// 扫描 bottle 里所有 userdata 的绝对路径（只扫这个 bottle）
    private func listAllUserdataPaths(inBottle bottle: URL) -> [String] {
        let fm = FileManager.default
        let driveC = bottle.appendingPathComponent("drive_c")

        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &isDir), isDir.boolValue else {
            return []
        }

        guard let enumerator = fm.enumerator(
            at: driveC,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles],
            errorHandler: { _, _ in true }
        ) else {
            return []
        }

        var result: [String] = []
        for case let url as URL in enumerator {
            guard url.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }
            let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values?.isDirectory == true, values?.isSymbolicLink != true else {
                continue
            }
            result.append(url.path)
            enumerator.skipDescendants()
        }
        return result
    }


    
    /// 单个 userdata 目录的指纹：所有顶层文件的 名字+mtime+size 拼接
    private func computeFingerprint(for userdataPath: String) -> String {
        let fm = FileManager.default
        let dir = URL(fileURLWithPath: userdataPath)
        guard let children = try? fm.contentsOfDirectory(
            at: dir,
            includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else { return "" }

        var parts: [String] = []
        for file in children {
            let v = try? file.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey])
            guard v?.isRegularFile == true else { continue }
            let name = file.lastPathComponent
            let mtime = v?.contentModificationDate?.timeIntervalSince1970 ?? 0
            let size = v?.fileSize ?? 0
            parts.append("\(name):\(mtime):\(size)")
        }
        parts.sort()
        return parts.joined(separator: "|")
    }

    private func computeFingerprints(for paths: [String]) -> [String: String] {
        var r: [String: String] = [:]
        for p in paths { r[p] = computeFingerprint(for: p) }
        return r
    }
    /// 启动前：开追踪
    private func beginSaveTracking(for gameId: String, bottle: URL) {
        let paths = listAllUserdataPaths(inBottle: bottle)
        let fps = computeFingerprints(for: paths)
        let running = SaveTrackingStore.shared.currentRunningGameIds()

        SaveTrackingStore.shared.beginTracking(
            gameId: gameId,
            bottlePath: bottle.path,
            currentPaths: paths,
            currentFingerprints: fps,
            runningGameIds: running
        )

        if wineDebug {
            appendStatus("📸存档追踪：\(gameId) 启动前扫到 \(paths.count) 个 userdata")
        }
    }

    /// 启动每秒快照 Timer
    private func startSaveTrackingTimer(for gameId: String, bottle: URL) {
        Self.trackingTimers[gameId]?.invalidate()

        if let record = SaveTrackingStore.shared.load(gameId: gameId),
           record.status == .tracked || record.status == .shared {
            return
        }

        let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if let record = SaveTrackingStore.shared.load(gameId: gameId),
               record.status == .tracked || record.status == .shared {
                Self.trackingTimers[gameId]?.invalidate()
                Self.trackingTimers.removeValue(forKey: gameId)
                return
            }

            let paths = Self.listAllUserdataPathsStatic(inBottle: bottle)
            let fps = Self.computeFingerprintsStatic(for: paths)
            let running = SaveTrackingStore.shared.currentRunningGameIds()
            SaveTrackingStore.shared.appendSnapshot(
                gameId: gameId,
                currentPaths: paths,
                currentFingerprints: fps,
                runningGameIds: running
            )
        }
        Self.trackingTimers[gameId] = timer
    }
    /// wine 启动器退出了，但游戏可能还在 wineserver 里跑。
    /// 继续 Timer，等 wineserver 退出后再 finalize。
    private func scheduleTrackingFinalize(for gameId: String, bottle: URL) {
        // ⚠️ 不要在这里停 Timer
        waitForWineserverExitThenFinalize(gameId: gameId, bottle: bottle, attempt: 0)
    }

    private func waitForWineserverExitThenFinalize(gameId: String, bottle: URL, attempt: Int) {
        if attempt > 120 {
            if wineDebug { appendStatus("⏱️存档追踪：等待 wineserver 超时，直接分析") }
            performTrackingFinalize(gameId: gameId, bottle: bottle)
            return
        }

        // 用静态方法在后台跑 pgrep，避免捕获 self；传入本次 bottle 路径过滤
        Self.checkWineserverRunning(forBottle: bottle.path) { stillRunning in
            DispatchQueue.main.async {
                if stillRunning {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        self.waitForWineserverExitThenFinalize(gameId: gameId, bottle: bottle, attempt: attempt + 1)
                    }
                } else {
                    self.performTrackingFinalize(gameId: gameId, bottle: bottle)
                }
            }
        }
    }

    /// 真正做归属分析 + 写回 GameInfo
    /// 此时 wineserver 已经退出
    private func performTrackingFinalize(gameId: String, bottle: URL) {
        Self.trackingTimers[gameId]?.invalidate()
        Self.trackingTimers.removeValue(forKey: gameId)

        SaveTrackingStore.shared.markGameStopped(gameId)

        let paths = listAllUserdataPaths(inBottle: bottle)
        let fps = computeFingerprints(for: paths)
        let running: [String] = []

        var others: [String: String] = [:]
        for entry in gameList {
            guard let storage = gameStorage(entry), let g = loadGameInfo(storage) else { continue }
            if let tp = g.trackedSavePath {
                others[g.gameId] = tp
            }
        }

        let status = SaveTrackingStore.shared.finalizeTracking(
            gameId: gameId,
            currentPaths: paths,
            currentFingerprints: fps,
            runningGameIds: running,
            allOtherTrackedPaths: others
        )

        for entry in gameList {
            guard let storage = gameStorage(entry),
                  var g = loadGameInfo(storage),
                  g.gameId == gameId else { continue }

            let oldStatus = g.trackingStatus ?? ""
            let protected = (oldStatus == SaveTrackingStatus.tracked.rawValue
                          || oldStatus == SaveTrackingStatus.shared.rawValue)
            if (status == .pending || status == .ambiguous) && protected {
                // 保留旧状态
            } else {
                g.trackingStatus = status.rawValue
                if status == .tracked || status == .shared {
                    if let record = SaveTrackingStore.shared.load(gameId: gameId),
                       let tp = record.trackedPath {
                        g.trackedSavePath = tp
                    }
                }
                g.lastTrackingUpdate = Date().timeIntervalSince1970
                saveGameInfo(storage, g)
            }

            if wineDebug {
                appendStatus("💾存档追踪：\(gameId) → \(status.rawValue)")
            }

            if selectedGameEntry == entry {
                selectedGameEntry = entry
            }
            break
        }
    }
    /// 校验所有游戏的 trackedSavePath 是否还有效
    /// 失效的 → 改回 pending（保留 trackedSavePath 供兜底扫描参考）
    private func validateAllTrackedPaths() {
        let fm = FileManager.default
        var invalidCount = 0

        for entry in gameList {
            guard let storage = gameStorage(entry),
                  var g = loadGameInfo(storage) else { continue }

            // ⭐️ tracked / shared 都检查
            let needCheck = (g.trackingStatus == SaveTrackingStatus.tracked.rawValue
                          || g.trackingStatus == SaveTrackingStatus.shared.rawValue)
            guard needCheck else { continue }

            let path = g.trackedSavePath ?? ""
            if path.isEmpty || !fm.fileExists(atPath: path) {
                g.trackingStatus = SaveTrackingStatus.pending.rawValue
                g.lastTrackingUpdate = Date().timeIntervalSince1970
                saveGameInfo(storage, g)
                invalidCount += 1
            }
        }

        if invalidCount > 0 {
            appendStatus("⚠️ 检测到 \(invalidCount) 个游戏的追踪路径已失效，已重置为「待定位」（导出时会自动兜底扫描）")
        }
    }
    /// 给游戏列表显示追踪状态小标签
    @ViewBuilder
    private func trackingBadge(for entry: String) -> some View {
        if let storage = gameStorage(entry),
           let game = loadGameInfo(storage) {
            let status = SaveTrackingStatus(rawValue: game.trackingStatus ?? "") ?? .neverLaunched
            switch status {
            case .tracked:
                Text("✅ 已定位存档").font(.caption2).foregroundColor(.green)
            case .shared:
                Text("🔗 共用存档").font(.caption2).foregroundColor(.orange)
            case .pending:
                Text("⏳ 待定位存档").font(.caption2).foregroundColor(.secondary)
            case .ambiguous:
                Text("⚠️ 歧义").font(.caption2).foregroundColor(.orange)//不会触发
            case .neverLaunched:
                Text("🆕 未启动过").font(.caption2).foregroundColor(.secondary)
            }
        }
    }
    // MARK: - Wine 安装

    private func extractWineArchive(_ archive: URL, to destination: URL) throws {
        let fm = FileManager.default
        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
        try fm.createDirectory(at: destination, withIntermediateDirectories: true)

        let ext = archive.pathExtension.lowercased()
        let process = Process()
        let errorPipe = Pipe()
        process.standardError = errorPipe

        if ext == "zip" {
            process.executableURL = URL(fileURLWithPath: "/usr/bin/ditto")
            process.arguments = ["-x", "-k", archive.path, destination.path]
        } else {
            process.executableURL = URL(fileURLWithPath: "/usr/bin/tar")
            process.arguments = ["-xf", archive.path, "-C", destination.path]
        }

        try process.run()
        process.waitUntilExit()

        guard process.terminationStatus == 0 else {
            let data = errorPipe.fileHandleForReading.readDataToEndOfFile()
            let message = String(data: data, encoding: .utf8) ?? "未知错误"

            // 修复：删除失败不再 try? 静默忽略，显式上报并写日志
            var cleanupNote = ""
            do {
                if fm.fileExists(atPath: destination.path) {
                    try fm.removeItem(at: destination)
                }
            } catch {
                cleanupNote = "\n⚠️ 且清理损坏目录失败（\(error.localizedDescription)），请手动删除：\(destination.path)"
                appendStatus("⚠️ 解压失败后清理目录失败: \(error.localizedDescription)\n路径: \(destination.path)")
            }

            throw NSError(
                domain: "YesPVZLauncher.WineInstall",
                code: Int(process.terminationStatus),
                userInfo: [NSLocalizedDescriptionKey: (message.isEmpty ? "解压失败" : message) + cleanupNote]
            )
        }
    }

    private func installWine(from archive: URL) {
        do {
            statusText = "📦正在解压 Wine..."

            try extractWineArchive(archive, to: wineFolder)

            ensureExecutablePermissions(in: wineFolder)

            removeQuarantine(in: wineFolder)

            guard let resources = resolveEngineResources(from: wineFolder) else {
                wineReady = false

                // 解压成功但内容不对（不是有效 Wine 包 / 包不完整）：
                // 一样要清掉，避免残留脏目录影响后续安装。
                var cleanupNote = ""
                let fm = FileManager.default
                do {
                    if fm.fileExists(atPath: wineFolder.path) {
                        try fm.removeItem(at: wineFolder)
                    }
                } catch {
                    cleanupNote = "\n⚠️ 且清理失败（\(error.localizedDescription)），请手动删除：\(wineFolder.path)"
                    appendStatus("⚠️ 清理无效 Wine 目录失败: \(error.localizedDescription)\n路径: \(wineFolder.path)")
                }

                statusText = "❌解压完成，但未找到有效的 wine64 或 wine 可执行文件，已清理无效目录。\(cleanupNote)"
                return
            }

            wine64Path = resources.wine.path
            wineReady = true
            statusText = "✅Wine安装成功！\n\(resources.wine.path)"
        } catch {
            wineReady = false
            statusText = "❌安装失败: \(error.localizedDescription)"
        }
    }

    private func downloadWine() {

        var sourceIndex = 0

        func nextAttempt() {

            guard sourceIndex < ResourceLinkConfig.wineDownloadSources.count else { statusText = "❌所有下载源失败，请手动安装"; return }

            let url = ResourceLinkConfig.wineDownloadSources[sourceIndex]

            let suffix: String

            if url.lastPathComponent.lowercased().hasSuffix(".tar.gz") { suffix = "tar.gz" }

            else if !url.pathExtension.isEmpty { suffix = url.pathExtension }

            else { suffix = "archive" }

            let temporaryFile = FileManager.default.temporaryDirectory.appendingPathComponent("yespvz_wine_\(UUID().uuidString).\(suffix)")

            statusText = "🔽下载中（源\(sourceIndex + 1)/\(ResourceLinkConfig.wineDownloadSources.count)）..."

            downloader.download(url: url, to: temporaryFile) { result in

                switch result {

                case .success(let path): self.statusText = "✅下载完成，安装中..."; self.installWine(from: path); try? FileManager.default.removeItem(at: path)

                case .failure(let error): self.statusText = "❌源\(sourceIndex + 1)失败: \(error.localizedDescription)，换下一个..."; sourceIndex += 1; nextAttempt()

                }

            }

        }

        nextAttempt()

    }

    private func manualInstall() {

        let panel = NSOpenPanel()

        panel.title = "选择Wine压缩包"

        panel.canChooseFiles = true

        panel.canChooseDirectories = false

        panel.allowsMultipleSelection = false

        panel.allowedContentTypes = [UTType(filenameExtension: "xz")!, UTType(filenameExtension: "gz")!, UTType(filenameExtension: "tar")!, UTType(filenameExtension: "zip")!]

        guard panel.runModal() == .OK, let url = panel.url else { statusText = "❌未选择文件"; return }

        statusText = "📦安装中..."

        installWine(from: url)

        _ = checkWineReady()

    }

    // MARK: - Wine 进程状态

    private func syncWineProcessState(showMessage: Bool = false) {

        let staleIDs = runningProcesses.filter { !$0.value.isRunning }.map(\.key)

        for id in staleIDs { runningProcesses.removeValue(forKey: id) }

        if showMessage {

            statusText = hasRunningWineProcess ? "🔄 已刷新进程状态\n✅当前仍有 Wine 进程运行" : "🔄 已刷新进程状态\n当前没有由启动器跟踪的 Wine 进程"

        }

    }

    private func terminateRunningProcesses() {

        syncWineProcessState()

        // 收集要杀的 PID（先干掉本启动器跟踪的 wine loader）
        var pids: [Int32] = []

        for process in runningProcesses.values where process.isRunning {

            if let errPipe = process.standardError as? Pipe { errPipe.fileHandleForReading.readabilityHandler = nil }

            if let outPipe = process.standardOutput as? Pipe { outPipe.fileHandleForReading.readabilityHandler = nil }

            let pid = process.processIdentifier
            pids.append(pid)

            // 先给进程组发 TERM，wine loader 的进程组会带上 wineserver + 游戏进程
            _ = runSystemProcess(executable: "/bin/kill", arguments: ["-TERM", "-\(pid)"], wait: false)
            process.terminate()
        }

        appendStatus("⚠️已尝试发送优雅终止信号（仅针对本启动器跟踪的 PID）...")

        // 1 秒后对还没死的进程组补刀 -9
        let pidsToKill = pids
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            for pid in pidsToKill {
                _ = self.runSystemProcess(executable: "/bin/kill", arguments: ["-9", "-\(pid)"], wait: false)
            }
        }

        runningProcesses.removeAll()

        // V10：强制终止，清空所有 running 标记
        SaveTrackingStore.shared.clearAllRunning()

        stopAllCaffeinate()

        appendStatus("✅已执行终止（仅本启动器进程组）")
    }

    private func realURL(_ url: URL) -> URL {
        url.standardizedFileURL.resolvingSymlinksInPath()
    }
    // MARK: - Wine 启动核心

    @discardableResult
    private func runWine(exe: URL, bottle: URL, gameId: String, isModifier: Bool = false) -> Bool {
        syncWineProcessState()

        // 无论游戏是复制导入还是软链接导入，
        // 真正交给 Wine 前全部转换为真实路径。
        let realExe = realURL(exe)
        let realBottle = realURL(bottle)

        guard FileManager.default.fileExists(atPath: realExe.path) else {
            appendStatus("❌找不到exe: \(realExe.path)")
            return false
        }

        guard checkWineReady(),
              let resources = resolveStoredWineResources() else {
            appendStatus("❌Wine未安装或 Wine loader 路径失效")
            return false
        }

        do {
            try FileManager.default.createDirectory(
                at: realBottle,
                withIntermediateDirectories: true
            )
        } catch {
            appendStatus("❌Bottle创建失败: \(error.localizedDescription)")
            return false
        }

        removeQuarantine(in: realExe.deletingLastPathComponent())
        removeQuarantine(in: wineFolder)
        removeQuarantine(in: realBottle)
        ensureExecutablePermissions(in: wineFolder)

        let wine = realURL(resources.wine)
        let realServer = realURL(resources.server)
        let realLibraryPath = realURL(resources.libraryPath)

        if wineDebug {
            appendStatus("""
            🔗原始 EXE：\(exe.path)
            📍实际 EXE：\(realExe.path)
            🔗原始 Bottle：\(bottle.path)
            📍实际 Bottle：\(realBottle.path)
            """)
        }
        guard isRealExecutableFile(wine) else { appendStatus("❌Wine loader 不是有效可执行文件: \(wine.path)"); return false }

        let process = Process()
        let processID = isModifier ? "modifier_\(gameId)" : gameId
        process.executableURL = wine
        process.currentDirectoryURL = realExe.deletingLastPathComponent()

        var environment = ProcessInfo.processInfo.environment
        let oldFallback = environment["DYLD_FALLBACK_LIBRARY_PATH"] ?? ""
        let libraryPath = realLibraryPath.path

        environment["WINEPREFIX"] = realBottle.path
        environment["LANG"] = "zh_CN.UTF-8"
        environment["LC_ALL"] = "zh_CN.UTF-8"
        environment["WINELOADER"] = wine.path
        environment["WINESERVER"] = realServer.path
        environment["WINELIB"] = libraryPath
        environment["DYLD_FALLBACK_LIBRARY_PATH"] =
            oldFallback.isEmpty ? libraryPath : "\(libraryPath):\(oldFallback)"

        if forceOpenGLRender {
            environment["WINED3D_BACKEND"] = "OpenGL"
            environment["WINED3D_SOFTWARE"] = "1"
            environment["DXVK_HUD"] = "0"
        }

        environment["WINEDEBUG"] = wineDebug ? "err+all,warn+all,fixme+all,+seh,+vulkan,+d3d,+dxgi" : "-all"
        process.environment = environment
        process.arguments = realExe.pathExtension.lowercased() == "bat"
            ? ["cmd.exe", "/c", "start", "", realExe.path]
            : [realExe.path]

        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        let logQueue = DispatchQueue(label: "com.yespvzlauncher.wine.log.\(processID)", qos: .utility)
        var pendingLog = ""
        var partialLine = ""
        var lastUIFlush = Date()
        let maxPendingCharacters = 10_000
        let minimumFlushInterval: TimeInterval = 0.8
        let importantKeywords = ["err:", "warn:", "fixme:", "exception", "unhandled", "kernelbase", "ntdll", "wineserver", "vulkan", "winevulkan", "dxvk", "d3d", "dxgi", "metal", "gptk", "fatal", "failed", "failure", "access denied"]

        func filteredImportantLines(from incoming: String) -> String {
            partialLine += incoming
            var lines = partialLine.components(separatedBy: .newlines)
            partialLine = lines.popLast() ?? ""
            let important = lines.filter { line in
                let lower = line.lowercased()
                return importantKeywords.contains(where: { lower.contains($0) })
            }
            guard !important.isEmpty else { return "" }
            return important.joined(separator: "\n") + "\n"
        }

        func flushPending(force: Bool = false) {
            logQueue.async {
                guard self.wineDebug else {
                    pendingLog.removeAll(keepingCapacity: true)
                    partialLine.removeAll(keepingCapacity: true)
                    return
                }
                let now = Date()
                guard force || now.timeIntervalSince(lastUIFlush) >= minimumFlushInterval else { return }
                if force, !partialLine.isEmpty {
                    let lower = partialLine.lowercased()
                    if importantKeywords.contains(where: { lower.contains($0) }) { pendingLog += partialLine + "\n" }
                    partialLine.removeAll(keepingCapacity: true)
                }
                guard !pendingLog.isEmpty else { return }
                let text = pendingLog
                pendingLog.removeAll(keepingCapacity: true)
                lastUIFlush = now
                DispatchQueue.main.async { self.appendWineLogToUI(text) }
            }
        }

        pipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty else { return }
            guard self.wineDebug, let text = String(data: data, encoding: .utf8) else { return }
            logQueue.async {
                let filtered = filteredImportantLines(from: text)
                if !filtered.isEmpty { pendingLog += filtered }
                if pendingLog.count > maxPendingCharacters {
                    pendingLog = "…本批关键日志已截断…\n" + String(pendingLog.suffix(maxPendingCharacters))
                }
                flushPending()
            }
        }

        process.terminationHandler = { finishedProcess in
            pipe.fileHandleForReading.readabilityHandler = nil
            flushPending(force: true)
            DispatchQueue.main.async {
                // ⭐️ 只在 runningProcesses 里存的还是自己时才删，避免误删新进程
                if let current = self.runningProcesses[processID], current === finishedProcess {
                    self.runningProcesses.removeValue(forKey: processID)
                }
                self.stopCaffeinate(id: processID)

                let code = finishedProcess.terminationStatus
                if code == 0 {
                    self.appendStatus("✅Wine启动入口已正常结束（退出码 0）。注意：这不等于 Windows 游戏已经退出，Wine 可能已把实际进程交给 wineserver。")
                } else {
                    self.appendStatus("⚠️Wine启动入口异常结束或被第三方或用户手动退出（退出码 \(code)）")
                }

                // ⭐️ 修改器不参与追踪
                // ⭐️ 已经 tracked / shared 的游戏不再 finalize，省后台轮询
                if !isModifier {
                    let alreadyTracked: Bool = {
                        guard let r = SaveTrackingStore.shared.load(gameId: gameId) else { return false }
                        return r.status == .tracked || r.status == .shared
                    }()
                    if !alreadyTracked {
                        self.scheduleTrackingFinalize(for: gameId, bottle: realBottle)
                    }
                }
            }
        }

        do {
            try process.run()
            runningProcesses[processID] = process

            // ⭐️ 修改器不参与追踪
            // ⭐️ 已经 tracked / shared 的游戏不再重复追踪，省后台
            if !isModifier {
                let alreadyTracked: Bool = {
                    guard let r = SaveTrackingStore.shared.load(gameId: gameId) else { return false }
                    return r.status == .tracked || r.status == .shared
                }()

                if !alreadyTracked {
                    SaveTrackingStore.shared.markGameRunning(gameId)
                    beginSaveTracking(for: gameId, bottle: realBottle)
                    startSaveTrackingTimer(for: gameId, bottle: realBottle)
                } else if wineDebug {
                    appendStatus("💾 \(gameId) 已追踪过，跳过本次追踪")
                }
            }

            startCaffeinate(for: process, id: processID)
            appendStatus("✅已发送启动指令")
            return true
        } catch {
            pipe.fileHandleForReading.readabilityHandler = nil
            runningProcesses.removeValue(forKey: processID)
            stopCaffeinate(id: processID)
            appendStatus("❌启动失败: \(error.localizedDescription)")
            return false
        }
    }
    private static func listAllUserdataPathsStatic(inBottle bottle: URL) -> [String] {
        let fm = FileManager.default
        let driveC = bottle.appendingPathComponent("drive_c")

        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &isDir), isDir.boolValue else {
            return []
        }

        guard let enumerator = fm.enumerator(
            at: driveC,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles],
            errorHandler: { _, _ in true }
        ) else {
            return []
        }

        var result: [String] = []
        for case let url as URL in enumerator {
            guard url.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }
            let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values?.isDirectory == true, values?.isSymbolicLink != true else {
                continue
            }
            result.append(url.path)
            enumerator.skipDescendants()
        }
        return result
    }
    
    private static func computeFingerprintsStatic(for paths: [String]) -> [String: String] {
        var r: [String: String] = [:]
        let fm = FileManager.default
        for path in paths {
            let dir = URL(fileURLWithPath: path)
            guard let children = try? fm.contentsOfDirectory(
                at: dir,
                includingPropertiesForKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey],
                options: [.skipsHiddenFiles]
            ) else {
                r[path] = ""
                continue
            }
            var parts: [String] = []
            for file in children {
                let v = try? file.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey])
                guard v?.isRegularFile == true else { continue }
                let name = file.lastPathComponent
                let mtime = v?.contentModificationDate?.timeIntervalSince1970 ?? 0
                let size = v?.fileSize ?? 0
                parts.append("\(name):\(mtime):\(size)")
            }
            parts.sort()
            r[path] = parts.joined(separator: "|")
        }
        return r
    }
    private static func checkWineserverRunning(forBottle bottlePath: String, completion: @escaping (Bool) -> Void) {
        DispatchQueue.global(qos: .utility).async {
            // 1) 拿到系统上所有 wineserver 的 PID
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/pgrep")
            p.arguments = ["-x", "wineserver"]
            let pipe = Pipe()
            p.standardOutput = pipe
            p.standardError = pipe

            do {
                try p.run()
                p.waitUntilExit()
            } catch {
                completion(false)
                return
            }

            guard p.terminationStatus == 0 else {
                completion(false)
                return
            }

            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            let output = String(data: data, encoding: .utf8) ?? ""
            let pids = output.split(separator: "\n").compactMap { Int32($0.trimmingCharacters(in: .whitespaces)) }
            guard !pids.isEmpty else {
                completion(false)
                return
            }

            // 2) 对每个 PID 查它环境变量里的 WINEPREFIX，只认属于我们 bottle 的那个
            let normalizedBottle = URL(fileURLWithPath: bottlePath).standardizedFileURL.path
            for pid in pids {
                let ps = Process()
                ps.executableURL = URL(fileURLWithPath: "/bin/ps")
                // eww = 显示环境变量 + 宽输出 + 不截断；-o command= 只保留命令行+环境
                ps.arguments = ["eww", "-p", "\(pid)", "-o", "command="]
                let psPipe = Pipe()
                ps.standardOutput = psPipe
                ps.standardError = psPipe
                do {
                    try ps.run()
                    ps.waitUntilExit()
                    let d = psPipe.fileHandleForReading.readDataToEndOfFile()
                    let line = String(data: d, encoding: .utf8) ?? ""
                    if line.contains("WINEPREFIX=\(normalizedBottle)") ||
                       line.contains("WINEPREFIX=\(bottlePath)") {
                        completion(true)
                        return
                    }
                } catch {
                    continue
                }
            }
            // 所有 wineserver 都不是我们 bottle 的 → 我们的已退出
            completion(false)
        }
    }
    // MARK: - 启动游戏 / 修改器

    private func launchModifier() {
        syncWineProcessState()

        guard let toolID = selectedToolId,
              let tool = toolList.first(where: { $0.toolId == toolID }),
              let entry = selectedGameEntry,
              let storage = gameStorage(entry),
              let game = loadGameInfo(storage) else {
            statusText = "⚠️请选择修改器"; return
        }

        let exe = URL(fileURLWithPath: tool.toolRealPath)
        guard FileManager.default.fileExists(atPath: exe.path) else {
            statusText = "❌修改器文件已被移动或删除，请重新导入"; return
        }

        let bottle = getBottle(game, storage: storage)

        statusText = "⏳启动修改器: \(tool.toolName)\n🍷Bottle: \(bottle.path)"
        _ = runWine(exe: exe, bottle: bottle, gameId: game.gameId, isModifier: true)
    }

    private func launchGame() {

        syncWineProcessState()

        guard let entry = selectedGameEntry else { statusText = "⚠️请选择游戏"; return }

        guard let storage = gameStorage(entry), let realFolder = resolveSymlink(storage), let game = loadGameInfo(storage) else { statusText = "❌游戏路径失效"; return }

        guard FileManager.default.fileExists(atPath: realFolder.path) else { statusText = "❌游戏原始文件夹不存在或软链接失效"; return }

        let exe = realFolder.appendingPathComponent(game.mainExeName)

        let bottle = getBottle(game, storage: storage)

        statusText = "⏳启动: \(realFolder.lastPathComponent)\n🍷Bottle: \(bottle.path)"

        _ = runWine(exe: exe, bottle: bottle, gameId: game.gameId)

    }

    // MARK: - 修改器导入

    private func importModifier() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.title = "选择修改器文件夹"
        guard panel.runModal() == .OK, let sourceFolder = panel.url else {
            statusText = "❌取消"; return
        }

        let exeList: [URL]
        do {
            let allItems = try FileManager.default.contentsOfDirectory(
                at: sourceFolder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]
            )
            exeList = allItems
                .filter { $0.pathExtension.lowercased() == "exe" }
                .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        } catch {
            statusText = "❌读取文件夹失败：\(error.localizedDescription)"; return
        }

        guard !exeList.isEmpty else { statusText = "❌文件夹里没有 .exe"; return }

        let mainExe: URL
        if exeList.count > 1 {
            let alertExe = NSAlert()
            alertExe.messageText = "检测到多个exe程序"
            alertExe.informativeText = "请选择【修改器主程序】"
            for exe in exeList { alertExe.addButton(withTitle: exe.lastPathComponent) }
            alertExe.addButton(withTitle: "取消")
            let response = alertExe.runModal()
            let index = response.rawValue - NSApplication.ModalResponse.alertFirstButtonReturn.rawValue
            guard index >= 0, index < exeList.count else {
                statusText = "❌已取消导入"; return
            }
            mainExe = exeList[index]
        } else {
            mainExe = exeList[0]
        }

        guard !gameList.isEmpty else { statusText = "⚠️请先导入游戏"; return }

        var items: [(display: String, gameID: String)] = []
        for entry in gameList {
            guard let storage = gameStorage(entry), let game = loadGameInfo(storage) else { continue }
            items.append((entry, game.gameId))
        }
        guard !items.isEmpty else { statusText = "⚠️没有可绑定的有效游戏"; return }

        let alert = NSAlert()
        alert.messageText = "绑定修改器"
        alert.informativeText = "选择要绑定的游戏"
        alert.addButton(withTitle: "确认")
        alert.addButton(withTitle: "取消")

        // 外层容器：全选 + 列表
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 280))

        let selectAllCheckbox = NSButton(checkboxWithTitle: "全选", target: nil, action: nil)
        selectAllCheckbox.state = .on       // 默认全部已绑定，所以全选也是 on
        selectAllCheckbox.frame = NSRect(x: 8, y: 256, width: 360, height: 20)
        container.addSubview(selectAllCheckbox)

        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.frame = NSRect(x: 0, y: 0, width: 380, height: 248)

        let tableView = NSTableView()
        tableView.headerView = nil
        tableView.rowHeight = 24
        tableView.allowsMultipleSelection = false
        tableView.selectionHighlightStyle = .none

        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("game"))
        column.width = 360
        tableView.addTableColumn(column)

        let dataSource = GameBindingDataSource(items: items)
        dataSource.tableView = tableView
        tableView.dataSource = dataSource
        tableView.delegate = dataSource

        scroll.documentView = tableView
        container.addSubview(scroll)

        alert.accessoryView = container

        dataSource.selectAllCheckbox = selectAllCheckbox
        selectAllCheckbox.target = dataSource
        selectAllCheckbox.action = #selector(GameBindingDataSource.selectAllToggled(_:))

        objc_setAssociatedObject(alert, AssociatedKeys.gameBindingDataSource, dataSource, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let selectedIDs = dataSource.selectedGameIDs
        guard !selectedIDs.isEmpty else { statusText = "⚠️未选择游戏"; return }

        do {
            try FileManager.default.createDirectory(at: toolsDir, withIntermediateDirectories: true)
        } catch {
            statusText = "❌创建 Tools 目录失败：\(error.localizedDescription)"; return
        }

        let folderName = sourceFolder.lastPathComponent
        let targetFolder = toolsDir.appendingPathComponent(folderName)

        if FileManager.default.fileExists(atPath: targetFolder.path) {
            let overwriteAlert = NSAlert()
            overwriteAlert.messageText = "已存在同名修改器"
            overwriteAlert.informativeText = "是否覆盖？"
            overwriteAlert.addButton(withTitle: "覆盖")
            overwriteAlert.addButton(withTitle: "取消")
            guard overwriteAlert.runModal() == .alertFirstButtonReturn else {
                statusText = "❌已取消导入"; return
            }

            // ⭐ 扫盘删所有同名旧 JSON（不依赖内存 toolList，避免漏删导致两个同名并存）
            if let files = try? FileManager.default.contentsOfDirectory(
                at: toolsDir,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
            ) {
                for file in files where file.pathExtension.lowercased() == "json" {
                    if let data = try? Data(contentsOf: file),
                       let old = try? JSONDecoder().decode(ToolInfo.self, from: data),
                       old.toolName == folderName {
                        try? FileManager.default.removeItem(at: file)
                    }
                }
            }

            // 删旧文件夹
            try? FileManager.default.removeItem(at: targetFolder)
        }

        do {
            try FileManager.default.copyItem(at: sourceFolder, to: targetFolder)
        } catch {
            statusText = "❌复制修改器失败：\(error.localizedDescription)"; return
        }

        let relativePath = mainExe.pathComponents
            .dropFirst(sourceFolder.pathComponents.count)
            .joined(separator: "/")

        let tool = ToolInfo(
            toolId: UUID().uuidString,
            toolName: folderName,
            toolRealPath: targetFolder.appendingPathComponent(relativePath).path,
            bindGameIds: selectedIDs,
            note: ""
        )
        saveTool(tool)
        loadTools()
        statusText = "✅修改器导入成功，绑定\(selectedIDs.count)个游戏"
    }
    // MARK: - 导入游戏

    private func importGame() {

        let panel = NSOpenPanel()

        panel.canChooseDirectories = true

        panel.canChooseFiles = false

        panel.allowsMultipleSelection = false

        panel.title = "选择解压完毕的PVZ游戏文件夹"

        guard panel.runModal() == .OK, let realGameFolder = panel.url else { statusText = "❌已取消导入"; return }

        let exeList: [URL]

        do {

            let allItems = try FileManager.default.contentsOfDirectory(at: realGameFolder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

            exeList = allItems.filter { $0.pathExtension.lowercased() == "exe" }.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }

        } catch { statusText = "❌读取文件夹失败：\(error.localizedDescription)"; return }

        guard !exeList.isEmpty else { statusText = "❌文件夹找不到任何exe程序，不是游戏目录"; return }

        let mainExe: URL

        if exeList.count > 1 {

            let alertExe = NSAlert()

            alertExe.messageText = "检测到多个exe程序"

            alertExe.informativeText = "请选择【游戏主程序】，不要选择修改器"

            for exe in exeList { alertExe.addButton(withTitle: exe.lastPathComponent) }

            alertExe.addButton(withTitle: "取消")

            let response = alertExe.runModal()

            let index = response.rawValue - NSApplication.ModalResponse.alertFirstButtonReturn.rawValue

            guard index >= 0, index < exeList.count else { statusText = "❌已取消导入"; return }

            mainExe = exeList[index]

        } else { mainExe = exeList[0] }

        let alertType = NSAlert()

        alertType.messageText = "选择游戏类型"

        alertType.informativeText = "这个是原版PVZ，还是魔改/改版PVZ？"

        alertType.addButton(withTitle: "原版 Original")

        alertType.addButton(withTitle: "魔改 Modded")

        alertType.addButton(withTitle: "取消")

        let typeResponse = alertType.runModal()

        let subDirectoryName: String

        if typeResponse == .alertFirstButtonReturn { subDirectoryName = "Original" }

        else if typeResponse == .alertSecondButtonReturn { subDirectoryName = "Modded" }

        else { statusText = "❌已取消导入"; return }

        let alertCopy = NSAlert()

        alertCopy.messageText = "选择导入方式"

        alertCopy.informativeText = """

        🔗【软链接】速度快，不复制文件；不要移动/删除原始文件夹，否则游戏失效

        📂【复制】完整拷贝游戏到启动器内部，占用额外硬盘空间，不怕改动原文件

        """

        alertCopy.addButton(withTitle: "软链接导入")

        alertCopy.addButton(withTitle: "复制全部文件")

        alertCopy.addButton(withTitle: "取消")

        let copyResponse = alertCopy.runModal()

        let doCopy: Bool

        if copyResponse == .alertFirstButtonReturn { doCopy = false }

        else if copyResponse == .alertSecondButtonReturn { doCopy = true }

        else { statusText = "❌已取消导入"; return }

        let gameLibraryDirectory = appSupport.appendingPathComponent("Games").appendingPathComponent(subDirectoryName)

        do { try FileManager.default.createDirectory(at: gameLibraryDirectory, withIntermediateDirectories: true) }

        catch { statusText = "❌创建目录失败：\(error.localizedDescription)"; return }

        let folderName = realGameFolder.lastPathComponent

        let targetURL = gameLibraryDirectory.appendingPathComponent(folderName)

        if FileManager.default.fileExists(atPath: targetURL.path) {

            let overwriteAlert = NSAlert()

            overwriteAlert.messageText = "已存在同名游戏"

            overwriteAlert.informativeText = "是否覆盖启动器中的现有记录？"

            overwriteAlert.addButton(withTitle: "覆盖")

            overwriteAlert.addButton(withTitle: "取消")

            guard overwriteAlert.runModal() == .alertFirstButtonReturn else { statusText = "❌已取消导入"; return }

            do { try FileManager.default.removeItem(at: targetURL) }

            catch { statusText = "❌无法覆盖旧记录：\(error.localizedDescription)"; return }

        }

        if doCopy {

            do { try FileManager.default.copyItem(at: realGameFolder, to: targetURL); statusText = "✅复制导入成功 → \(subDirectoryName)/\(folderName)" }

            catch { statusText = "❌复制失败：\(error.localizedDescription)"; return }

        } else {

            do { try FileManager.default.createSymbolicLink(at: targetURL, withDestinationURL: realGameFolder); statusText = "✅软链接导入成功 → \(subDirectoryName)/\(folderName)" }

            catch { statusText = "❌创建软链接失败：\(error.localizedDescription)"; return }

        }

        let info = GameInfo(
            gameId: "\(subDirectoryName)-\(folderName)",
            gameType: subDirectoryName == "Original" ? "original" : "mod",
            mainExeName: mainExe.lastPathComponent,
            useSeparateBottle: defaultSeparateBottle,
            trackedSavePath: nil,
            trackingStatus: SaveTrackingStatus.neverLaunched.rawValue,
            lastTrackingUpdate: nil
        )

        saveGameInfo(targetURL, info)

        refreshGames()

    }

    // MARK: - 删除数据

    private func removeGame(_ entry: String) {
        let alert = NSAlert()
        alert.messageText = "确认移除该游戏记录？"
        alert.informativeText = "只会删除启动器中的记录；软链接模式不会删除原始游戏文件。"
        alert.addButton(withTitle: "确认")
        alert.addButton(withTitle: "取消")

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        guard let storage = gameStorage(entry) else {
            statusText = "❌游戏记录无效"
            return
        }

        let fm = FileManager.default

        // ⭐ 先记下 gameId，删 storage 后就拿不到了
        let gameId = loadGameInfo(storage)?.gameId

        do {
            do {
                try fm.removeItem(at: storage)
            } catch CocoaError.fileNoSuchFile {
                // 节点已经不存在时，无需再报错。
            }


            // ⭐ 删追踪记录
            if let gameId {
                SaveTrackingStore.shared.remove(gameId: gameId)
            }

            if selectedGameEntry == entry {
                selectedGameEntry = nil
            }

            refreshGames()
            statusText = "✅已移除游戏记录"

        } catch {
            statusText = "❌移除失败: \(error.localizedDescription)"
        }
    }
    private func removeTool(_ tool: ToolInfo) {
        let alert = NSAlert()
        alert.messageText = "确认删除修改器记录？"
        alert.informativeText = "会同时删除启动器内的修改器副本。"
        alert.addButton(withTitle: "确认")
        alert.addButton(withTitle: "取消")
        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let fm = FileManager.default

        let file = toolsDir.appendingPathComponent("\(tool.toolId).json")
        if fm.fileExists(atPath: file.path) {
            try? fm.removeItem(at: file)
        }

        let toolFolder = toolsDir.appendingPathComponent(tool.toolName)
        if fm.fileExists(atPath: toolFolder.path) {
            try? fm.removeItem(at: toolFolder)
        }

        loadTools()
        if selectedToolId == tool.toolId { selectedToolId = nil }
        statusText = "✅已移除修改器记录"
    }

    // MARK: - 清空 Bottle 面板（V10.1）
    private func showClearBottlePanel() {
        struct BottleEntry {
            let display: String
            let path: URL
        }

        // 1) 公共 Bottle 永远是第一项
        var entries: [BottleEntry] = [
            BottleEntry(display: "公共 Bottle (GlobalBottle)", path: globalBottle)
        ]

        // 2) 识别全部游戏，按它们实际使用的 Bottle 归类
        for entry in gameList {
            guard let storage = gameStorage(entry),
                  let game = loadGameInfo(storage) else { continue }
            let bottle = getBottle(game, storage: storage)
            let kind = game.useSeparateBottle ? "独立 Bottle" : "公共 Bottle"
            entries.append(BottleEntry(display: "\(entry) （\(kind)）", path: bottle))
        }

        let alert = NSAlert()
        alert.messageText = "清空 Bottle"
        alert.informativeText = "选择要清空的 Bottle。\n⚠️ 存档和注册表会丢失，请先导出存档。"
        alert.addButton(withTitle: "清空")
        alert.addButton(withTitle: "取消")

        // 外层容器：全选 + 列表
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 280))

        let selectAllCheckbox = NSButton(checkboxWithTitle: "全选", target: nil, action: nil)
        selectAllCheckbox.state = .off
        selectAllCheckbox.frame = NSRect(x: 8, y: 256, width: 360, height: 20)
        container.addSubview(selectAllCheckbox)

        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.frame = NSRect(x: 0, y: 0, width: 380, height: 248)

        let tableView = NSTableView()
        tableView.headerView = nil
        tableView.rowHeight = 24
        tableView.allowsMultipleSelection = false
        tableView.selectionHighlightStyle = .none

        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("bottle"))
        column.width = 360
        tableView.addTableColumn(column)

        let dataSource = GameCheckboxDataSource(entries: entries.map { $0.display })
        dataSource.tableView = tableView
        tableView.dataSource = dataSource
        tableView.delegate = dataSource

        scroll.documentView = tableView
        container.addSubview(scroll)

        alert.accessoryView = container

        dataSource.selectAllCheckbox = selectAllCheckbox
        selectAllCheckbox.target = dataSource
        selectAllCheckbox.action = #selector(GameCheckboxDataSource.selectAllToggled(_:))

        objc_setAssociatedObject(alert, AssociatedKeys.gameCheckboxDataSource, dataSource, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let selectedDisplays = Set(dataSource.selectedEntries)
        let selectedPaths = Set(
            entries.filter { selectedDisplays.contains($0.display) }.map { $0.path }
        )

        guard !selectedPaths.isEmpty else {
            statusText = "❌未选择任何 Bottle"
            return
        }

        let fm = FileManager.default
        var removed: [String] = []
        var failed: [String] = []

        for path in selectedPaths {
            guard fm.fileExists(atPath: path.path) else { continue }
            do {
                try fm.removeItem(at: path)
                removed.append(path.lastPathComponent)
            } catch {
                failed.append("\(path.lastPathComponent): \(error.localizedDescription)")
            }
        }

        var lines: [String] = []
        if !removed.isEmpty {
            lines.append("✅已清空 \(removed.count) 个 Bottle：\(removed.joined(separator: "、"))")
        }
        if !failed.isEmpty {
            lines.append("❌部分清空失败：")
            lines.append(contentsOf: failed.map { "  • \($0)" })
        }
        if removed.isEmpty && failed.isEmpty {
            lines.append("ℹ️ 所选 Bottle 不存在，无需清空")
        }
        statusText = lines.joined(separator: "\n")
    }


    // MARK: - 程序退出清理

    private func cleanupBeforeTermination() {
        stopAllCaffeinate()

        for process in runningProcesses.values where process.isRunning {
            if let pipe = process.standardOutput as? Pipe {
                pipe.fileHandleForReading.readabilityHandler = nil
            }
            if let pipe = process.standardError as? Pipe {
                pipe.fileHandleForReading.readabilityHandler = nil
            }
            process.terminate()
        }
        // 不再 killall 系统上其他 Wine 进程
    }

    // MARK: - UI

    var body: some View {

        TabView(selection: $selectedTab) {

            VStack(spacing: 18) {

                Text("Yes PVZ Launcher").font(.largeTitle).bold()

                Text("选择版本并启动").font(.title)

                Picker("游戏版本", selection: $selectedGameEntry) {

                    Text("--请选择--").tag(nil as String?)

                    ForEach(gameList, id: \.self) { entry in Text(entry).tag(entry as String?) }

                }.pickerStyle(.menu)

                HStack(spacing: 16) {

                    Button("打开目录") { guard let entry = selectedGameEntry else { statusText = "⚠️请选择游戏"; return }; openGameFolder(entry) }

                    Button("启动游戏") { launchGame() }.buttonStyle(.borderedProminent)

                }

                let tools = toolsForGame()

                if !tools.isEmpty {

                    VStack(spacing: 8) {

                        Text("绑定的修改器").font(.subheadline)

                        Picker("", selection: $selectedToolId) {

                            Text("--选择--").tag(nil as String?)

                            ForEach(tools, id: \.toolId) { tool in Text(tool.toolName).tag(tool.toolId as String?) }

                        }.pickerStyle(.menu)

                        Button("▶ 启动修改器") { launchModifier() }.disabled(selectedToolId == nil)

                    }

                }

                Spacer()

                ScrollView {

                    Text(statusText)

                        .foregroundColor(.secondary)

                        .font(.system(size: 11))

                        .textSelection(.enabled)

                }

                .frame(maxHeight: 100)

            }

            .padding(30)

            .tabItem { Label("启动", systemImage: "play") }

            .tag(0)

            // ✅ 传入共享 library

            DownloadView(showAppDetail: $showAppDetail, selectedGame: $selectedGame, library: sharedLibrary, statusText: statusText)

                .tabItem { Label("下载", systemImage: "square.and.arrow.down") }

                .tag(1)

            // MARK: 管理

            VStack(spacing: 20) {

                Text("游戏管理").font(.title).bold()

                HStack(spacing: 12) {

                    Button("导入游戏") { importGame() }

                    Button("导入修改器") { importModifier() }

                    Button("导出存档") { exportSaveData() }

                    Button("导入存档") { importSaveData() }

                }

                VStack(alignment: .leading) {

                    Text("游戏列表").font(.headline).padding(.bottom, 4)

                    if gameList.isEmpty { Text("暂无游戏").foregroundColor(.secondary).font(.subheadline) }

                    else {

                        ScrollView {

                            VStack(spacing: 8) {

                                ForEach(gameList, id: \.self) { entry in

                                    HStack {

                                        Text(entry)
                                        trackingBadge(for: entry)
                                        Spacer()

                                        Button("在访达中显示") { openGameFolder(entry) }

                                        Button("重新定位存档") {
                                            guard let storage = gameStorage(entry),
                                                  var g = loadGameInfo(storage) else { return }
                                            g.trackingStatus = SaveTrackingStatus.pending.rawValue
                                            g.trackedSavePath = nil
                                            g.lastTrackingUpdate = Date().timeIntervalSince1970
                                            saveGameInfo(storage, g)
                                            SaveTrackingStore.shared.remove(gameId: g.gameId)
                                            statusText = "✅ 已清空「\(entry)」的存档定位，下次启动游戏时重新追踪"
                                            refreshGames()
                                        }

                                        Button("移除") { removeGame(entry) }

                                    }

                                }

                            }

                        }.frame(maxHeight: 180)

                    }

                }

                Divider()

                VStack(alignment: .leading) {

                    Text("修改器列表").font(.headline).padding(.bottom, 4)

                    if toolList.isEmpty { Text("暂无修改器").foregroundColor(.secondary).font(.subheadline) }

                    else {

                        ScrollView {

                            VStack(spacing: 8) {

                                ForEach(toolList, id: \.toolId) { tool in

                                    HStack {

                                        Text(tool.toolName); Spacer()

                                        Button("在访达中显示") {

                                            let url = URL(fileURLWithPath: tool.toolRealPath)

                                            if FileManager.default.fileExists(atPath: url.path) { NSWorkspace.shared.activateFileViewerSelecting([url]) }

                                            else { statusText = "❌修改器文件已被移动或删除" }

                                        }

                                        Button("移除") { removeTool(tool) }

                                    }

                                }

                            }

                        }.frame(maxHeight: 150)

                    }

                }

                Spacer()

                ScrollView {

                    Text(statusText).foregroundColor(.secondary)

                }

                .frame(maxHeight: 100)

            }

            .padding(30)

            .tabItem { Label("管理", systemImage: "folder") }

            .tag(2)

            // MARK: 设置

            ScrollView {

                VStack(spacing: 20) {

                    Text("设置").font(.title).bold()

                    Text("数据目录: \(appSupport.path)").font(.system(size: 11))

                    Button("打开数据文件夹") { NSWorkspace.shared.open(appSupport) }

                    Divider()

                    Text("运行引擎(Wine)").font(.headline)

                    VStack(spacing: 10) {

                        HStack {

                            Button("在线下载安装") { downloadWine() }.disabled(downloader.isDownloading)

                            Button("手动选择安装包") { manualInstall() }

                        }

                        Text("（如您自己使用的引擎安装包无法正常玩游戏，请更换在线下载安装）")

                            .font(.caption).foregroundColor(.secondary)

                        if downloader.isDownloading {

                            HStack {

                                ProgressView(value: downloader.progress).frame(width: 200)

                                Text(String(format: "%.0f%%", downloader.progress * 100)).font(.caption)

                            }

                        }

                        Text(wineReady ? "✅已就绪" : "⚠️未安装")

                        if !wine64Path.isEmpty { Text("Wine: \(wine64Path)").font(.system(size: 10)).foregroundColor(.secondary) }

                    }

                    Divider()

                    Text("偏好设置").font(.headline)

                    VStack(spacing: 10) {

                        Toggle("新游戏默认独立Bottle", isOn: $defaultSeparateBottle)

                        Toggle("Wine调试日志（开启可能导致游戏掉帧）", isOn: $wineDebug)

                    }

                    Divider()

                    Text("防冻结设置").font(.headline)

                    VStack(spacing: 10) {

                        Toggle("系统保活 (Caffeinate)", isOn: $enableKeepAlive)

                        Toggle("强制 OpenGL 渲染 (防后台冻结)", isOn: $forceOpenGLRender)

                        if forceOpenGLRender {
                            Text("⚠️ 开启后走 CPU 软件渲染：CPU 占用会明显升高，部分场景 UI 可能掉帧。仅在遇到后台冻结时开启。")
                                .font(.caption)
                                .foregroundColor(.orange)
                                .fixedSize(horizontal: false, vertical: true)
                        }

                    }

                    Divider()

                    Text("维护").font(.headline)
                    HStack(spacing: 12) {


                        Button("清空 Bottle") {
                            showClearBottlePanel()
                        }.foregroundColor(.red)
                        Button("清除缓存/临时文件") {
                            let alert = NSAlert()
                            alert.messageText = "确认清除？"
                            alert.informativeText = "会清除临时下载文件和图片缓存，不影响游戏、存档和 Wine 引擎。"
                            alert.addButton(withTitle: "确认")
                            alert.addButton(withTitle: "取消")
                            guard alert.runModal() == .alertFirstButtonReturn else { return }

                            let fm = FileManager.default
                            var removed = 0

                            let tmp = fm.temporaryDirectory
                            if let files = try? fm.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil) {
                                for file in files where file.lastPathComponent.hasPrefix("yespvz_wine_") {
                                    if (try? fm.removeItem(at: file)) != nil { removed += 1 }
                                }
                            }
                            URLCache.shared.removeAllCachedResponses()

                            statusText = "✅已清除缓存/临时文件（清理 \(removed) 个临时下载文件）"
                        }.foregroundColor(.red)

                        Button("卸载 Wine 引擎") {
                            let alert = NSAlert()
                            alert.messageText = "确认卸载 Wine 引擎？"
                            alert.informativeText = "会删除 WineEngine 目录。游戏和存档不受影响，但需要重新安装引擎才能启动游戏。"
                            alert.addButton(withTitle: "卸载")
                            alert.addButton(withTitle: "取消")
                            guard alert.runModal() == .alertFirstButtonReturn else { return }

                            let fm = FileManager.default
                            do {
                                if fm.fileExists(atPath: wineFolder.path) {
                                    try fm.removeItem(at: wineFolder)
                                }
                                wineReady = false
                                wine64Path = ""
                                statusText = "✅已卸载 Wine 引擎，请重新安装"
                            } catch {
                                statusText = "❌卸载失败: \(error.localizedDescription)\n路径: \(wineFolder.path)"
                            }
                        }.foregroundColor(.red)

                        Button("重置全部数据") {
                            let alert = NSAlert()
                            alert.messageText = "确认重置？"
                            alert.informativeText = "所有配置将删除"
                            alert.addButton(withTitle: "确认")
                            alert.addButton(withTitle: "取消")
                            if alert.runModal() == .alertFirstButtonReturn {
                                terminateRunningProcesses()
                                do {
                                    if FileManager.default.fileExists(atPath: appSupport.path) {
                                        try FileManager.default.removeItem(at: appSupport)
                                    }
                                    gameList.removeAll()
                                    toolList.removeAll()
                                    selectedGameEntry = nil
                                    selectedToolId = nil
                                    wineReady = false
                                    wine64Path = ""
                                    statusText = "✅已重置，请重启"
                                } catch {
                                    statusText = "❌重置失败: \(error.localizedDescription)"
                                }
                            }
                        }.foregroundColor(.red)
                    }

                    Divider()

                    Text("关于启动器").font(.headline)

                    VStack(spacing: 10) {
                        Text("当前版本:10.0.0")
                            .font(.caption).foregroundColor(.secondary)
                        
                        HStack(spacing: 12) {
                            Button("关于我们工作室") { openExactResourceLink(ResourceLinkConfig.link1) }
                            Button("Github发布页面") { openExactResourceLink(ResourceLinkConfig.link2) }
                            Button("反馈bug") { openExactResourceLink(ResourceLinkConfig.link3) }
                        }
                        .frame(maxWidth: .infinity)
                        
                        // ✅ 新增：第二行HStack，把两个按钮包起来，横向并排
                        HStack(spacing:12) {
                            Button("检查更新") { checkForUpdates() }
                            Toggle("接收预发布版更新（测试版）", isOn: $includePrerelease)
                            Button("用户帮助") { showHelp = true }
                            Button("赞助") { openExactResourceLink(ResourceLinkConfig.link4) }
                        }
                        .frame(maxWidth: .infinity)
                    }

                    

                    Spacer()

                    ScrollView {

                        Text(statusText)

                            .foregroundColor(.secondary)

                            .font(.system(size: 11))

                            .textSelection(.enabled)

                    }

                    .frame(maxHeight: 100)

                }

            }

            .padding(30)

            .tabItem { Label("设置", systemImage: "gearshape") }

            .tag(3)

        }

        .id(resetID)   // ✅ 全局重置视图身份

        .frame(minWidth: 720, minHeight: 620)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

        .toolbar {

            ToolbarItem(placement: .automatic) {

                HStack(spacing: 8) {

                    // 停止按钮：只杀进程（不变）

                    GlassActionButton(systemIcon: "stop.fill", tintColor: .red, isEnabled: hasRunningWineProcess) {

                        terminateRunningProcesses()

                    }

                    // ✅ 刷新按钮：清缓存 + 重置视图 + 重载数据（不动进程）

                    GlassActionButton(systemIcon: "arrow.triangle.2.circlepath", tintColor: .blue, isEnabled: true) {

                        // 1. 清空图片缓存

                        URLCache.shared.removeAllCachedResponses()



                        // 2. 重新加载所有数据

                        sharedLibrary.load(manualRefresh: true)

                        refreshGames()

                        validateAllTrackedPaths()

                        loadTools()
                        wineReady = checkWineReady()

                        // 3. 刷新 Wine 进程状态（保留原有功能）

                        syncWineProcessState(showMessage: true)

                        // 4. 重置选中状态（回到干净状态）

                        selectedGameEntry = nil

                        selectedToolId = nil



                        // 5. 日志反馈

                        appendStatus("🔄 已执行全局刷新（缓存已清空，数据已重载）")

                    }

                }

                .padding(.trailing, 0)

            }

        }

        .sheet(isPresented: $showHelp) {

            HelpView()

        }

        // 已移除 .sheet(isPresented: $showAppDetail)，因为现在由 DownloadView 自己管理

        .onAppear {
            silentCleanupOnLaunch()

            refreshGames()

            validateAllTrackedPaths()

            loadTools()

            wineReady = checkWineReady()

            NotificationCenter.default.addObserver(forName: NSApplication.willTerminateNotification, object: nil, queue: .main) { _ in cleanupBeforeTermination() }

        }

        .onChange(of: gameList) { _, newList in

            if let selected = selectedGameEntry, !newList.contains(selected) { selectedGameEntry = nil; selectedToolId = nil }

        }

        .onChange(of: selectedGameEntry) { _, _ in selectedToolId = nil }

    }

}

// MARK: - 下载页组件（使用共享 library）

struct DownloadView: View {

    @Binding var showAppDetail: Bool

    @Binding var selectedGame: GameItem?

    @ObservedObject var library: RemoteGameLibrary

    @State private var showAllApps = false

    @State private var detailGame: GameItem? = nil

    @State private var searchText = ""

    @State private var isSearching = false

    var statusText: String

    // ✅ 缓存随机数据（只在数据刷新时更新）

    @State private var topBannerItems: [(game: GameItem, index: Int)] = []

    @State private var favoriteGames: [GameItem] = []

    @State private var selectedGames: [GameItem] = []

    @State private var hotGames: [GameItem] = []

    @State private var tweetGames: [GameItem] = []

    @State private var newGames: [GameItem] = []

    var filteredItems: [GameItem] {

        if searchText.isEmpty {

            return library.items

        } else {

            return library.items.filter {

                $0.name.localizedCaseInsensitiveContains(searchText) ||

                String($0.id).localizedCaseInsensitiveContains(searchText)

            }

        }

    }

    // ✅ 重新生成随机选择（只在 library.items 变化或手动刷新时调用）

    private func regenerateRandomSelections() {

        let items = library.items

        guard !items.isEmpty else {

            topBannerItems = []

            favoriteGames = []

            selectedGames = []

            hotGames = []

            tweetGames = []

            newGames = []

            return

        }

        let shuffled = items.shuffled()

        let count = min(8, shuffled.count)

        topBannerItems = (0..<count).map { i in

            let game = shuffled[i]

            let index = [4,5,6,7,8].randomElement()!

            return (game, index)

        }

        favoriteGames = items.shuffled()

        selectedGames = items.shuffled()

        hotGames = items.shuffled()

        tweetGames = items.shuffled()

        newGames = items.shuffled()

    }

    var body: some View {

        ZStack(alignment: .top) {

            // loading 和错误提示

            VStack {

                if library.isLoading {

                    ProgressView("正在拉取游戏库…")

                        .controlSize(.small)

                }

                if let err = library.errorMessage, library.items.isEmpty {

                    Text(err)

                        .foregroundColor(.red)

                    Button("重试加载") {

                        library.load(manualRefresh:true)

                    }

                }

            }

            .padding(.top,80)

            ScrollView {

                VStack(alignment: .leading, spacing: 20) {

                    Color.clear.frame(height: 80)

                    // ✅ 顶部大图 - 使用缓存数据（图文绑定）

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            if topBannerItems.isEmpty {

                                ForEach(0..<8, id: \.self) { _ in

                                    TopBannerCardView(onTap: {})

                                }

                            } else {

                                ForEach(topBannerItems.indices, id: \.self) { idx in

                                    let item = topBannerItems[idx]

                                    let game = item.game

                                    let index = item.index

                                    TopBannerCardView(

                                        imageURL: game.adImageURL(for: index) ?? "",

                                        title: game.subtitle(for: index) ?? game.name,

                                        onTap: {

                                            detailGame = game

                                        }

                                    )

                                }

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    .frame(height: 300)

                    HStack {

                        Text("为你推荐").font(.title3).bold()

                        Spacer()

                        Button("查看全部") { showAllApps = true }

                            .buttonStyle(.plain)

                            .foregroundColor(.blue)

                    }

                    .padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(library.items) { item in

                            CompactAppGridItem(

                                link: item.link,

                                name: item.name,

                                subtitle: item.subtitle,

                                imageURL: item.icon ?? "",

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 小图标区域（8个） - 使用缓存

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = favoriteGames.count >= 8 ? Array(favoriteGames.prefix(8)) : favoriteGames

                            ForEach(display) { item in

                                SmallAppItem(

                                    imageURL: item.icon ?? "",

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 我们喜爱的APP和游戏 - 使用缓存

                    Text("我们喜爱的APP和游戏").font(.title3).bold().padding(.leading)

                    let displayedFavorites = favoriteGames.count >= 9 ? Array(favoriteGames.prefix(9)) : favoriteGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(displayedFavorites) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            ResponsiveAppCard(

                                imageURL: imageURL,

                                name: item.name,

                                subtitle: item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 精选 - 使用缓存

                    Text("精选").font(.title3).bold().padding(.leading)

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = selectedGames.count >= 4 ? Array(selectedGames.prefix(4)) : selectedGames

                            ForEach(display) { item in

                                let previews = item.previews ?? []

                                let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                                let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                                SmallAppItem(

                                    imageURL: imageURL,

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 热门佳作 - 使用缓存

                    Text("热门佳作").font(.title3).bold().padding(.leading)

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = hotGames.count >= 5 ? Array(hotGames.prefix(5)) : hotGames

                            ForEach(display) { item in

                                let previews = item.previews ?? []

                                let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                                let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                                SmallAppItem(

                                    imageURL: imageURL,

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 今日推荐 - 使用缓存

                    Text("今日推荐").font(.title3).bold().padding(.leading)

                    let displayedTweets = tweetGames.count >= 6 ? Array(tweetGames.prefix(6)) : tweetGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 20)], spacing: 20) {

                        ForEach(displayedTweets) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            TweetItem(

                                imageURL: imageURL,

                                title: item.subtitle9 ?? item.name,

                                subtitle: item.subtitle10 ?? item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 新品推荐 - 使用缓存

                    Text("新品推荐").font(.title3).bold().padding(.leading)

                    let displayedNew = newGames.count >= 6 ? Array(newGames.prefix(6)) : newGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(displayedNew) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            ResponsiveAppCard(

                                imageURL: imageURL,

                                name: item.name,

                                subtitle: item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    HStack {

                        Text("为你推荐").font(.title3).bold()

                        Spacer()

                        Button("查看全部") { showAllApps = true }

                            .buttonStyle(.plain)

                            .foregroundColor(.blue)

                    }

                    .padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(library.items) { item in

                            CompactAppGridItem(

                                link: item.link,

                                name: item.name,

                                subtitle: item.subtitle,

                                imageURL: item.icon ?? "",

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                }

                .padding(30)

            }

            .padding(30)

            .sheet(isPresented: $showAllApps) {

                AllAppsListView()

            }

            // ✅ 搜索框（覆盖层）

            VStack(spacing: 0) {

                HStack {

                    Image(systemName: "magnifyingglass")

                        .foregroundColor(.secondary)

                    TextField("搜索游戏名称", text: $searchText, onEditingChanged: { editing in

                        withAnimation(.easeInOut(duration: 0.15)) {

                            isSearching = editing && !searchText.isEmpty

                        }

                    })

                    .textFieldStyle(.plain)

                    .onChange(of: searchText) { _, newValue in

                        withAnimation(.easeInOut(duration: 0.15)) {

                            isSearching = !newValue.isEmpty

                        }

                    }

                    if !searchText.isEmpty {

                        Button(action: {

                            searchText = ""

                            isSearching = false

                        }) {

                            Image(systemName: "xmark.circle.fill")

                                .foregroundColor(.secondary)

                        }

                        .buttonStyle(.plain)

                    }

                }

                .padding(10)

                .background(.ultraThinMaterial)

                .cornerRadius(10)

                .padding(.horizontal, 30)

                .padding(.top, 10)

                if isSearching && !filteredItems.isEmpty {

                    ScrollView {

                        VStack(alignment: .leading, spacing: 4) {

                            ForEach(filteredItems) { item in

                                HStack {

                                    if let url = URL(string: item.icon ?? "") {

                                        CachedAsyncImage(url: url) { phase in

                                            switch phase {

                                            case .success(let image):

                                                image.resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                            default:

                                                Image("placeholder").resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                            }

                                        }

                                    } else {

                                        Image("placeholder").resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                    }

                                    VStack(alignment: .leading, spacing: 2) {

                                        Text(item.name).font(.headline)

                                        Text(item.subtitle).font(.caption).foregroundColor(.secondary)

                                    }

                                    Spacer()

                                    Text(item.subtitle)

                                        .font(.caption)

                                        .foregroundColor(.secondary)

                                        .lineLimit(1)

                                }

                                .padding(.horizontal, 12)

                                .padding(.vertical, 8)

                                .contentShape(Rectangle())

                                .onTapGesture {

                                    detailGame = item

                                    searchText = ""

                                    isSearching = false

                                }

                                Divider()

                            }

                        }

                        .padding(.vertical, 4)

                    }

                    .frame(maxHeight: 250)

                    .background(.regularMaterial)

                    .cornerRadius(10)

                    .padding(.horizontal, 30)

                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)

                } else if isSearching && filteredItems.isEmpty && !searchText.isEmpty {

                    HStack {

                        Text("未找到匹配的游戏")

                            .foregroundColor(.secondary)

                            .padding()

                        Spacer()

                    }

                    .frame(maxWidth: .infinity)

                    .background(.regularMaterial)

                    .cornerRadius(10)

                    .padding(.horizontal, 30)

                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)

                }

                Spacer()

            }

            .padding(.bottom, 0)

        }

        .sheet(item: $detailGame) { game in

            AppDetailView(game: game)

        }

        .onAppear {

            library.load(manualRefresh: false)

            regenerateRandomSelections()

        }

        .onChange(of: library.items) { _, _ in

            regenerateRandomSelections()

        }

    }

}

extension GameItem: Equatable {}//布丁

// MARK: - GameItem 扩展（用于图文绑定）

extension GameItem {

    func subtitle(for index: Int) -> String? {

        switch index {

        case 4: return subtitle4

        case 5: return subtitle5

        case 6: return subtitle6

        case 7: return subtitle7

        case 8: return subtitle8

        default: return nil

        }

    }

    func adImageURL(for index: Int) -> String? {

        let adOffset = index - 3  // 4->1, 5->2, 6->3, 7->4, 8->5

        guard let previews = previews, previews.count >= 5 + adOffset else { return nil }

        return previews[previews.count - 5 + (adOffset - 1)]

    }

}

// MARK: - V9.1.1 远程图片缓存与缩略图解码

private final class RemoteImagePipeline {
    static let shared = RemoteImagePipeline()

    private let memoryCache = NSCache<NSURL, NSImage>()
    private let lock = NSLock()
    private var inFlight: [URL: [(Result<NSImage, Error>) -> Void]] = [:]
    private let session: URLSession

    private init() {
        memoryCache.countLimit = 180
        memoryCache.totalCostLimit = 220 * 1024 * 1024

        let diskCache = URLCache(
            memoryCapacity: 96 * 1024 * 1024,
            diskCapacity: 512 * 1024 * 1024,
            diskPath: "YesPVZLauncherRemoteImages"
        )
        let configuration = URLSessionConfiguration.default
        configuration.urlCache = diskCache
        configuration.requestCachePolicy = .returnCacheDataElseLoad
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 60
        configuration.httpMaximumConnectionsPerHost = 6
        session = URLSession(configuration: configuration)
    }

    func cachedImage(for url: URL) -> NSImage? {
        memoryCache.object(forKey: url as NSURL)
    }

    func load(
        _ url: URL,
        maxPixelSize: CGFloat = 2400,
        completion: @escaping (Result<NSImage, Error>) -> Void
    ) {
        if let image = cachedImage(for: url) {
            completion(.success(image))
            return
        }

        lock.lock()
        if inFlight[url] != nil {
            inFlight[url]?.append(completion)
            lock.unlock()
            return
        }
        inFlight[url] = [completion]
        lock.unlock()

        var request = URLRequest(url: url)
        request.cachePolicy = .returnCacheDataElseLoad
        request.timeoutInterval = 20

        session.dataTask(with: request) { [weak self] data, _, error in
            guard let self else { return }

            let result: Result<NSImage, Error>
            if let error {
                result = .failure(error)
            } else if let data, let image = self.downsample(data: data, maxPixelSize: maxPixelSize) {
                let cost = max(1, Int(image.size.width * image.size.height * 4))
                self.memoryCache.setObject(image, forKey: url as NSURL, cost: cost)
                result = .success(image)
            } else {
                result = .failure(NSError(
                    domain: "YesPVZLauncher.RemoteImage",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "图片数据无法解析"]
                ))
            }

            self.lock.lock()
            let callbacks = self.inFlight.removeValue(forKey: url) ?? []
            self.lock.unlock()

            DispatchQueue.main.async {
                callbacks.forEach { $0(result) }
            }
        }.resume()
    }

    func prefetch(_ urls: [URL]) {
        for url in urls.prefix(24) {
            if cachedImage(for: url) != nil { continue }
            load(url, maxPixelSize: 1400) { _ in }
        }
    }

    private func downsample(data: Data, maxPixelSize: CGFloat) -> NSImage? {
        let options: [CFString: Any] = [
            kCGImageSourceShouldCache: false
        ]
        guard let source = CGImageSourceCreateWithData(data as CFData, options as CFDictionary) else {
            return NSImage(data: data)
        }

        let downsampleOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
        ]

        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(
            source,
            0,
            downsampleOptions as CFDictionary
        ) else {
            return NSImage(data: data)
        }

        return NSImage(
            cgImage: cgImage,
            size: NSSize(width: cgImage.width, height: cgImage.height)
        )
    }
}

private final class CachedImageLoader: ObservableObject {
    @Published var phase: AsyncImagePhase = .empty

    private var representedURL: URL?

    func load(url: URL?) {
        guard representedURL != url else { return }
        representedURL = url

        guard let url else {
            phase = .empty
            return
        }

        if let cached = RemoteImagePipeline.shared.cachedImage(for: url) {
            phase = .success(Image(nsImage: cached))
            return
        }

        phase = .empty
        RemoteImagePipeline.shared.load(url) { [weak self] result in
            guard let self, self.representedURL == url else { return }
            switch result {
            case .success(let image):
                self.phase = .success(Image(nsImage: image))
            case .failure(let error):
                self.phase = .failure(error)
            }
        }
    }
}

private struct CachedAsyncImage<Content: View>: View {
    let url: URL?
    let content: (AsyncImagePhase) -> Content

    @StateObject private var loader = CachedImageLoader()

    init(url: URL?, @ViewBuilder content: @escaping (AsyncImagePhase) -> Content) {
        self.url = url
        self.content = content
    }

    var body: some View {
        content(loader.phase)
            .onAppear { loader.load(url: url) }
            .onChange(of: url) { _, newURL in
                loader.load(url: newURL)
            }
    }
}

// macOS 触控板两指横向滑动支持。事件仍返回系统，不阻断普通鼠标/键盘操作。
private struct HorizontalScrollSwipeMonitor: NSViewRepresentable {
    let onPrevious: () -> Void
    let onNext: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPrevious: onPrevious, onNext: onNext)
    }

    func makeNSView(context: Context) -> NSView {
        let view = NSView(frame: .zero)
        DispatchQueue.main.async { context.coordinator.start() }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        context.coordinator.onPrevious = onPrevious
        context.coordinator.onNext = onNext
    }

    static func dismantleNSView(_ nsView: NSView, coordinator: Coordinator) {
        coordinator.stop()
    }

    final class Coordinator {
        var onPrevious: () -> Void
        var onNext: () -> Void
        private var monitor: Any?
        private var accumulatedX: CGFloat = 0
        private var lastTrigger = Date.distantPast

        init(onPrevious: @escaping () -> Void, onNext: @escaping () -> Void) {
            self.onPrevious = onPrevious
            self.onNext = onNext
        }

        func start() {
            guard monitor == nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                guard let self else { return event }

                let x = event.scrollingDeltaX
                let y = event.scrollingDeltaY
                guard abs(x) > abs(y), abs(x) > 0.1 else { return event }

                accumulatedX += x
                let now = Date()
                guard now.timeIntervalSince(lastTrigger) > 0.28 else { return event }

                if accumulatedX <= -55 {
                    accumulatedX = 0
                    lastTrigger = now
                    onNext()
                } else if accumulatedX >= 55 {
                    accumulatedX = 0
                    lastTrigger = now
                    onPrevious()
                }

                if event.phase == .ended || event.momentumPhase == .ended {
                    accumulatedX = 0
                }
                return event
            }
        }

        func stop() {
            if let monitor {
                NSEvent.removeMonitor(monitor)
                self.monitor = nil
            }
        }

        deinit { stop() }
    }
}

// MARK: - 放大图片后的 Mac 触控板平移监听
// 仅在图片已经放大时启用。
// 这里不负责翻页，只把两指滚动增量累加到当前图片位置，
// 因此不会出现上一版那种“重新落指后跳回头部”的问题。
private struct ZoomedImageTrackpadPanMonitor: NSViewRepresentable {
    let isEnabled: Bool
    let onScroll: (CGFloat, CGFloat) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(isEnabled: isEnabled, onScroll: onScroll)
    }

    func makeNSView(context: Context) -> NSView {
        let view = NSView(frame: .zero)
        DispatchQueue.main.async {
            context.coordinator.start()
        }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        context.coordinator.isEnabled = isEnabled
        context.coordinator.onScroll = onScroll
    }

    static func dismantleNSView(_ nsView: NSView, coordinator: Coordinator) {
        coordinator.stop()
    }

    final class Coordinator {
        var isEnabled: Bool
        var onScroll: (CGFloat, CGFloat) -> Void
        private var monitor: Any?

        init(isEnabled: Bool, onScroll: @escaping (CGFloat, CGFloat) -> Void) {
            self.isEnabled = isEnabled
            self.onScroll = onScroll
        }

        func start() {
            guard monitor == nil else { return }

            monitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                guard let self, self.isEnabled else { return event }

                let dx = event.scrollingDeltaX
                let dy = event.scrollingDeltaY

                guard abs(dx) > 0.01 || abs(dy) > 0.01 else {
                    return event
                }

                // 在放大状态下，两指滚动只移动当前图片，不交给外层分页 ScrollView。
                self.onScroll(dx, dy)
                return nil
            }
        }

        func stop() {
            if let monitor {
                NSEvent.removeMonitor(monitor)
                self.monitor = nil
            }
        }

        deinit {
            stop()
        }
    }
}

// MARK: - App 详情页

struct AppDetailView: View {
    @Environment(\.dismiss) private var dismiss

    let game: GameItem?

    @State private var selectedPreviewIndex: Int? = nil

    // 当前图片缩放状态。
    @State private var previewScale: CGFloat = 1
    @State private var previewLastScale: CGFloat = 1



    // 放大后的图片平移。
    @State private var previewPanOffset: CGSize = .zero
    @State private var previewPanBase: CGSize = .zero
    // 鼠标在 galleryPage 本地坐标里的位置（左上角为原点）
    @State private var currentMouseLocation: CGPoint = .zero

    init(game: GameItem? = nil) {
        self.game = game
    }

    private var detailPreviews: [String] {
        Array((game?.previews ?? []).prefix(5))
    }

    private func resetPreviewTransform(animated: Bool = false) {
        let update = {
            previewScale = 1
            previewLastScale = 1
            previewPanOffset = .zero
            previewPanBase = .zero
        }

        if animated {
            withAnimation(.spring(response: 0.26, dampingFraction: 0.86)) {
                update()
            }
        } else {
            update()
        }
    }

    private func openPreview(_ index: Int) {
        guard detailPreviews.indices.contains(index) else { return }
        resetPreviewTransform()
        selectedPreviewIndex = index
    }

    private func closePreview() {
        resetPreviewTransform()
        withAnimation(.easeOut(duration: 0.14)) {
            selectedPreviewIndex = nil
        }
    }

    private func previousPreview() {
        guard previewScale <= 1.01,
              let index = selectedPreviewIndex,
              index > 0 else { return }

        resetPreviewTransform()
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedPreviewIndex = index - 1
        }
    }

    private func nextPreview() {
        guard previewScale <= 1.01,
              let index = selectedPreviewIndex,
              index < detailPreviews.count - 1 else { return }

        resetPreviewTransform()
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedPreviewIndex = index + 1
        }
    }

    private func clampPan(_ proposed: CGSize, size: CGSize) -> CGSize {
            guard previewScale > 1 else { return .zero }

            let frameW = max(240, size.width  - 120)
            let frameH = max(240, size.height - 70)

            // 拿当前图片真实宽高比
            let urlString: String = {
                guard let i = selectedPreviewIndex,
                      detailPreviews.indices.contains(i) else { return "" }
                return detailPreviews[i]
            }()
            let nsImage = URL(string: urlString)
                .flatMap { RemoteImagePipeline.shared.cachedImage(for: $0) }
            let imgAspect: CGFloat = {
                guard let img = nsImage, img.size.height > 0 else {
                    return frameW / frameH   // 缓存未命中：退化成铺满 frame
                }
                return img.size.width / img.size.height
            }()

            // 图片在 frame 内 scaledToFit 之后的实际渲染尺寸
            let frameAspect = frameW / frameH
            let imgW: CGFloat
            let imgH: CGFloat
            if imgAspect > frameAspect {
                imgW = frameW
                imgH = frameW / imgAspect
            } else {
                imgH = frameH
                imgW = frameH * imgAspect
            }

            // 缩放后图片的实际尺寸
            let scaledW = imgW * previewScale
            let scaledH = imgH * previewScale

            // 左右一包：图片宽没超窗口 → 锁死居中；超了 → 允许滑但边缘不进来
            let maxX = max(0, (scaledW - size.width)  / 2)
            // 上下一包：图片高没超窗口 → 锁死居中；超了 → 允许滑但边缘不进来
            let maxY = max(0, (scaledH - size.height) / 2)

            return CGSize(
                width:  min(max(proposed.width,  -maxX), maxX),
                height: min(max(proposed.height, -maxY), maxY)
            )
        }

    var body: some View {
        ZStack {
            detailPage
                .allowsHitTesting(selectedPreviewIndex == nil)

            if let index = selectedPreviewIndex,
               detailPreviews.indices.contains(index) {
                previewOverlay
                    .transition(.opacity)
                    .zIndex(100)
            }
        }
        .frame(minWidth: 600, minHeight: 500)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(nsColor: .windowBackgroundColor))
        .onChange(of: selectedPreviewIndex) { _, newValue in
            if newValue != nil {
                resetPreviewTransform()
            }
        }
    }

    // MARK: 普通详情页

    private var detailPage: some View {
        HStack(spacing: 0) {
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
                .padding()

                Spacer()
            }
            .frame(width: 60)

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let game {
                        Group {
                            HStack {
                                if let url = URL(string: game.icon ?? "") {
                                    CachedAsyncImage(url: url) { phase in
                                        switch phase {
                                        case .success(let image):
                                            image
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 60, height: 60)
                                                .cornerRadius(12)
                                        default:
                                            Image("placeholder")
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 60, height: 60)
                                                .cornerRadius(12)
                                        }
                                    }
                                } else {
                                    Image("placeholder")
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 60, height: 60)
                                        .cornerRadius(12)
                                }

                                VStack(alignment: .leading) {
                                    Text(game.name)
                                        .font(.title)
                                        .bold()

                                    Text(game.subtitle)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }

                                Spacer()

                                Button("下载") {
                                    if let url = URL(string: game.link) {
                                        NSWorkspace.shared.open(url)
                                    }
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding()

                            Divider()

                            Text(game.subtitle2 ?? game.subtitle)
                                .padding()

                            Divider()

                            if !detailPreviews.isEmpty {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 12) {
                                        ForEach(Array(detailPreviews.enumerated()), id: \.offset) { index, urlString in
                                            Button {
                                                openPreview(index)
                                            } label: {
                                                if let url = URL(string: urlString) {
                                                    CachedAsyncImage(url: url) { phase in
                                                        switch phase {
                                                        case .success(let image):
                                                            image
                                                                .resizable()
                                                                .scaledToFit()
                                                                .frame(height: 200)
                                                                .cornerRadius(12)
                                                        default:
                                                            Image("placeholder")
                                                                .resizable()
                                                                .scaledToFit()
                                                                .frame(height: 200)
                                                                .cornerRadius(12)
                                                        }
                                                    }
                                                } else {
                                                    Image("placeholder")
                                                        .resizable()
                                                        .scaledToFit()
                                                        .frame(height: 200)
                                                        .cornerRadius(12)
                                                }
                                            }
                                            .buttonStyle(.plain)
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                                .padding(.vertical, 8)
                            } else if let url = URL(string: game.icon ?? "") {
                                CachedAsyncImage(url: url) { phase in
                                    switch phase {
                                    case .success(let image):
                                        image
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxHeight: 300)
                                            .cornerRadius(12)
                                    default:
                                        Image("placeholder")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxHeight: 300)
                                            .cornerRadius(12)
                                    }
                                }
                                .padding()
                            } else {
                                Image("placeholder")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxHeight: 300)
                                    .cornerRadius(12)
                                    .padding()
                            }
                        }
                        .id(game.id)
                    } else {
                        HStack {
                            Image("placeholder")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .cornerRadius(12)

                            VStack(alignment: .leading) {
                                Text("应用名称").font(.title).bold()
                                Text("免费，无内购").font(.caption).foregroundColor(.secondary)
                            }

                            Spacer()

                            Button("下载") { }
                                .buttonStyle(.borderedProminent)
                        }
                        .padding()

                        Divider()
                        Text("游戏简介（占位符）").padding()
                        Divider()

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(0..<5, id: \.self) { _ in
                                    Image("placeholder")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxHeight: 200)
                                        .cornerRadius(12)
                                }
                            }
                        }
                        .padding()
                    }
                }
                .padding()
            }
        }
    }

    // MARK: 微信式图片查看器

    @ViewBuilder
    private var previewOverlay: some View {
        GeometryReader { geometry in
            ZStack {
                Color(nsColor: .underPageBackgroundColor)
                    .opacity(0.98)
                    .ignoresSafeArea()

                if #available(macOS 14.0, *) {
                    modernPagedGallery(size: geometry.size)
                } else {
                    fallbackPagedGallery(size: geometry.size)
                }

                galleryNavigationButtons
                    .zIndex(30)

                galleryCloseButton
                    .zIndex(31)

                galleryPageIndicator
                    .zIndex(31)

                // 图片放大以后，Mac 触控板两指滚动 = 移动当前图片。
                ZoomedImageTrackpadPanMonitor(
                    isEnabled: previewScale > 1.01,
                    onScroll: { dx, dy in
                        let proposed = CGSize(
                            width: previewPanOffset.width + dx,
                            height: previewPanOffset.height + dy
                        )
                        let clamped = clampPan(proposed, size: geometry.size)
                        previewPanOffset = clamped
                        previewPanBase = clamped
                    }
                )
                .frame(width: 1, height: 1)
                .allowsHitTesting(false)
                .zIndex(40)
            }
        }
    }

    @available(macOS 14.0, *)
    @ViewBuilder
    private func modernPagedGallery(size: CGSize) -> some View {
        ScrollView(.horizontal) {
            LazyHStack(spacing: 0) {
                ForEach(Array(detailPreviews.enumerated()), id: \.offset) { index, urlString in
                    galleryPage(
                        index: index,
                        urlString: urlString,
                        size: size
                    )
                    .frame(width: size.width, height: size.height)
                    .id(index)
                    .onContinuousHover { phase in
                        if case .active(let loc) = phase {
                            currentMouseLocation = loc
                        }
                    }
                }
            }
            .scrollTargetLayout()
        }
        .scrollIndicators(.hidden)
        .scrollTargetBehavior(.paging)
        .scrollPosition(id: $selectedPreviewIndex)
        // 关键：图片一旦放大，彻底关闭分页滚动。
        .scrollDisabled(previewScale > 1.01)
    }

    @ViewBuilder
    private func fallbackPagedGallery(size: CGSize) -> some View {
        if let index = selectedPreviewIndex,
           detailPreviews.indices.contains(index) {
            galleryPage(
                index: index,
                urlString: detailPreviews[index],
                size: size
            )
            .frame(width: size.width, height: size.height)
        }
    }

    @ViewBuilder
    private func galleryPage(index: Int, urlString: String, size: CGSize) -> some View {
        ZStack {
            // 灰色空白区点击退出。
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    closePreview()
                }
            
            if let url = URL(string: urlString) {
                CachedAsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        galleryLoadedImage(
                            image,
                            pageIndex: index,
                            size: size
                        )
                        
                    case .failure:
                        Image(systemName: "photo.badge.exclamationmark")
                            .font(.system(size: 38))
                            .foregroundColor(.secondary)
                        
                    default:
                        // 无文字、无“高清图片”提示，只保留系统最小加载指示。
                        ProgressView()
                            .controlSize(.small)
                    }
                }
            } else {
                Image("placeholder")
                    .resizable()
                    .scaledToFit()
                    .frame(
                        width: max(240, size.width - 120),
                        height: max(240, size.height - 70)
                    )
            }
        }
        .frame(width: size.width, height: size.height)
        // ⭐️ 新增：跟踪鼠标在 page 本地坐标里的位置
        .onContinuousHover { phase in
            if case .active(let loc) = phase {
                currentMouseLocation = loc
            }
        }
    }
    @ViewBuilder
    private func galleryLoadedImage(_ image: Image, pageIndex: Int, size: CGSize) -> some View {
        let isCurrent = pageIndex == selectedPreviewIndex

        let baseImage = image
            .resizable()
            .scaledToFit()
            .frame(
                width: max(240, size.width - 120),
                height: max(240, size.height - 70)
            )
            .scaleEffect(
                isCurrent ? previewScale : 1,
                anchor: .center
            )
            .offset(
                x: isCurrent ? previewPanOffset.width : 0,
                y: isCurrent ? previewPanOffset.height : 0
            )
            .shadow(
                color: .black.opacity(0.26),
                radius: 16,
                x: 0,
                y: 6
            )
            // 双击：从鼠标位置撑开 / 还原回中心
            .highPriorityGesture(
                SpatialTapGesture(count: 2)
                    .onEnded { value in
                        guard isCurrent else { return }

                        if previewScale > 1.01 {
                            // 还原：平移回中心 + 缩回 100%
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.86)) {
                                previewScale = 1
                                previewLastScale = 1
                                previewPanOffset = .zero
                                previewPanBase = .zero
                            }
                        } else {
                            // 放大：从鼠标位置撑开，等价于原来的 scaleEffect(anchor:) 版
                            let imageWidth  = max(240, size.width  - 120)
                            let imageHeight = max(240, size.height - 70)

                            let dx = value.location.x - imageWidth  / 2
                            let dy = value.location.y - imageHeight / 2

                            // ratio = 2，oldOffset = 0
                            // newOffset = (1 - ratio) * (dx, dy) = (-dx, -dy)
                            let newOffset = CGSize(width: -dx, height: -dy)

                            previewPanBase = newOffset
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.86)) {
                                previewScale = 2
                                previewLastScale = 2
                                previewPanOffset = newOffset
                            }
                        }
                    }
            )
            // 捏合：围绕鼠标位置缩放，鼠标下的点保持不动
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { value in
                        guard isCurrent else { return }

                        let oldScale = previewScale
                        let newScale = min(max(previewLastScale * value, 1), 4)

                        if newScale <= 1.01 {
                            previewScale = 1
                            previewLastScale = 1   // ⭐️ 就加这一行
                            previewPanOffset = .zero
                            previewPanBase = .zero
                            return
                        }

                        guard oldScale > 0.01,
                              abs(newScale - oldScale) > 0.0001 else {
                            previewScale = newScale
                            return
                        }

                        // ⭐️ 鼠标相对 page 中心的位置
                        let M = CGPoint(
                            x: currentMouseLocation.x - size.width  / 2,
                            y: currentMouseLocation.y - size.height / 2
                        )

                        // ⭐️ newOffset = M * (1 - ratio) + oldOffset * ratio
                        let ratio = newScale / oldScale
                        let newOffset = CGSize(
                            width:  M.x * (1 - ratio) + previewPanOffset.width  * ratio,
                            height: M.y * (1 - ratio) + previewPanOffset.height * ratio
                        )

                        previewScale = newScale
                        let clamped = clampPan(newOffset, size: size)
                        previewPanOffset = clamped
                        previewPanBase = clamped
                    }
                    .onEnded { _ in
                        guard isCurrent else { return }
                        if previewScale < 1.06 {
                            resetPreviewTransform(animated: true)
                        } else {
                            previewLastScale = previewScale
                            let clamped = clampPan(previewPanOffset, size: size)
                            previewPanOffset = clamped
                            previewPanBase = clamped
                        }
                    }
            )

        if isCurrent && previewScale > 1.01 {
            baseImage
                .gesture(
                    DragGesture(minimumDistance: 1)
                        .onChanged { value in
                            let proposed = CGSize(
                                width:  previewPanBase.width  + value.translation.width,
                                height: previewPanBase.height + value.translation.height
                            )
                            previewPanOffset = clampPan(proposed, size: size)                        }
                        .onEnded { _ in
                            previewPanBase = previewPanOffset
                        }
                )
        } else {
            baseImage
        }
    }

    private var galleryNavigationButtons: some View {
        HStack {
            Button(action: previousPreview) {
                ZStack {
                    Circle()
                        .fill(Color.black.opacity(0.56))
                        .frame(width: 44, height: 44)

                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .buttonStyle(.plain)
            .disabled((selectedPreviewIndex ?? 0) <= 0 || previewScale > 1.01)
            .opacity((selectedPreviewIndex ?? 0) <= 0 ? 0.28 : (previewScale > 1.01 ? 0.42 : 1))

            Spacer()

            Button(action: nextPreview) {
                ZStack {
                    Circle()
                        .fill(Color.black.opacity(0.56))
                        .frame(width: 44, height: 44)

                    Image(systemName: "chevron.right")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .buttonStyle(.plain)
            .disabled(
                (selectedPreviewIndex ?? 0) >= detailPreviews.count - 1 ||
                previewScale > 1.01
            )
            .opacity(
                (selectedPreviewIndex ?? 0) >= detailPreviews.count - 1
                ? 0.28
                : (previewScale > 1.01 ? 0.42 : 1)
            )
        }
        .padding(.horizontal, 18)
    }

    private var galleryCloseButton: some View {
        VStack {
            HStack {
                Spacer()

                Button(action: closePreview) {
                    ZStack {
                        Circle()
                            .fill(Color.black.opacity(0.60))
                            .frame(width: 38, height: 38)

                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
                .buttonStyle(.plain)
            }

            Spacer()
        }
        .padding(16)
    }

    private var galleryPageIndicator: some View {
        VStack {
            Spacer()

            if let index = selectedPreviewIndex {
                HStack(spacing: 8) {
                    Text("\(index + 1) / \(detailPreviews.count)")
                        .font(.caption.monospacedDigit())

                    if previewScale > 1.01 {
                        Text("\(Int(previewScale * 100))%")
                            .font(.caption.monospacedDigit())
                    }
                }
                .foregroundColor(.primary)
                .padding(.horizontal, 11)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .padding(.bottom, 12)
            }
        }
    }
}

// MARK: - 其他组件（已改为支持动态数据）

struct ResponsiveAppCard: View {

    var imageURL: String = ""

    var name: String = "应用名称"

    var subtitle: String = "免费，无内购"

    var onTap: () -> Void = {}

    var body: some View {

        ZStack(alignment: .bottomLeading) {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image

                            .resizable()

                            .scaledToFill()

                            .frame(height: 120)

                            .clipped()

                            .cornerRadius(10)

                    default:

                        Image("placeholder")

                            .resizable()

                            .scaledToFill()

                            .frame(height: 120)

                            .clipped()

                            .cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder")

                    .resizable()

                    .scaledToFill()

                    .frame(height: 120)

                    .clipped()

                    .cornerRadius(10)

            }

            LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.6)], startPoint: .top, endPoint: .bottom)

                .frame(height: 80)

                .cornerRadius(10)

            VStack(alignment: .leading) {

                Text(name)

                    .font(.headline)

                    .foregroundColor(.white)

                Text(subtitle)

                    .font(.caption)

                    .foregroundColor(.white.opacity(0.8))

            }

            .padding(8)

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct SmallAppItem: View {

    var imageURL: String = ""

    var name: String = "应用名称"

    var onTap: () -> Void = {}

    var body: some View {

        VStack {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFit().frame(height: 60).cornerRadius(10)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(height: 60).cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(height: 60).cornerRadius(10)

            }

            Text(name).font(.caption)

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct TweetItem: View {

    var imageURL: String = ""

    var title: String = "推文标题"

    var subtitle: String = "推文简介"

    var onTap: () -> Void = {}

    var body: some View {

        HStack {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

            }

            VStack(alignment: .leading) {

                Text(title).bold()

                Text(subtitle).font(.caption).foregroundColor(.secondary)

            }

            Spacer()

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct CompactAppGridItem: View {

    var link: String = ""

    var name: String = "应用名称"

    var subtitle: String = "免费，无内购"

    var imageURL: String = ""

    var onTap: () -> Void = {}

    var body: some View {

        HStack(spacing: 8) {

            if let url = URL(string: imageURL) {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFill().frame(width: 40, height: 40).cornerRadius(8)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(width: 40, height: 40).cornerRadius(8)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(width: 40, height: 40).cornerRadius(8)

            }

            VStack(alignment: .leading) {

                Text(name).font(.headline)

                Text(subtitle).font(.caption).foregroundColor(.secondary)

            }

            Spacer(minLength: 4)

            Button("下载") {

                if let url = URL(string: link) {

                    NSWorkspace.shared.open(url)

                }

            }

            .buttonStyle(.borderedProminent)

            .controlSize(.small)

        }

        .padding(10)

        .background(Color.gray.opacity(0.05))

        .cornerRadius(12)

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct TopBannerCardView: View {

    var imageURL: String = ""

    var title: String = "精选大图"

    var onTap: () -> Void = {}

    var body: some View {

        ZStack(alignment: .bottomLeading) {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image

                            .resizable()

                            .scaledToFill()

                            .frame(width: 700, height: 300)

                            .clipped()

                    default:

                        Image("placeholder")

                            .resizable()

                            .scaledToFill()

                            .frame(width: 700, height: 300)

                            .clipped()

                    }

                }

            } else {

                Image("placeholder")

                    .resizable()

                    .scaledToFill()

                    .frame(width: 700, height: 300)

                    .clipped()

            }

            LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.6)], startPoint: .top, endPoint: .bottom)

            Text(title)

                .font(.title)

                .bold()

                .foregroundColor(.white)

                .padding()

        }

        .frame(width: 700, height: 300)

        .cornerRadius(12)

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

// MARK: - 帮助视图

struct HelpView: View {

    @Environment(\.dismiss) private var dismiss

    var body: some View {

        VStack(alignment: .leading) {

            Text("帮助中心").font(.title2).bold().padding()

            Divider()

            ScrollView {

                Text("""

                📖 【关于此启动器】

                当前版本: 10.0.0

                本启动器适用于在 macOS 上运行植物大战僵尸的大多数版本。
                
                感谢/致谢:

                VICTORY工作室(VICTORY Studio)：主开发者

                AI:Deepseek(deepseek.com):最终V6,V7,V8,V9,V10的开发辅助、豆包(doula.com/doubao.com)：前期V1,V2的开发辅助、ChatGPT(chatgpt.com):V3,V4,V5的开发辅助

                新手向导来来！：
                
                来来今天叫你如何快捷上手该启动器，注意听好喽！⎜（‘o’）⎜注意听讲！
                第一次使用先进入下载页面获取植物大战僵尸原版或改版或者是用你自己的文件（必须是Windows版的文件）在管理页面点击导入游戏导入你的游戏。进入设置点击在线下载安装之后等待下载完成即可回到启动界面，点击选择游戏后等待几秒即可正常游玩。
                下面是一些新手问题：
                游戏的字体变成｜｜｜：后续即将修复已找到办法
                无法启动报错53:去设置清空bottle
                
                实用帮助:
                
                启动时退出且退出码为53通常由Bottle前缀损坏或下载/解压的引擎包不完整导致:请您使用设置里的删除残留文件。如无效请使用复制导入游戏即使已经修了这个bug（保存好您的存档）

                游侠汉化V2及基于此版本的改版的"竖杠/方块"字体问题:V2完全绕过Windows标准GDI，直接调用DirectDraw读取自定义的font.bin和font.dds。在M4芯片上，Wine内部计算Pitch（行跨度）与原生Windows有微小差异，且无法加载第三方dxwrapper/ddraw.dll补丁。结论：无解，只能直接放弃V2，使用V1汉化版或基于V1标准字体的魔改版。

                若你的改版是安装器exe:在Mac上使用第三方解压工具解压或导入游戏后再安装到桌面及其他地方（不要用默认路径）

                日志太多导致游戏卡死或掉帧:请您关掉设置中的调试日志开关。

                Bug列表:

                      🔴严重/无法修复(属于目前无法解决):

                        1.游侠汉化V2的"竖杠/方块"字体问题:V2完全绕过Windows标准GDI，直接调用DirectDraw读取自定义的font.bin和font.dds。在M4芯片上，Wine内部计算Pitch（行跨度）与原生Windows有微小差异，且无法加载第三方dxwrapper/ddraw.dll补丁。结论：无解，只能直接放弃V2，使用V1汉化版或基于V1标准字体的魔改版。

                        2.退出码:53（Kernel32.dll加载失败）：高频触发，通常由Bottle前缀损坏或下载/解压的引擎包不完整导致:请您使用设置里的删除残留文件（老办法）或重建bottle即使已经修了这个bug（保存好您的存档)

                        3.特定引擎的"后台失焦冻结"（切后台超过2秒，连音乐都停止）：这是特定Wine引擎的硬伤，Caffeinate和强制OpenGL只能缓解。后期解决方法研发中。

                      🟡 中等/不稳定（容易引发严重Bug，需谨慎操作或未解决）

                        4.在线下载引擎不稳定：因地址为GitHub链接所以在国内有概率失败或卡死，不要频繁使用在线下载,最好用的安装包地址:https://github.com/frankea/Whisky/releases/download/v4.5.105-beta.1/Libraries.tar.gz

                      5.存档丢失风险：清空全局Bottle或重置全部数据会直接删除用户存档，做了"导出/导入存档"的功能。

                      6.修改器多开偶发冲突：虽然加了复制修改器到独立Bottle的逻辑，但部分老修改器依赖窗口句柄检测，在多开复制模式下偶尔找不到游戏或导致轻微掉帧，这种属于修改器自身底层逻辑限制。

                      🟢 已解决/轻微（已优化或正常）

                       7.界面按钮命名不清晰（已解决）：管理页的"打开"和"打开位置"全部改成了"在访达中显示"。

                       8.修改器列表倒序（已解决）：去掉了 reversed()，现在从上往下正常排列。

                      9.游戏与修改器共用容器冲突（已解决）：V7加入了修改器自动复制到独立 Bottle 的逻辑，支持多开防冲突。

                       10.日志刷屏导致 UI 卡死（已解决）：加入了日志过滤、防爆内存截断，以及停止按钮的双重保障（优雅终止 + Killall -9）。

                       11.停止按钮没反应/卡死停不下来:和上一报告bug使用同一解决方式

                       12.丢失"新游戏默认独立Bottle"开关（已解决）：在设置界面成功找回并恢复了。

                       13.设置界面窗口限制（已解决）：整个设置页面已改为整体可滚动滑动，日志区域也正常恢复了（短消息居中，长日志自动靠左）。

                       14.按钮排版（已优化）：关于启动器的前三行按钮（关于、GitHub、反馈）已调整为同一行居中，帮助按钮单独放在下一行触发新窗口。

                       15.日志卡死/掉帧（已解决）：加入了精准的关键日志过滤和0.15秒节流，开启调试日志不再直接卡死。

                       16.进程标识冲突（已解决）：游戏与修改器共用同一个进程标识，导致修改器退出时会误删游戏的运行记录。已改为游戏和修改器使用独立的进程标识。

                       17.退出清理误杀（已解决）：关闭启动器时会调用 killall 强制终止系统上所有 Wine 进程，导致 Whisky、CrossOver 等被误杀。已改为只终止本启动器自己启动的进程。

                       18.首次启动失败（已解决）：runWine 中调用了 wineboot 初始化 Bottle，但 Whisky 引擎包内不含 wineboot，导致首次启动直接报错"找不到 wineboot"。已回退到 9.1.6 的实现方式，由 Wine 隐式初始化。

                       19.共用存档状态循环（已解决）：共用存档的游戏标记为 shared 后不写回 trackedSavePath，导致下次启动时被校验逻辑改回 pending，追踪状态无限循环。已在写回条件中增加 shared 分支。

                       20.修改器重复条目（已解决）：修改器同名覆盖时只替换文件夹，旧 JSON 未删除，列表中同时出现两条同名修改器。已改为覆盖确认通过后先删旧记录。

                       21.修改器残留文件（已解决）：移除修改器记录时只删 JSON，磁盘上的 Tools/修改器名/ 文件夹仍然保留。已改为同时删除实际文件夹。

                       22.追踪记录残留（已解决）：移除游戏记录时未删除 SaveTracking 下对应的 JSON。已改为同步删除。

                       23.修改器导入方式（已优化）：原本只能选择单个 exe，无法处理带配置文件的修改器。已改为选择文件夹，完整复用游戏导入流程，支持重名覆盖提示。

                       24.清空 Bottle 弹窗（已优化）：原本点击直接清空全局 Bottle，无法选择性清理。已改为弹窗列表，第一项为"公共 Bottle"，其后列出所有游戏，可多选。

                       25.多选弹窗全选（已优化）：所有多选弹窗顶部增加"全选"复选框，二态切换，勾选即全选，取消即全不选。覆盖清空 Bottle、导出存档、导入存档、修改器绑定四处弹窗。

                       26.多选默认不选（已优化）：多选弹窗打开时所有条目默认不勾选，用户需主动勾选目标项，避免误操作。

                👋🙏 免责声明：

                本软件仅供学习交流使用，如遇到无法解决的难题，请前往设置界面点击反馈bug按钮反馈bug。

                @B站一个闲的没事的糯米   个人界面:https://space.bilibili.com/3546728525466305?spm_id_from=333.1007.0.0

                """)

                .padding()

                .textSelection(.enabled)

            }

            Divider()

            HStack {

                Spacer()

                Button("关闭") { dismiss() }.buttonStyle(.borderedProminent).padding()

            }

        }

        .frame(minWidth: 500, minHeight: 450)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

    }

}

// MARK: - 全部应用列表

struct AllAppsListView: View {

    @Environment(\.dismiss) private var dismiss

    @StateObject private var library = RemoteGameLibrary()

    @State private var selectedGame: GameItem?  // ✅ 新增，用于弹详情

    var body: some View {

        VStack(spacing: 0) {

            HStack {

                Text("查看全部").font(.title2).bold()

                Spacer()

                Button("关闭") { dismiss() }.buttonStyle(.borderedProminent)

            }

            .padding()

            Divider()

            ScrollView {

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                    ForEach(library.items) { item in

                        CompactAppGridItem(

                            link: item.link,

                            name: item.name,

                            subtitle: item.subtitle,

                            imageURL: item.icon ?? "",

                            onTap: {

                                selectedGame = item  // ✅ 点击后弹出详情

                            }

                        )

                    }

                }

                .padding()

            }

        }

        .frame(minWidth: 800, minHeight: 600)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

        .sheet(item: $selectedGame) { game in

            AppDetailView(game: game)

        }

        .onAppear {

            library.load(manualRefresh: false)

        }

    }

}

// MARK: - 远程游戏库模型

struct GameItem: Codable, Identifiable {

    let id: Int

    let name: String

    let subtitle: String

    let subtitle2: String?

    let subtitle3: String?

    let subtitle4: String?

    let subtitle5: String?

    let subtitle6: String?

    let subtitle7: String?

    let subtitle8: String?

    let subtitle9: String?  // 推文标题

    let subtitle10: String? // 推文简介

    let link: String

    let icon: String?

    let previews: [String]?

}

class RemoteGameLibrary: ObservableObject {

    @Published var items: [GameItem] = []

    @Published var isLoading: Bool = false

    @Published var errorMessage: String?

    private let rawURL = URL(string: "https://raw.githubusercontent.com/nuomi4/YesPVZlauncher/main/games.json")!

    private let cacheFileName = "games_library_cache.json"

    private let cacheLifetime: TimeInterval = 10 * 60 // 10分钟缓存


    private func prefetchIcons(for items: [GameItem]) {
        let urls = items.compactMap { item -> URL? in
            guard let icon = item.icon else { return nil }
            return URL(string: icon)
        }
        RemoteImagePipeline.shared.prefetch(urls)
    }

    private func cacheFilePath() -> URL {

        let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!

        let folder = appSupport.appendingPathComponent("YesPVZLauncher", isDirectory:true)

        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        return folder.appendingPathComponent(cacheFileName)

    }

    private struct LibraryCache: Codable {

        let timestamp: TimeInterval

        let jsonData: Data

    }

    private func loadDiskCache() -> [GameItem]? {

        let path = cacheFilePath()

        guard FileManager.default.fileExists(atPath: path.path) else { return nil }

        do {

            let data = try Data(contentsOf: path)

            let model = try JSONDecoder().decode(LibraryCache.self, from: data)

            let now = Date().timeIntervalSince1970

            if now - model.timestamp < cacheLifetime {

                let decoded = try JSONDecoder().decode([String:[GameItem]].self, from: model.jsonData)

                return decoded["games"]

            }

        } catch {

            print("读取本地缓存失败:\(error)")

        }

        return nil

    }

    private func saveDiskCache(data:Data) {

        let model = LibraryCache(timestamp: Date().timeIntervalSince1970, jsonData: data)

        do {

            let encoded = try JSONEncoder().encode(model)

            try encoded.write(to: cacheFilePath())

        } catch {

            print("写入缓存失败:\(error)")

        }

    }

    func load(manualRefresh:Bool = false) {

        if !manualRefresh, let cache = loadDiskCache() {

            DispatchQueue.main.async {

                self.items = cache
                self.prefetchIcons(for: cache)

            }

        }

        DispatchQueue.main.async {

            self.isLoading = true

            self.errorMessage = nil

        }

        var req = URLRequest(url: rawURL)

        req.timeoutInterval = 8.0

        req.setValue("YesPVZLauncher", forHTTPHeaderField: "User‑Agent")

        let task = URLSession.shared.dataTask(with: req) { [weak self] data, resp, error in

            guard let self = self else { return }

            DispatchQueue.main.async {

                self.isLoading = false

            }

            if let err = error {

                DispatchQueue.main.async {

                    if (err as NSError).code == NSURLErrorTimedOut {

                        self.errorMessage = "网络超时，GitHub访问延迟"

                    } else {

                        self.errorMessage = "加载失败：\(err.localizedDescription)"

                    }

                }

                return

            }

            guard let receivedData = data else {

                DispatchQueue.main.async {

                    self.errorMessage = "没有收到数据"

                }

                return

            }

            do {

                let decoded = try JSONDecoder().decode([String: [GameItem]].self, from: receivedData)

                guard let list = decoded["games"] else {

                    DispatchQueue.main.async {

                        self.errorMessage = "json解析异常"

                    }

                    return

                }

                self.saveDiskCache(data: receivedData)

                DispatchQueue.main.async {

                    self.items = list
                    self.prefetchIcons(for: list)

                }

            } catch {

                DispatchQueue.main.async {

                    self.errorMessage = "解析JSON出错:\(error.localizedDescription)"

                }

            }

        }

        task.resume()

    }

}



// MARK: - 游戏多选数据源（NSTableView 懒加载版）
private final class GameCheckboxDataSource: NSObject, NSTableViewDataSource, NSTableViewDelegate {
    let entries: [String]
    private(set) var selectedEntries: [String] = []
    private var states: [String: NSControl.StateValue] = [:]
    weak var tableView: NSTableView?
    weak var selectAllCheckbox: NSButton?

    init(entries: [String]) {
        self.entries = entries
        super.init()
        for e in entries { states[e] = .off }
        selectedEntries = []
    }

    func numberOfRows(in tableView: NSTableView) -> Int { entries.count }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let entry = entries[row]
        let id = NSUserInterfaceItemIdentifier("GameCheckboxCell")
        let checkbox: NSButton
        if let reused = tableView.makeView(withIdentifier: id, owner: nil) as? NSButton {
            checkbox = reused
        } else {
            checkbox = NSButton(checkboxWithTitle: "", target: self, action: #selector(toggle(_:)))
            checkbox.identifier = id
        }
        checkbox.title = entry
        checkbox.state = states[entry] ?? .off
        checkbox.tag = row
        return checkbox
    }

    @objc private func toggle(_ sender: NSButton) {
        let entry = entries[sender.tag]
        states[entry] = sender.state
        selectedEntries = entries.filter { states[$0] == .on }
        updateSelectAllCheckboxState()
    }

    @objc func selectAllToggled(_ sender: NSButton) {
        let newState: NSControl.StateValue = (sender.state == .on) ? .on : .off
        for e in entries { states[e] = newState }
        selectedEntries = (newState == .on) ? entries : []
        tableView?.reloadData()
    }

    private func updateSelectAllCheckboxState() {
        guard let cb = selectAllCheckbox else { return }
        cb.state = (!entries.isEmpty && selectedEntries.count == entries.count) ? .on : .off
    }
}

// MARK: - 修改器绑定数据源（NSTableView 懒加载版）
private final class GameBindingDataSource: NSObject, NSTableViewDataSource, NSTableViewDelegate {
    let items: [(display: String, gameID: String)]
    private(set) var selectedGameIDs: [String] = []
    private var states: [String: NSControl.StateValue] = [:]
    weak var tableView: NSTableView?
    weak var selectAllCheckbox: NSButton?

    init(items: [(display: String, gameID: String)]) {
        self.items = items
        super.init()
        for item in items { states[item.gameID] = .on }
        selectedGameIDs = items.map { $0.gameID }
    }

    func numberOfRows(in tableView: NSTableView) -> Int { items.count }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let item = items[row]
        let id = NSUserInterfaceItemIdentifier("GameBindingCell")
        let checkbox: NSButton
        if let reused = tableView.makeView(withIdentifier: id, owner: nil) as? NSButton {
            checkbox = reused
        } else {
            checkbox = NSButton(checkboxWithTitle: "", target: self, action: #selector(toggle(_:)))
            checkbox.identifier = id
        }
        checkbox.title = item.display
        checkbox.state = states[item.gameID] ?? .off
        checkbox.tag = row
        return checkbox
    }

    @objc private func toggle(_ sender: NSButton) {
        let item = items[sender.tag]
        states[item.gameID] = sender.state
        selectedGameIDs = items.filter { states[$0.gameID] == .on }.map { $0.gameID }
        updateSelectAllCheckboxState()
    }

    @objc func selectAllToggled(_ sender: NSButton) {
        let newState: NSControl.StateValue = (sender.state == .on) ? .on : .off
        for item in items { states[item.gameID] = newState }
        selectedGameIDs = (newState == .on) ? items.map { $0.gameID } : []
        tableView?.reloadData()
    }

    private func updateSelectAllCheckboxState() {
        guard let cb = selectAllCheckbox else { return }
        cb.state = (!items.isEmpty && selectedGameIDs.count == items.count) ? .on : .off
    }
}

// MARK: - SaveTracking：存档追踪模块（V10）
// 存储位置：~/Library/Application Support/YesPVZLauncher/SaveTracking/<gameId>.json
// 逻辑：游戏启动前记录一份快照，运行中每 1 秒记录一份差量，退出后做归属分析。
// 本文件只负责「数据结构 + 读写 + 差集 + 归属分析」，不接入 runWine（那是第二批）。

enum SaveTrackingStatus: String, Codable {
    case neverLaunched   // 从没启动过（GameInfo 里 trackingStatus 为 nil 时的默认值）
    case pending         // 启动过，但还没定位到唯一路径
    case tracked         // 已定位到唯一路径
    case shared          // 定位到，但与其他游戏共用
    case ambiguous       // 同时出现多个新路径，无法区分
}

struct SaveTrackingSnapshot: Codable {
    let timestamp: TimeInterval
    let userdataPaths: [String]
    let userdataFingerprints: [String: String]?
    let runningGameIds: [String]
}

struct SaveTrackingRecord: Codable {
    let gameId: String
    let bottlePath: String
    var status: SaveTrackingStatus
    var trackedPath: String?          // 最终归属到的路径
    var snapshots: [SaveTrackingSnapshot]
    var lastUpdate: TimeInterval
}

final class SaveTrackingStore {
    static let shared = SaveTrackingStore()

    private let fm = FileManager.default

    /// V10：wineserver 里还在跑的游戏 gameId（跟 ContentView 的 runningProcesses 无关）
    /// 启动时加入，wineserver 退出后才移除。
    private(set) var wineserverRunningGameIds: Set<String> = []

    /// 游戏启动，加入
    func markGameRunning(_ gameId: String) {
        wineserverRunningGameIds.insert(gameId)
    }

    /// wineserver 退出，移除
    func markGameStopped(_ gameId: String) {
        wineserverRunningGameIds.remove(gameId)
    }

    /// 全部清空（强制终止时用）
    func clearAllRunning() {
        wineserverRunningGameIds.removeAll()
    }

    /// 读快照
    func currentRunningGameIds() -> [String] {
        return Array(wineserverRunningGameIds)
    }

    private var storageDir: URL {
        let appSupport = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("YesPVZLauncher")
            .appendingPathComponent("SaveTracking")
        try? fm.createDirectory(at: appSupport, withIntermediateDirectories: true)
        return appSupport
    }

    private func recordPath(for gameId: String) -> URL {
        storageDir.appendingPathComponent("\(gameId).json")
    }

    // MARK: 读写

    func load(gameId: String) -> SaveTrackingRecord? {
        let path = recordPath(for: gameId)
        guard fm.fileExists(atPath: path.path) else { return nil }
        do {
            return try JSONDecoder().decode(SaveTrackingRecord.self, from: Data(contentsOf: path))
        } catch {
            return nil
        }
    }

    func save(_ record: SaveTrackingRecord) {
        do {
            let data = try JSONEncoder().encode(record)
            try data.write(to: recordPath(for: record.gameId), options: .atomic)
        } catch {
            // 静默失败。追踪是辅助功能，坏了不影响主流程。
        }
    }

    func remove(gameId: String) {
        let path = recordPath(for: gameId)
        try? fm.removeItem(at: path)
    }

    // MARK: 快照

    /// 启动前：开一条新的追踪记录（如果已有 tracked 记录，直接跳过）
    func beginTracking(gameId: String, bottlePath: String, currentPaths: [String], currentFingerprints: [String: String], runningGameIds: [String]) {
        if let existing = load(gameId: gameId),
           existing.status == .tracked || existing.status == .shared {
            return
        }

        var record = load(gameId: gameId) ?? SaveTrackingRecord(
            gameId: gameId,
            bottlePath: bottlePath,
            status: .pending,
            trackedPath: nil,
            snapshots: [],
            lastUpdate: Date().timeIntervalSince1970
        )

        let snap = SaveTrackingSnapshot(
            timestamp: Date().timeIntervalSince1970,
            userdataPaths: currentPaths,
            userdataFingerprints: currentFingerprints,
            runningGameIds: runningGameIds
        )
        record.snapshots.append(snap)
        if record.status != .tracked && record.status != .shared {
            record.status = .pending
        }
        record.lastUpdate = snap.timestamp
        save(record)
    }

    /// 运行中：追加一份快照（差量为空时也追加，用于归属分析）
    func appendSnapshot(gameId: String, currentPaths: [String], currentFingerprints: [String: String], runningGameIds: [String]) {
        guard var record = load(gameId: gameId) else { return }
        guard record.status != .tracked && record.status != .shared else { return }

        let snap = SaveTrackingSnapshot(
            timestamp: Date().timeIntervalSince1970,
            userdataPaths: currentPaths,
            userdataFingerprints: currentFingerprints,
            runningGameIds: runningGameIds
        )

        if record.snapshots.count >= 10_000 {
            record.snapshots.removeFirst()
        }

        record.snapshots.append(snap)
        record.lastUpdate = snap.timestamp
        save(record)
    }

    /// 退出后：归属分析
    /// 返回分析后的状态（同时已经写回磁盘）
    @discardableResult
    func finalizeTracking(
        gameId: String,
        currentPaths: [String],
        currentFingerprints: [String: String],
        runningGameIds: [String],
        allOtherTrackedPaths: [String: String]
    ) -> SaveTrackingStatus {
        guard var record = load(gameId: gameId) else { return .pending }
        guard record.status != .tracked && record.status != .shared else { return record.status }

        let finalSnap = SaveTrackingSnapshot(
            timestamp: Date().timeIntervalSince1970,
            userdataPaths: currentPaths,
            userdataFingerprints: currentFingerprints,
            runningGameIds: runningGameIds
        )
        record.snapshots.append(finalSnap)

        let result = analyze(snapshots: record.snapshots, myGameId: gameId, allOtherTrackedPaths: allOtherTrackedPaths)

        record.status = result.status
        record.trackedPath = result.path
        record.lastUpdate = Date().timeIntervalSince1970
        save(record)
        return result.status
    }

    // MARK: 归属分析核心

    private struct AnalysisResult {
        let status: SaveTrackingStatus
        let path: String?
    }

    private func analyze(
        snapshots: [SaveTrackingSnapshot],
        myGameId: String,
        allOtherTrackedPaths: [String: String]
    ) -> AnalysisResult {
        guard snapshots.count >= 2 else {
            return AnalysisResult(status: .pending, path: nil)
        }

        let selfRan = snapshots.contains { $0.runningGameIds.contains(myGameId) }
        guard selfRan else {
            return AnalysisResult(status: .pending, path: nil)
        }

        var myPaths: Set<String> = []
        for i in 1..<snapshots.count {
            let before = snapshots[i - 1]
            let after = snapshots[i]

            let beforeHasMe = before.runningGameIds.contains(myGameId)
            let afterHasMe = after.runningGameIds.contains(myGameId)
            guard beforeHasMe || afterHasMe else { continue }

            let beforePaths = Set(before.userdataPaths)
            let afterPaths = Set(after.userdataPaths)

            // 1) 路径新增
            myPaths.formUnion(afterPaths.subtracting(beforePaths))

            // 2) 指纹变化（已存在但内容改了）
            let beforeFp = before.userdataFingerprints ?? [:]
            let afterFp = after.userdataFingerprints ?? [:]
            for path in afterPaths.intersection(beforePaths) {
                if let b = beforeFp[path], let a = afterFp[path], b != a {
                    myPaths.insert(path)
                }
            }
        }

        if myPaths.isEmpty {
            return AnalysisResult(status: .pending, path: nil)
        }

        if myPaths.count == 1, let path = myPaths.first {
            if conflictWithOtherGame(path: path, myGameId: myGameId, allOtherTrackedPaths: allOtherTrackedPaths) != nil {
                return AnalysisResult(status: .shared, path: path)
            }
            return AnalysisResult(status: .tracked, path: path)
        }

        if let best = myPaths.max(by: { scorePath($0) < scorePath($1) }) {
            if conflictWithOtherGame(path: best, myGameId: myGameId, allOtherTrackedPaths: allOtherTrackedPaths) != nil {
                return AnalysisResult(status: .shared, path: best)
            }
            return AnalysisResult(status: .tracked, path: best)
        }
        return AnalysisResult(status: .ambiguous, path: nil)
    }

    private func conflictWithOtherGame(path: String, myGameId: String, allOtherTrackedPaths: [String: String]) -> String? {
        for (gid, p) in allOtherTrackedPaths where gid != myGameId {
            if p == path { return gid }
        }
        return nil
    }

    private func scorePath(_ path: String) -> Int {
        let lower = path.lowercased()
        var score = 0
        if lower.contains("plants") { score += 100 }
        if lower.contains("zombie") { score += 100 }
        if lower.contains("popcap") { score += 60 }
        if lower.contains("programdata") { score += 30 }
        return score
    }
}


// MARK: - Associated Object Keys（Swift 6 安全的指针 key）
private enum AssociatedKeys {
    static let gameCheckboxDataSource = UnsafeRawPointer(
        bitPattern: Int(bitPattern: ObjectIdentifier(GameCheckboxDataSource.self))
    )!
    static let gameBindingDataSource = UnsafeRawPointer(
        bitPattern: Int(bitPattern: ObjectIdentifier(GameBindingDataSource.self))
    )!
}
#Preview { ContentView() }

