import SwiftUI

import AppKit

import Foundation

import UniformTypeIdentifiers

import Combine
import ImageIO

// MARK: - 资源链接配置 (V8: 已更新为最新下载源)

enum ResourceLinkConfig {

    //static let gameEnOriginal = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/01%20Win%20%E7%B3%BB%E7%BB%9F%E8%8B%B1%E6%96%87%E5%8E%9F%E7%89%88/"

    //static let gameCnOriginal = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/02%20Win%20%E7%B3%BB%E7%BB%9F%E4%B8%AD%E6%96%87%E5%8E%9F%E7%89%88/"

    //static let pakPatch = "https://pvz.766788.xyz/ziyuan/01%20%E4%B8%80%E4%BB%A3%E7%94%B5%E8%84%91/12%20%E6%B8%B8%E6%88%8F%20PAK/"

    // 新加的3个占位链接（记得自己替换成真实网址）

    static let link1 = "https://space.bilibili.com/3546728525466305?spm_id_from=333.1007.0.0"

    static let link2 = "https://github.com/nuomi4/YesPVZlauncher/tree/main"

    static let link3 = "https://github.com/nuomi4/YesPVZlauncher/issues/new?template=bug_report.md"

    // V8 更新：最新的 Whisky 4.5.105-beta.1 引擎下载链接

    static let wineDownloadSources: [URL] = [

        URL(string: "https://github.com/frankea/Whisky/releases/download/v4.5.105-beta.1/Libraries.tar.gz")!

    ]

}

// MARK: - 数据模型

struct GameInfo: Codable {

    let gameId: String

    let gameType: String

    let mainExeName: String

    var useSeparateBottle: Bool

}

struct ToolInfo: Codable {

    let toolId: String

    let toolName: String

    let toolRealPath: String

    var bindGameIds: [String]

    var note: String

}

// MARK: - 下载错误

enum WineDownloadError: LocalizedError {

    case alreadyDownloading, destinationMissing, incompleteFile, cancelled

    var errorDescription: String? {

        switch self {

        case .alreadyDownloading: return "已有下载任务正在进行"

        case .destinationMissing: return "下载目标路径为空"

        case .incompleteFile: return "下载文件不完整"

        case .cancelled: return "已取消下载"

        }

    }

}

// MARK: - 下载管理器

final class WineDownloader: NSObject, ObservableObject, URLSessionDownloadDelegate {

    @Published var progress: Double = 0

    @Published var isDownloading: Bool = false

    private var task: URLSessionDownloadTask?

    private var destination: URL?

    private var completion: ((Result<URL, Error>) -> Void)?

    private var session: URLSession?

    private var hasFinished = false

    func download(url: URL, to file: URL, completion: @escaping (Result<URL, Error>) -> Void) {

        guard !isDownloading else {

            completion(.failure(WineDownloadError.alreadyDownloading)); return

        }

        resetState()

        destination = file

        self.completion = completion

        let config = URLSessionConfiguration.default

        config.timeoutIntervalForRequest = 60

        config.timeoutIntervalForResource = 600

        config.requestCachePolicy = .reloadIgnoringLocalCacheData

        let session = URLSession(configuration: config, delegate: self, delegateQueue: .main)

        self.session = session

        task = session.downloadTask(with: url)

        task?.resume()

    }

    func cancel() {

        guard isDownloading else { return }

        task?.cancel()

        finish(.failure(WineDownloadError.cancelled))

    }

    private func resetState() {

        progress = 0; isDownloading = true; hasFinished = false

    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {

        guard totalBytesExpectedToWrite > 0 else { return }

        progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)

    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {

        guard let destination else {

            finish(.failure(WineDownloadError.destinationMissing)); return

        }

        do {

            let fm = FileManager.default

            if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }

            try fm.copyItem(at: location, to: destination)

            let attrs = try fm.attributesOfItem(atPath: destination.path)

            let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0

            guard size >= 30 * 1024 * 1024 else {

                try? fm.removeItem(at: destination)

                finish(.failure(WineDownloadError.incompleteFile)); return

            }

            finish(.success(destination))

        } catch {

            finish(.failure(error))

        }

    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {

        if let error, !hasFinished {

            finish(.failure(error))

        }

    }

    private func finish(_ result: Result<URL, Error>) {

        guard !hasFinished else { return }

        hasFinished = true

        isDownloading = false

        task = nil

        let callback = completion

        completion = nil

        destination = nil

        session?.finishTasksAndInvalidate()

        session = nil

        callback?(result)

    }

}

// MARK: - 玻璃质感圆形按钮

struct GlassActionButton: View {//汤圆

    let systemIcon: String

    let tintColor: Color

    let isEnabled: Bool

    let action: () -> Void

    var body: some View {

        Button(action: action) {

            ZStack {

                Circle().fill(Color.black.opacity(0.1)).offset(y: 1)

                Circle().fill(.regularMaterial).environment(\.colorScheme, .light)

                Circle().stroke(Color.white.opacity(0.8), lineWidth: 1.2)

                Circle().stroke(Color.black.opacity(0.05), lineWidth: 1).padding(1.5)

                Image(systemName: systemIcon)

                    .font(.system(size: 15, weight: .medium))

                    .foregroundColor(isEnabled ? tintColor : Color.gray.opacity(0.4))

            }

            .frame(width: 34, height: 34)

        }

        .buttonStyle(.plain)

        .disabled(!isEnabled)

    }

}

// MARK: - Wine 引擎资源

private struct WineEngineResources {

    let wine: URL

    let server: URL

    let libraryPath: URL

}

// MARK: - 主界面 (V9.1.1：图片查看器 / 图片缓存 / 存档导出兜底)

struct ContentView: View {

    @State private var statusText = ""

    @State private var selectedTab = 0

    @State private var gameList: [String] = []

    @State private var selectedGameEntry: String?

    @State private var toolList: [ToolInfo] = []

    @State private var selectedToolId: String?

    @State private var wineReady = false

    @StateObject private var downloader = WineDownloader()

    @State private var runningProcesses: [UUID: Process] = [:]

    @State private var caffeinateProcesses: [UUID: Process] = [:]

    @State private var showHelp = false

    @State private var showAppDetail = false

    @State private var selectedGame: GameItem? = nil

    @State private var resetID = UUID()

    @StateObject private var sharedLibrary = RemoteGameLibrary()

    // V8 恢复偏好设置：新游戏默认独立 Bottle

    @AppStorage("wine64Path") private var wine64Path: String = ""

    @AppStorage("defaultSeparateBottle") private var defaultSeparateBottle = false

    @AppStorage("wineDebug") private var wineDebug = false

    // V8 防冻结与老游戏兼容设置：保留 Caffeinate 和 OpenGL 强制渲染

    @AppStorage("enableKeepAlive") private var enableKeepAlive = true

    @AppStorage("forceOpenGLRender") private var forceOpenGLRender = false

    private var appSupport: URL {

        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!

            .appendingPathComponent("YesPVZLauncher")

    }

    private var globalBottle: URL { appSupport.appendingPathComponent("GlobalBottle") }

    private var wineFolder: URL { appSupport.appendingPathComponent("WineEngine") }

    private var toolsDir: URL { appSupport.appendingPathComponent("GameLibrary/Tools") }

    private var hasRunningWineProcess: Bool {

        runningProcesses.values.contains(where: { $0.isRunning })

    }

    // MARK: - 咖啡因保活

    private func startCaffeinate(for process: Process, id: UUID) {

        guard enableKeepAlive, process.isRunning else { return }

        let keepAlive = Process()

        keepAlive.executableURL = URL(fileURLWithPath: "/usr/bin/caffeinate")

        keepAlive.arguments = ["-dimsu", "-w", String(process.processIdentifier)]

        do {

            try keepAlive.run()

            caffeinateProcesses[id] = keepAlive

            if wineDebug { appendStatus("☕咖啡因保活已启动（跟随 PID \(process.processIdentifier)）") }

        } catch {

            if wineDebug { appendStatus("⚠️咖啡因保活启动失败: \(error.localizedDescription)") }

        }

    }

    private func stopCaffeinate(id: UUID) {

        guard let keepAlive = caffeinateProcesses.removeValue(forKey: id) else { return }

        if keepAlive.isRunning { keepAlive.terminate() }

    }

    private func stopAllCaffeinate() {

        for process in caffeinateProcesses.values where process.isRunning { process.terminate() }

        caffeinateProcesses.removeAll()

    }

    // MARK: - 通用工具

    private let maxVisibleLogCharacters = 30_000

    private func appendStatus(_ text: String) {

        statusText = statusText.isEmpty ? text : statusText + "\n\(text)"

        if statusText.count > maxVisibleLogCharacters {

            statusText = "…前面的日志已截断…\n" + String(statusText.suffix(maxVisibleLogCharacters))

        }

    }

    private func appendWineLogToUI(_ text: String) {

        guard !text.isEmpty else { return }

        statusText += text

        if statusText.count > maxVisibleLogCharacters {

            statusText = "…前面的 Wine 日志已截断…\n" + String(statusText.suffix(maxVisibleLogCharacters))

        }

    }

    private func openExactResourceLink(_ raw: String) {

        guard !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {

            statusText = "❌链接为空"; return

        }

        let process = Process()

        process.executableURL = URL(fileURLWithPath: "/usr/bin/open")

        process.arguments = [raw]

        do {

            try process.run()

            if wineDebug { statusText = "🔗原始链接已直接交给系统:\n\(raw)" }

        } catch {

            statusText = "❌打开链接失败: \(error.localizedDescription)"

        }

    }

    private func runSystemProcess(executable: String, arguments: [String], wait: Bool = true) -> Int32? {

        let process = Process()

        process.executableURL = URL(fileURLWithPath: executable)

        process.arguments = arguments

        do {

            try process.run()

            if wait { process.waitUntilExit(); return process.terminationStatus }

            return 0

        } catch { return nil }

    }

    private func removeQuarantine(in url: URL) {

        guard FileManager.default.fileExists(atPath: url.path) else { return }

        _ = runSystemProcess(executable: "/usr/bin/xattr", arguments: ["-cr", url.path])

    }

    private func ensureExecutablePermissions(in url: URL) {

        guard FileManager.default.fileExists(atPath: url.path) else { return }

        _ = runSystemProcess(executable: "/bin/chmod", arguments: ["-R", "755", url.path])

    }

    private func getBottle(_ game: GameInfo, storage: URL) -> URL {

        game.useSeparateBottle ? storage.appendingPathComponent("GameBottle") : globalBottle

    }



    // MARK: - 存档导入导出

    private func resolveGameExePath(for game: GameInfo, storage: URL) -> URL? {

        guard let realFolder = resolveSymlink(storage) else { return nil }

        let exe = realFolder.appendingPathComponent(game.mainExeName)

        guard FileManager.default.fileExists(atPath: exe.path) else { return nil }

        return exe

    }

    private func findUserdataPath(for game: GameInfo, storage: URL) -> URL? {

        let fm = FileManager.default

        let bottle = getBottle(game, storage: storage)

        let driveC = bottle.appendingPathComponent("drive_c")

        guard let exePath = resolveGameExePath(for: game, storage: storage) else {

            return nil

        }

        // 1. 游戏主程序目录下的 userdata（最优先）

        let primaryPath = exePath.deletingLastPathComponent().appendingPathComponent("userdata")

        if fm.fileExists(atPath: primaryPath.path) {

            return primaryPath

        }

        // 2. Windows Vista+ 路径

        let programData = driveC.appendingPathComponent("ProgramData")

        let vistaPath = programData

            .appendingPathComponent("PopCap Games")

            .appendingPathComponent("PlantsVsZombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: vistaPath.path) {

            return vistaPath

        }

        // 3. Steam 本地路径

        let steamPath = programData

            .appendingPathComponent("Steam")

            .appendingPathComponent("PlantsVsZombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: steamPath.path) {

            return steamPath

        }

        // 4. Zoo 日文版路径

        let zooPath = programData

            .appendingPathComponent("Zoo")

            .appendingPathComponent("Plants vs Zombies")

            .appendingPathComponent("userdata")

        if fm.fileExists(atPath: zooPath.path) {

            return zooPath

        }

        return nil

    }

    // V9.1.3：仅用于“导出存档”的智能路径搜索。
    // 重要：明确区分“软链接导入”和“复制导入”，同时再区分独立 Bottle / 全局 Bottle。
    // 导入存档逻辑仍保持 V9 原样，不使用这里的全盘扫描。

    private func isGameStorageSymbolicLink(_ storage: URL) -> Bool {
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: storage.path) else {
            return false
        }
        return attrs[.type] as? FileAttributeType == .typeSymbolicLink
    }

    private func firstExistingUserdataDirectory(in parent: URL) -> URL? {
        let fm = FileManager.default

        // 兼容大小写不同的改版：userdata / UserData / USERDATA。
        let names = ["userdata", "UserData", "USERDATA"]
        for name in names {
            let candidate = parent.appendingPathComponent(name)
            var isDirectory: ObjCBool = false
            if fm.fileExists(atPath: candidate.path, isDirectory: &isDirectory),
               isDirectory.boolValue {
                return candidate
            }
        }

        // 对大小写敏感磁盘再做一次目录枚举匹配。
        guard let children = try? fm.contentsOfDirectory(
            at: parent,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }

        for child in children {
            guard child.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }
            let values = try? child.resourceValues(forKeys: [.isDirectoryKey])
            if values?.isDirectory == true {
                return child
            }
        }

        return nil
    }

    private func knownUserdataPathInsideBottle(_ bottle: URL) -> URL? {
        let fm = FileManager.default
        let driveC = bottle.appendingPathComponent("drive_c")

        var driveCIsDirectory: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &driveCIsDirectory),
              driveCIsDirectory.boolValue else {
            return nil
        }

        // 已知常见位置仍然优先，避免每次都遍历整个 C 盘。
        let parentCandidates: [URL] = [
            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("PopCap Games")
                .appendingPathComponent("PlantsVsZombies"),

            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("Steam")
                .appendingPathComponent("PlantsVsZombies"),

            driveC
                .appendingPathComponent("ProgramData")
                .appendingPathComponent("Zoo")
                .appendingPathComponent("Plants vs Zombies")
        ]

        for parent in parentCandidates {
            if let userdata = firstExistingUserdataDirectory(in: parent) {
                return userdata
            }
        }

        return nil
    }

    private func scanDriveCForUserdata(_ driveC: URL) -> URL? {
        let fm = FileManager.default

        var driveCIsDirectory: ObjCBool = false
        guard fm.fileExists(atPath: driveC.path, isDirectory: &driveCIsDirectory),
              driveCIsDirectory.boolValue else {
            return nil
        }

        guard let enumerator = fm.enumerator(
            at: driveC,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles],
            errorHandler: { _, _ in true }
        ) else {
            return nil
        }

        var candidates: [(url: URL, score: Int)] = []

        for case let url as URL in enumerator {
            guard url.lastPathComponent.caseInsensitiveCompare("userdata") == .orderedSame else {
                continue
            }

            let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values?.isDirectory == true,
                  values?.isSymbolicLink != true else {
                continue
            }

            var score = 0
            let path = url.path.lowercased()

            // PVZ / PopCap 相关路径优先。
            if path.contains("plants") { score += 120 }
            if path.contains("zombie") { score += 120 }
            if path.contains("popcap") { score += 80 }
            if path.contains("programdata") { score += 30 }
            if path.contains("steam") { score += 20 }
            if path.contains("zoo") { score += 10 }

            // 存档内容特征加权，避免误选其他 Windows 软件的 userdata。
            if let children = try? fm.contentsOfDirectory(
                at: url,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
            ) {
                let lowerNames = children.map { $0.lastPathComponent.lowercased() }
                if lowerNames.contains(where: { $0.hasSuffix(".dat") }) { score += 60 }
                if lowerNames.contains(where: { $0.contains("user") }) { score += 25 }
                if lowerNames.contains(where: { $0.contains("game") }) { score += 20 }
            }

            candidates.append((url, score))
            enumerator.skipDescendants()
        }

        return candidates.max(by: { $0.score < $1.score })?.url
    }

    private func findUserdataPathForExport(for game: GameInfo, storage: URL) -> URL? {
        let fm = FileManager.default
        let isSymlinkImport = isGameStorageSymbolicLink(storage)
        let bottle = getBottle(game, storage: storage)
        let driveC = bottle.appendingPathComponent("drive_c")

        // ─────────────────────────────────────────────
        // A. 软链接导入
        // storage 只是启动器里的链接；真正游戏本体由软链接目标决定。
        // 所以先直接检查“真实游戏本体/userdata”。
        // ─────────────────────────────────────────────
        if isSymlinkImport {
            if let realGameFolder = resolveSymlink(storage),
               fm.fileExists(atPath: realGameFolder.path),
               let userdata = firstExistingUserdataDirectory(in: realGameFolder) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，命中游戏本体 userdata")
                }
                return userdata
            }

            // 游戏本体没找到，再查这个游戏实际使用的 Bottle。
            if let known = knownUserdataPathInsideBottle(bottle) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，命中 Bottle 已知路径")
                }
                return known
            }

            if let scanned = scanDriveCForUserdata(driveC) {
                if wineDebug {
                    appendStatus("💾存档导出：软链接模式，C 盘全盘扫描命中 userdata")
                }
                return scanned
            }

            return nil
        }

        // ─────────────────────────────────────────────
        // B. 复制导入
        // storage 是启动器内部保存的实体副本，不把它当成外部“原始游戏本体”去追踪。
        // 按用户实际运行环境，优先查它真正使用的 GameBottle / GlobalBottle。
        // ─────────────────────────────────────────────

        // useSeparateBottle == true  → storage/GameBottle/drive_c
        // useSeparateBottle == false → Application Support/YesPVZLauncher/GlobalBottle/drive_c
        if let known = knownUserdataPathInsideBottle(bottle) {
            if wineDebug {
                let mode = game.useSeparateBottle ? "GameBottle" : "GlobalBottle"
                appendStatus("💾存档导出：复制模式，命中 \(mode) 已知路径")
            }
            return known
        }

        // 固定位置没有，再扫描“这个复制游戏真正使用的 C 盘”。
        if let scanned = scanDriveCForUserdata(driveC) {
            if wineDebug {
                let mode = game.useSeparateBottle ? "GameBottle" : "GlobalBottle"
                appendStatus("💾存档导出：复制模式，\(mode) C 盘全盘扫描命中 userdata")
            }
            return scanned
        }

        return nil
    }

    private func selectGamesFromList(title: String, message: String) -> [String] {

        let alert = NSAlert()

        alert.messageText = title

        alert.informativeText = message

        alert.addButton(withTitle: "确认")

        alert.addButton(withTitle: "取消")

        let scroll = NSScrollView()

        scroll.hasVerticalScroller = true

        scroll.borderType = .bezelBorder

        scroll.frame = NSRect(x: 0, y: 0, width: 380, height: 240)

        let stack = NSStackView()

        stack.orientation = .vertical

        stack.alignment = .leading

        stack.spacing = 8

        stack.edgeInsets = NSEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)

        var buttons: [String: NSButton] = [:]

        for entry in gameList {

            let checkbox = NSButton(checkboxWithTitle: entry, target: nil, action: nil)

            checkbox.state = .on

            buttons[entry] = checkbox

            stack.addArrangedSubview(checkbox)

        }

        stack.frame = NSRect(x: 0, y: 0, width: 360, height: max(240, stack.fittingSize.height))

        scroll.documentView = stack

        alert.accessoryView = scroll

        guard alert.runModal() == .alertFirstButtonReturn else { return [] }

        return buttons.filter { $0.value.state == .on }.map(\.key)

    }

    // MARK: 导出存档

    private func exportSaveData() {

        let selected = selectGamesFromList(title: "选择要导出的游戏", message: "请选择要导出存档的游戏（可多选）")

        guard !selected.isEmpty else { return }

        let panel = NSOpenPanel()

        panel.title = "选择导出位置"

        panel.canChooseFiles = false

        panel.canChooseDirectories = true

        panel.allowsMultipleSelection = false

        panel.message = "选择存档导出的目标文件夹"

        guard panel.runModal() == .OK, let targetDir = panel.url else {

            statusText = "❌未选择导出位置"

            return

        }

        var successCount = 0
        var failedEntries: [String] = []

        for entry in selected {

            guard let storage = gameStorage(entry),

                  let game = loadGameInfo(storage),

                  let userdataPath = findUserdataPathForExport(for: game, storage: storage) else {

                failedEntries.append(entry)

                if wineDebug {
                    appendStatus("🔎未找到 \(entry) 的存档：已按软链接/复制模式检查对应位置，并扫描该游戏实际使用的 C 盘")
                }

                continue

            }

            let folderName = storage.lastPathComponent + "_存档"

            let destFolder = targetDir.appendingPathComponent(folderName)

            do {

                if FileManager.default.fileExists(atPath: destFolder.path) {

                    try FileManager.default.removeItem(at: destFolder)

                }

                try FileManager.default.createDirectory(at: destFolder, withIntermediateDirectories: true)

                let destUserdata = destFolder.appendingPathComponent("userdata")

                try FileManager.default.copyItem(at: userdataPath, to: destUserdata)

                successCount += 1

            } catch {

                // 复制失败时不要留下一个空的“xxx_存档”目录。
                if FileManager.default.fileExists(atPath: destFolder.path) {
                    try? FileManager.default.removeItem(at: destFolder)
                }

                failedEntries.append(entry)

                if wineDebug {
                    appendStatus("❌导出 \(entry) 失败: \(error.localizedDescription)")
                }

            }

        }

        if successCount == 0 {

            statusText = """
            ❌找不到所选游戏的存档存储文件夹。

            已检查常用存档路径，并扫描该游戏实际使用的 Windows C 盘。
            如果游戏作者说明了存档位置，请按照作者提供的路径手动复制存档。
            """

        } else if failedEntries.isEmpty {

            statusText = "✅成功导出 \(successCount) 个存档到 \(targetDir.lastPathComponent)"

        } else {

            statusText = """
            ✅成功导出 \(successCount) 个存档到 \(targetDir.lastPathComponent)
            ⚠️另有 \(failedEntries.count) 个游戏未找到存档路径。
            """

        }

    }

    // MARK: 导入存档

    private func importSaveData() {

        // 检查是否有正在运行的 Wine 进程

        if hasRunningWineProcess {

            let alert = NSAlert()

            alert.messageText = "游戏正在运行"

            alert.informativeText = "检测到有游戏正在运行，请先关闭游戏再导入存档，否则会导致导入失败。"

            alert.addButton(withTitle: "确定")

            alert.runModal()

            return

        }

        let panel = NSOpenPanel()

        panel.title = "选择要导入的存档文件夹"

        panel.canChooseFiles = false

        panel.canChooseDirectories = true

        panel.allowsMultipleSelection = false

        panel.message = "请选择之前导出的存档文件夹（格式：xxx_存档）"

        guard panel.runModal() == .OK, let sourceFolder = panel.url else {

            statusText = "❌未选择存档"

            return

        }

        let sourceUserdata = sourceFolder.appendingPathComponent("userdata")

        guard FileManager.default.fileExists(atPath: sourceUserdata.path) else {

            statusText = "❌所选文件夹不包含 userdata，不是有效的存档"

            return

        }

        let selected = selectGamesFromList(title: "选择要导入的游戏", message: "请选择要导入存档的游戏（可多选）")

        guard !selected.isEmpty else { return }

        var successCount = 0

        for entry in selected {

            guard let storage = gameStorage(entry),

                  let game = loadGameInfo(storage),

                  let targetUserdata = findUserdataPath(for: game, storage: storage) else {

                appendStatus("❌未找到 \(entry) 的目标路径")

                continue

            }

            if FileManager.default.fileExists(atPath: targetUserdata.path) {

                let alert = NSAlert()

                alert.messageText = "覆盖确认"

                alert.informativeText = "游戏「\(entry)」的存档已存在，是否覆盖？"

                alert.addButton(withTitle: "覆盖")

                alert.addButton(withTitle: "跳过")

                guard alert.runModal() == .alertFirstButtonReturn else { continue }

                do {

                    try FileManager.default.removeItem(at: targetUserdata)

                } catch {

                    appendStatus("❌删除旧存档失败: \(error.localizedDescription)")

                    continue

                }

            }

            do {

                try FileManager.default.copyItem(at: sourceUserdata, to: targetUserdata)

                successCount += 1

            } catch {

                appendStatus("❌导入 \(entry) 失败: \(error.localizedDescription)")

            }

        }

        statusText = "✅成功导入 \(successCount) 个存档"

    }

















    // MARK: - JSON 数据

    private func loadGameInfo(_ url: URL) -> GameInfo? {

        let file = url.appendingPathComponent("gameinfo.json")

        guard FileManager.default.fileExists(atPath: file.path) else { return nil }

        do { return try JSONDecoder().decode(GameInfo.self, from: Data(contentsOf: file)) }

        catch { statusText = "⚠️读取配置失败: \(error.localizedDescription)"; return nil }

    }

    private func saveGameInfo(_ url: URL, _ info: GameInfo) {

        do { try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true); try JSONEncoder().encode(info).write(to: url.appendingPathComponent("gameinfo.json"), options: .atomic) }

        catch { statusText = "⚠️写入失败: \(error.localizedDescription)" }

    }

    private func saveTool(_ tool: ToolInfo) {

        do { try FileManager.default.createDirectory(at: toolsDir, withIntermediateDirectories: true); try JSONEncoder().encode(tool).write(to: toolsDir.appendingPathComponent("\(tool.toolId).json"), options: .atomic) }

        catch { statusText = "⚠️保存工具失败: \(error.localizedDescription)" }

    }

    private func loadTools() {

        toolList.removeAll()

        guard FileManager.default.fileExists(atPath: toolsDir.path) else { return }

        do {

            let files = try FileManager.default.contentsOfDirectory(at: toolsDir, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

            var loaded: [ToolInfo] = []

            for file in files where file.pathExtension.lowercased() == "json" {

                do { loaded.append(try JSONDecoder().decode(ToolInfo.self, from: Data(contentsOf: file))) }

                catch { appendStatus("⚠️修改器记录损坏，已跳过: \(file.lastPathComponent)") }

            }

            toolList = loaded.sorted { $0.toolName.localizedStandardCompare($1.toolName) == .orderedAscending }

        } catch { appendStatus("⚠️读取修改器列表失败: \(error.localizedDescription)") }

    }

    // MARK: - 游戏目录

    private func gameStorage(_ entry: String) -> URL? {

        let parts = entry.split(separator: "|", maxSplits: 1).map(String.init)

        guard parts.count == 2 else { return nil }

        let subDirectory: String

        switch parts[0] {

        case "原版": subDirectory = "Original"

        case "魔改": subDirectory = "Modded"

        default: return nil

        }

        return appSupport.appendingPathComponent("Games").appendingPathComponent(subDirectory).appendingPathComponent(parts[1])

    }

    private func resolveSymlink(_ url: URL) -> URL? {

        let fm = FileManager.default

        do {

            let attributes = try fm.attributesOfItem(atPath: url.path)

            guard attributes[.type] as? FileAttributeType == .typeSymbolicLink else { return url }

            let destination = try fm.destinationOfSymbolicLink(atPath: url.path)

            if destination.hasPrefix("/") { return URL(fileURLWithPath: destination).standardizedFileURL }

            return url.deletingLastPathComponent().appendingPathComponent(destination).standardizedFileURL

        } catch { return nil }

    }

    private func openGameFolder(_ entry: String) {

        guard let storage = gameStorage(entry) else { statusText = "❌游戏文件夹记录丢失，可能在手动操作中被清空。请尝试重新导入。"; return }

        guard let realURL = resolveSymlink(storage) else { statusText = "❌软链接目标文件失效，文件夹可能已经被手动移动或删除了。"; return }

        guard FileManager.default.fileExists(atPath: realURL.path) else {

            statusText = "❌目标目录已被清空或移动，请在 Finder 中打开应用数据目录手动查看。"

            NSWorkspace.shared.open(appSupport); return

        }

        NSWorkspace.shared.open(realURL)

        statusText = "✅已打开目录"

    }

    private func toolsForGame() -> [ToolInfo] {

        guard let entry = selectedGameEntry, let storage = gameStorage(entry), let game = loadGameInfo(storage) else { return [] }

        return toolList.filter { $0.bindGameIds.contains(game.gameId) }

    }

    private func refreshGames() {

        var result: [String] = []

        func scan(tag: String, root: URL) {

            guard FileManager.default.fileExists(atPath: root.path) else { return }

            do {

                let items = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

                for item in items { result.append("\(tag)|\(item.lastPathComponent)") }

            } catch { appendStatus("⚠️扫描游戏目录失败: \(error.localizedDescription)") }

        }

        scan(tag: "原版", root: appSupport.appendingPathComponent("Games/Original"))

        scan(tag: "魔改", root: appSupport.appendingPathComponent("Games/Modded"))

        gameList = result.sorted { $0.localizedStandardCompare($1) == .orderedAscending }

    }

    // MARK: - Wine 引擎路径探测

    private func isRealExecutableFile(_ url: URL) -> Bool {

        let fm = FileManager.default

        let resolved = url.resolvingSymlinksInPath()

        var isDirectory: ObjCBool = false

        guard fm.fileExists(atPath: resolved.path, isDirectory: &isDirectory), !isDirectory.boolValue else { return false }

        return fm.isExecutableFile(atPath: resolved.path)

    }

    private func wineCandidateScore(_ url: URL) -> Int {

        let name = url.lastPathComponent.lowercased()

        let parent = url.deletingLastPathComponent().lastPathComponent.lowercased()

        let path = url.path.lowercased()

        var score = 0

        if parent == "bin" { score += 10_000 }

        if path.contains("/bin/") { score += 2_000 }

        if name == "wine64" { score += 500 }

        if name == "wine" { score += 300 }

        if path.contains("/lib/") || path.contains("/lib64/") { score -= 5_000 }

        return score

    }

    private func libraryCandidateScore(_ url: URL, wine: URL) -> Int {

        let path = url.standardizedFileURL.path.lowercased()

        let wineRoot = wine.deletingLastPathComponent().deletingLastPathComponent().standardizedFileURL.path.lowercased()

        var score = 0

        if path == "\(wineRoot)/lib" { score += 20_000 }

        if path == "\(wineRoot)/lib64" { score += 18_000 }

        if url.lastPathComponent.lowercased() == "lib" { score += 1_000 }

        if url.lastPathComponent.lowercased() == "lib64" { score += 800 }

        if path.contains("/lib/wine/") || path.contains("/lib64/wine/") { score -= 10_000 }

        return score

    }

    private func buildEngineResources(wine: URL, serverCandidates: [URL], libraryCandidates: [URL]) -> WineEngineResources? {

        let fm = FileManager.default

        let wineEntry = wine.standardizedFileURL

        let binDirectory = wineEntry.deletingLastPathComponent()

        let server = serverCandidates.first(where: { $0.deletingLastPathComponent().standardizedFileURL == binDirectory.standardizedFileURL }) ?? serverCandidates.first

        guard let server, isRealExecutableFile(server) else { return nil }

        guard let libraryPath = libraryCandidates.max(by: { libraryCandidateScore($0, wine: wineEntry) < libraryCandidateScore($1, wine: wineEntry) }) else { return nil }

        guard fm.fileExists(atPath: libraryPath.path) else { return nil }

        return WineEngineResources(wine: wineEntry, server: server.standardizedFileURL, libraryPath: libraryPath.standardizedFileURL)

    }

    private func resolveEngineResources(from root: URL) -> WineEngineResources? {

        let fm = FileManager.default

        guard fm.fileExists(atPath: root.path) else { return nil }

        guard let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .isExecutableKey], options: [.skipsHiddenFiles], errorHandler: { _, _ in true }) else { return nil }

        var wineCandidates: [URL] = []

        var serverCandidates: [URL] = []

        var libraryCandidates: [URL] = []

        for case let file as URL in enumerator {

            let name = file.lastPathComponent.lowercased()

            if (name == "wine64" || name == "wine"), isRealExecutableFile(file) { wineCandidates.append(file); continue }

            if name == "wineserver", isRealExecutableFile(file) { serverCandidates.append(file); continue }

            if name == "lib" || name == "lib64" {

                var isDirectory: ObjCBool = false

                if fm.fileExists(atPath: file.path, isDirectory: &isDirectory), isDirectory.boolValue { libraryCandidates.append(file) }

            }

        }

        guard let bestWine = wineCandidates.max(by: { wineCandidateScore($0) < wineCandidateScore($1) }) else { return nil }

        return buildEngineResources(wine: bestWine, serverCandidates: serverCandidates, libraryCandidates: libraryCandidates)

    }

    private func resolveStoredWineResources() -> WineEngineResources? {

        let fm = FileManager.default

        if !wine64Path.isEmpty {

            let stored = URL(fileURLWithPath: wine64Path).standardizedFileURL

            if isRealExecutableFile(stored), let scanned = resolveEngineResources(from: wineFolder) {

                return WineEngineResources(wine: stored, server: scanned.server, libraryPath: scanned.libraryPath)

            }

        }

        if let resources = resolveEngineResources(from: wineFolder) {

            wine64Path = resources.wine.path

            return resources

        }

        if !wine64Path.isEmpty && !fm.fileExists(atPath: wine64Path) { wine64Path = "" }

        return nil

    }

    private func checkWineReady() -> Bool {

        guard let resources = resolveStoredWineResources() else { wineReady = false; return false }

        wine64Path = resources.wine.path

        wineReady = true

        return true

    }

    // MARK: - Wine 安装

    private func extractWineArchive(_ archive: URL, to destination: URL) throws {

        let fm = FileManager.default

        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }

        try fm.createDirectory(at: destination, withIntermediateDirectories: true)

        let ext = archive.pathExtension.lowercased()

        let process = Process()

        let errorPipe = Pipe()

        process.standardError = errorPipe

        if ext == "zip" {

            process.executableURL = URL(fileURLWithPath: "/usr/bin/ditto")

            process.arguments = ["-x", "-k", archive.path, destination.path]

        } else {

            process.executableURL = URL(fileURLWithPath: "/usr/bin/tar")

            process.arguments = ["-xf", archive.path, "-C", destination.path]

        }

        try process.run()

        process.waitUntilExit()

        guard process.terminationStatus == 0 else {

            let data = errorPipe.fileHandleForReading.readDataToEndOfFile()

            let message = String(data: data, encoding: .utf8) ?? "未知错误"

            try? fm.removeItem(at: destination)

            throw NSError(domain: "YesPVZLauncher.WineInstall", code: Int(process.terminationStatus), userInfo: [NSLocalizedDescriptionKey: message.isEmpty ? "解压失败" : message])

        }

    }

    private func installWine(from archive: URL) {

        do {

            statusText = "📦正在解压 Wine..."

            try extractWineArchive(archive, to: wineFolder)

            ensureExecutablePermissions(in: wineFolder)

            removeQuarantine(in: wineFolder)

            guard let resources = resolveEngineResources(from: wineFolder) else {

                wineReady = false; statusText = "❌解压完成，但未找到有效的 wine64 或 wine 可执行文件"; return

            }

            wine64Path = resources.wine.path

            wineReady = true

            statusText = "✅Wine安装成功！\n\(resources.wine.path)"

        } catch {

            wineReady = false

            statusText = "❌安装失败: \(error.localizedDescription)"

        }

    }

    private func downloadWine() {

        var sourceIndex = 0

        func nextAttempt() {

            guard sourceIndex < ResourceLinkConfig.wineDownloadSources.count else { statusText = "❌所有下载源失败，请手动安装"; return }

            let url = ResourceLinkConfig.wineDownloadSources[sourceIndex]

            let suffix: String

            if url.lastPathComponent.lowercased().hasSuffix(".tar.gz") { suffix = "tar.gz" }

            else if !url.pathExtension.isEmpty { suffix = url.pathExtension }

            else { suffix = "archive" }

            let temporaryFile = FileManager.default.temporaryDirectory.appendingPathComponent("yespvz_wine_\(UUID().uuidString).\(suffix)")

            statusText = "🔽下载中（源\(sourceIndex + 1)/\(ResourceLinkConfig.wineDownloadSources.count)）..."

            downloader.download(url: url, to: temporaryFile) { result in

                switch result {

                case .success(let path): self.statusText = "✅下载完成，安装中..."; self.installWine(from: path); try? FileManager.default.removeItem(at: path)

                case .failure(let error): self.statusText = "❌源\(sourceIndex + 1)失败: \(error.localizedDescription)，换下一个..."; sourceIndex += 1; nextAttempt()

                }

            }

        }

        nextAttempt()

    }

    private func manualInstall() {

        let panel = NSOpenPanel()

        panel.title = "选择Wine压缩包"

        panel.canChooseFiles = true

        panel.canChooseDirectories = false

        panel.allowsMultipleSelection = false

        panel.allowedContentTypes = [UTType(filenameExtension: "xz")!, UTType(filenameExtension: "gz")!, UTType(filenameExtension: "tar")!, UTType(filenameExtension: "zip")!]

        guard panel.runModal() == .OK, let url = panel.url else { statusText = "❌未选择文件"; return }

        statusText = "📦安装中..."

        installWine(from: url)

        _ = checkWineReady()

    }

    // MARK: - Wine 进程状态

    private func syncWineProcessState(showMessage: Bool = false) {

        let staleIDs = runningProcesses.filter { !$0.value.isRunning }.map(\.key)

        for id in staleIDs { runningProcesses.removeValue(forKey: id) }

        if showMessage {

            statusText = hasRunningWineProcess ? "🔄 已刷新进程状态\n✅当前仍有 Wine 进程运行" : "🔄 已刷新进程状态\n当前没有由启动器跟踪的 Wine 进程"

        }

    }

    private func terminateRunningProcesses() {

        syncWineProcessState()

        for process in runningProcesses.values where process.isRunning {

            if let errPipe = process.standardError as? Pipe { errPipe.fileHandleForReading.readabilityHandler = nil }

            if let outPipe = process.standardOutput as? Pipe { outPipe.fileHandleForReading.readabilityHandler = nil }

            process.terminate()

        }

        appendStatus("⚠️已尝试发送优雅终止信号...")

        let killTask = Process()

        killTask.executableURL = URL(fileURLWithPath: "/usr/bin/killall")

        killTask.arguments = ["-9", "wine", "wine64", "wineserver"]

        do { try killTask.run(); killTask.waitUntilExit() } catch { appendStatus("⚠️强制终止命令执行失败: \(error.localizedDescription)") }

        runningProcesses.removeAll()

        stopAllCaffeinate()

        appendStatus("✅已执行强制物理终止 (Killall -9)！")

    }

    // MARK: - Wine 启动核心

    @discardableResult

    private func runWine(exe: URL, bottle: URL) -> Bool {

        syncWineProcessState()

        guard FileManager.default.fileExists(atPath: exe.path) else { appendStatus("❌找不到exe: \(exe.path)"); return false }

        guard checkWineReady(), let resources = resolveStoredWineResources() else { appendStatus("❌Wine未安装或 Wine loader 路径失效"); return false }

        do { try FileManager.default.createDirectory(at: bottle, withIntermediateDirectories: true) } catch { appendStatus("❌Bottle创建失败: \(error.localizedDescription)"); return false }

        removeQuarantine(in: exe.deletingLastPathComponent())

        removeQuarantine(in: wineFolder)

        removeQuarantine(in: bottle)

        ensureExecutablePermissions(in: wineFolder)

        let wine = resources.wine.standardizedFileURL

        guard isRealExecutableFile(wine) else { appendStatus("❌Wine loader 不是有效可执行文件: \(wine.path)"); return false }

        let process = Process()

        let processID = UUID()

        process.executableURL = wine

        process.currentDirectoryURL = exe.deletingLastPathComponent()

        var environment = ProcessInfo.processInfo.environment

        let oldFallback = environment["DYLD_FALLBACK_LIBRARY_PATH"] ?? ""

        let libraryPath = resources.libraryPath.path

        environment["WINEPREFIX"] = bottle.path

        environment["LANG"] = "zh_CN.UTF-8"

        environment["LC_ALL"] = "zh_CN.UTF-8"

        environment["WINELOADER"] = wine.path

        environment["WINESERVER"] = resources.server.path

        environment["WINELIB"] = libraryPath

        environment["DYLD_FALLBACK_LIBRARY_PATH"] = oldFallback.isEmpty ? libraryPath : "\(libraryPath):\(oldFallback)"

        // V8 修复：强制 OpenGL 渲染，彻底防后台卡死，并兼容老游戏（如游侠汉化2版）特定的位图字体渲染问题

        if forceOpenGLRender {

            environment["WINED3D_BACKEND"] = "OpenGL"

            environment["WINED3D_SOFTWARE"] = "1" // 强制CPU软件渲染，防止特定DDS位图字体竖杠/豆腐块

            environment["DXVK_HUD"] = "0"

        }

        // V8 优化：使用精确的日志过滤，防止卡死

        environment["WINEDEBUG"] = wineDebug ? "err+all,warn+all,fixme+all,+seh,+vulkan,+d3d,+dxgi" : "-all"

        process.environment = environment

        process.arguments = exe.pathExtension.lowercased() == "bat" ? ["cmd.exe", "/c", "start", "", exe.path] : [exe.path]

        let pipe = Pipe()

        process.standardOutput = pipe

        process.standardError = pipe

        // V8 优化：无论调试开关是否开启，均持续排空管道，避免 Wine 堵死

        let logQueue = DispatchQueue(label: "com.yespvzlauncher.wine.log.\(processID.uuidString)", qos: .utility)

        var pendingLog = ""

        var partialLine = ""

        var lastUIFlush = Date()

        let maxPendingCharacters = 10_000

        let minimumFlushInterval: TimeInterval = 0.8

        let importantKeywords = ["err:", "warn:", "fixme:", "exception", "unhandled", "kernelbase", "ntdll", "wineserver", "vulkan", "winevulkan", "dxvk", "d3d", "dxgi", "metal", "gptk", "fatal", "failed", "failure", "access denied"]

        func filteredImportantLines(from incoming: String) -> String {

            partialLine += incoming

            var lines = partialLine.components(separatedBy: .newlines)

            partialLine = lines.popLast() ?? ""

            let important = lines.filter { line in

                let lower = line.lowercased()

                return importantKeywords.contains(where: { lower.contains($0) })

            }

            guard !important.isEmpty else { return "" }

            return important.joined(separator: "\n") + "\n"

        }

        func flushPending(force: Bool = false) {

            logQueue.async {

                guard self.wineDebug else {

                    pendingLog.removeAll(keepingCapacity: true)

                    partialLine.removeAll(keepingCapacity: true)

                    return

                }

                let now = Date()

                guard force || now.timeIntervalSince(lastUIFlush) >= minimumFlushInterval else { return }

                if force, !partialLine.isEmpty {

                    let lower = partialLine.lowercased()

                    if importantKeywords.contains(where: { lower.contains($0) }) { pendingLog += partialLine + "\n" }

                    partialLine.removeAll(keepingCapacity: true)

                }

                guard !pendingLog.isEmpty else { return }

                let text = pendingLog

                pendingLog.removeAll(keepingCapacity: true)

                lastUIFlush = now

                DispatchQueue.main.async { self.appendWineLogToUI(text) }

            }

        }

        pipe.fileHandleForReading.readabilityHandler = { handle in

            let data = handle.availableData

            guard !data.isEmpty else { return }

            guard self.wineDebug, let text = String(data: data, encoding: .utf8) else { return }

            logQueue.async {

                let filtered = filteredImportantLines(from: text)

                if !filtered.isEmpty { pendingLog += filtered }

                if pendingLog.count > maxPendingCharacters {

                    pendingLog = "…本批关键日志已截断…\n" + String(pendingLog.suffix(maxPendingCharacters))

                }

                flushPending()

            }

        }

        process.terminationHandler = { finishedProcess in

            pipe.fileHandleForReading.readabilityHandler = nil

            flushPending(force: true)

            DispatchQueue.main.async {

                self.runningProcesses.removeValue(forKey: processID)

                self.stopCaffeinate(id: processID)

                let code = finishedProcess.terminationStatus

                if code == 0 {

                    self.appendStatus("✅Wine启动入口已正常结束（退出码 0）。注意：这不等于 Windows 游戏已经退出，Wine 可能已把实际进程交给 wineserver。")

                } else {

                    self.appendStatus("⚠️Wine启动入口异常结束或被第三方或用户手动退出（退出码 \(code)）")

                }

            }

        }

        do {

            try process.run()

            runningProcesses[processID] = process

            startCaffeinate(for: process, id: processID)

            appendStatus("✅已发送启动指令")

            return true

        } catch {

            pipe.fileHandleForReading.readabilityHandler = nil

            runningProcesses.removeValue(forKey: processID)

            stopCaffeinate(id: processID)

            appendStatus("❌启动失败: \(error.localizedDescription)")

            return false

        }

    }

    // MARK: - 启动游戏 / 修改器

    private func launchModifier() {

        syncWineProcessState()

        guard let toolID = selectedToolId, let tool = toolList.first(where: { $0.toolId == toolID }), let entry = selectedGameEntry, let storage = gameStorage(entry), let game = loadGameInfo(storage) else { statusText = "⚠️请选择修改器"; return }

        let exe = URL(fileURLWithPath: tool.toolRealPath)

        guard FileManager.default.fileExists(atPath: exe.path) else { statusText = "❌修改器文件已被移动或删除，请重新导入"; return }

        let bottle = getBottle(game, storage: storage)

        var launchExe = exe

        // 判断当前游戏是否是“复制”类型（即无软链接，直接是实体文件）

        if let attrs = try? FileManager.default.attributesOfItem(atPath: storage.path), attrs[.type] as? FileAttributeType != .typeSymbolicLink {

            let driveC = bottle.appendingPathComponent("drive_c")

            try? FileManager.default.createDirectory(at: driveC, withIntermediateDirectories: true)

            let destExe = driveC.appendingPathComponent(tool.toolName)

            let sourceModDate = (try? FileManager.default.attributesOfItem(atPath: exe.path))?[.modificationDate] as? Date

            let destModDate = (try? FileManager.default.attributesOfItem(atPath: destExe.path))?[.modificationDate] as? Date

            if !FileManager.default.fileExists(atPath: destExe.path) || sourceModDate != destModDate {

                if !FileManager.default.fileExists(atPath: destExe.path) {

                    do {

                        try FileManager.default.copyItem(at: exe, to: destExe)

                    } catch {

                        // 忽略复制失败，继续用原始路径启动

                    }

                }

            }

            launchExe = destExe

        }

        statusText = "⏳启动修改器: \(tool.toolName)\n🍷Bottle: \(bottle.path)"

        _ = runWine(exe: launchExe, bottle: bottle)

    }

    private func launchGame() {

        syncWineProcessState()

        guard let entry = selectedGameEntry else { statusText = "⚠️请选择游戏"; return }

        guard let storage = gameStorage(entry), let realFolder = resolveSymlink(storage), let game = loadGameInfo(storage) else { statusText = "❌游戏路径失效"; return }

        guard FileManager.default.fileExists(atPath: realFolder.path) else { statusText = "❌游戏原始文件夹不存在或软链接失效"; return }

        let exe = realFolder.appendingPathComponent(game.mainExeName)

        let bottle = getBottle(game, storage: storage)

        statusText = "⏳启动: \(realFolder.lastPathComponent)\n🍷Bottle: \(bottle.path)"

        _ = runWine(exe: exe, bottle: bottle)

    }

    // MARK: - 修改器导入

    private func importModifier() {

        let panel = NSOpenPanel()

        panel.canChooseFiles = true

        panel.canChooseDirectories = false

        panel.allowsMultipleSelection = false

        panel.title = "选择修改器exe"

        panel.allowedContentTypes = [UTType(filenameExtension: "exe")!]

        guard panel.runModal() == .OK, let exe = panel.url else { statusText = "❌取消"; return }

        guard !gameList.isEmpty else { statusText = "⚠️请先导入游戏"; return }

        var items: [(display: String, gameID: String)] = []

        for entry in gameList {

            guard let storage = gameStorage(entry), let game = loadGameInfo(storage) else { continue }

            items.append((entry, game.gameId))

        }

        guard !items.isEmpty else { statusText = "⚠️没有可绑定的有效游戏"; return }

        let alert = NSAlert()

        alert.messageText = "绑定修改器"

        alert.informativeText = "选择要绑定的游戏"

        alert.addButton(withTitle: "确认")

        alert.addButton(withTitle: "取消")

        let scroll = NSScrollView()

        scroll.hasVerticalScroller = true

        scroll.borderType = .bezelBorder

        scroll.frame = NSRect(x: 0, y: 0, width: 380, height: 240)

        let stack = NSStackView()

        stack.orientation = .vertical

        stack.alignment = .leading

        stack.spacing = 8

        stack.edgeInsets = NSEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)

        var buttons: [String: NSButton] = [:]

        for item in items {

            let checkbox = NSButton(checkboxWithTitle: item.display, target: nil, action: nil)

            checkbox.state = .on

            buttons[item.gameID] = checkbox

            stack.addArrangedSubview(checkbox)

        }

        stack.frame = NSRect(x: 0, y: 0, width: 360, height: max(240, stack.fittingSize.height))

        scroll.documentView = stack

        alert.accessoryView = scroll

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let selectedIDs = buttons.filter { $0.value.state == .on }.map(\.key)

        guard !selectedIDs.isEmpty else { statusText = "⚠️未选择游戏"; return }

        let tool = ToolInfo(toolId: UUID().uuidString, toolName: exe.lastPathComponent, toolRealPath: exe.path, bindGameIds: selectedIDs, note: "")

        saveTool(tool)

        loadTools()

        statusText = "✅修改器导入成功，绑定\(selectedIDs.count)个游戏"

    }

    // MARK: - 导入游戏

    private func importGame() {

        let panel = NSOpenPanel()

        panel.canChooseDirectories = true

        panel.canChooseFiles = false

        panel.allowsMultipleSelection = false

        panel.title = "选择解压完毕的PVZ游戏文件夹"

        guard panel.runModal() == .OK, let realGameFolder = panel.url else { statusText = "❌已取消导入"; return }

        let exeList: [URL]

        do {

            let allItems = try FileManager.default.contentsOfDirectory(at: realGameFolder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])

            exeList = allItems.filter { $0.pathExtension.lowercased() == "exe" }.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }

        } catch { statusText = "❌读取文件夹失败：\(error.localizedDescription)"; return }

        guard !exeList.isEmpty else { statusText = "❌文件夹找不到任何exe程序，不是游戏目录"; return }

        let mainExe: URL

        if exeList.count > 1 {

            let alertExe = NSAlert()

            alertExe.messageText = "检测到多个exe程序"

            alertExe.informativeText = "请选择【游戏主程序】，不要选择修改器"

            for exe in exeList { alertExe.addButton(withTitle: exe.lastPathComponent) }

            alertExe.addButton(withTitle: "取消")

            let response = alertExe.runModal()

            let index = response.rawValue - NSApplication.ModalResponse.alertFirstButtonReturn.rawValue

            guard index >= 0, index < exeList.count else { statusText = "❌已取消导入"; return }

            mainExe = exeList[index]

        } else { mainExe = exeList[0] }

        let alertType = NSAlert()

        alertType.messageText = "选择游戏类型"

        alertType.informativeText = "这个是原版PVZ，还是魔改/改版PVZ？"

        alertType.addButton(withTitle: "原版 Original")

        alertType.addButton(withTitle: "魔改 Modded")

        alertType.addButton(withTitle: "取消")

        let typeResponse = alertType.runModal()

        let subDirectoryName: String

        if typeResponse == .alertFirstButtonReturn { subDirectoryName = "Original" }

        else if typeResponse == .alertSecondButtonReturn { subDirectoryName = "Modded" }

        else { statusText = "❌已取消导入"; return }

        let alertCopy = NSAlert()

        alertCopy.messageText = "选择导入方式"

        alertCopy.informativeText = """

        🔗【软链接】速度快，不复制文件；不要移动/删除原始文件夹，否则游戏失效

        📂【复制】完整拷贝游戏到启动器内部，占用额外硬盘空间，不怕改动原文件

        """

        alertCopy.addButton(withTitle: "软链接导入")

        alertCopy.addButton(withTitle: "复制全部文件")

        alertCopy.addButton(withTitle: "取消")

        let copyResponse = alertCopy.runModal()

        let doCopy: Bool

        if copyResponse == .alertFirstButtonReturn { doCopy = false }

        else if copyResponse == .alertSecondButtonReturn { doCopy = true }

        else { statusText = "❌已取消导入"; return }

        let gameLibraryDirectory = appSupport.appendingPathComponent("Games").appendingPathComponent(subDirectoryName)

        do { try FileManager.default.createDirectory(at: gameLibraryDirectory, withIntermediateDirectories: true) }

        catch { statusText = "❌创建目录失败：\(error.localizedDescription)"; return }

        let folderName = realGameFolder.lastPathComponent

        let targetURL = gameLibraryDirectory.appendingPathComponent(folderName)

        if FileManager.default.fileExists(atPath: targetURL.path) {

            let overwriteAlert = NSAlert()

            overwriteAlert.messageText = "已存在同名游戏"

            overwriteAlert.informativeText = "是否覆盖启动器中的现有记录？"

            overwriteAlert.addButton(withTitle: "覆盖")

            overwriteAlert.addButton(withTitle: "取消")

            guard overwriteAlert.runModal() == .alertFirstButtonReturn else { statusText = "❌已取消导入"; return }

            do { try FileManager.default.removeItem(at: targetURL) }

            catch { statusText = "❌无法覆盖旧记录：\(error.localizedDescription)"; return }

        }

        if doCopy {

            do { try FileManager.default.copyItem(at: realGameFolder, to: targetURL); statusText = "✅复制导入成功 → \(subDirectoryName)/\(folderName)" }

            catch { statusText = "❌复制失败：\(error.localizedDescription)"; return }

        } else {

            do { try FileManager.default.createSymbolicLink(at: targetURL, withDestinationURL: realGameFolder); statusText = "✅软链接导入成功 → \(subDirectoryName)/\(folderName)" }

            catch { statusText = "❌创建软链接失败：\(error.localizedDescription)"; return }

        }

        let info = GameInfo(gameId: "\(subDirectoryName)-\(folderName)", gameType: subDirectoryName == "Original" ? "original" : "mod", mainExeName: mainExe.lastPathComponent, useSeparateBottle: defaultSeparateBottle)

        saveGameInfo(targetURL, info)

        refreshGames()

    }

    // MARK: - 删除数据

    private func removeGame(_ entry: String) {

        let alert = NSAlert()

        alert.messageText = "确认移除该游戏记录？"

        alert.informativeText = "只会删除启动器中的记录；软链接模式不会删除原始游戏文件。"

        alert.addButton(withTitle: "确认")

        alert.addButton(withTitle: "取消")

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        guard let storage = gameStorage(entry) else { statusText = "❌游戏记录无效"; return }

        do { if FileManager.default.fileExists(atPath: storage.path) { try FileManager.default.removeItem(at: storage) }; refreshGames(); statusText = "✅已移除游戏记录" }

        catch { statusText = "❌移除失败: \(error.localizedDescription)" }

    }

    private func removeTool(_ tool: ToolInfo) {

        let alert = NSAlert()

        alert.messageText = "确认删除修改器记录？"

        alert.addButton(withTitle: "确认")

        alert.addButton(withTitle: "取消")

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let file = toolsDir.appendingPathComponent("\(tool.toolId).json")

        do { if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }; loadTools(); if selectedToolId == tool.toolId { selectedToolId = nil }; statusText = "✅已移除修改器记录" }

        catch { statusText = "❌移除修改器失败: \(error.localizedDescription)" }

    }

    // MARK: - 程序退出清理

    private func cleanupBeforeTermination() {

        stopAllCaffeinate()

        for process in runningProcesses.values where process.isRunning {

            if let pipe = process.standardOutput as? Pipe { pipe.fileHandleForReading.readabilityHandler = nil }

            if let pipe = process.standardError as? Pipe { pipe.fileHandleForReading.readabilityHandler = nil }

            process.terminate()

        }

        let killTask = Process()

        killTask.executableURL = URL(fileURLWithPath: "/usr/bin/killall")

        killTask.arguments = ["-9", "wineserver", "wine64", "wine"]

        try? killTask.run()

    }

    // MARK: - UI

    var body: some View {

        TabView(selection: $selectedTab) {

            VStack(spacing: 18) {

                Text("Yes PVZ Launcher").font(.largeTitle).bold()

                Text("选择版本并启动").font(.title)

                Picker("游戏版本", selection: $selectedGameEntry) {

                    Text("--请选择--").tag(nil as String?)

                    ForEach(gameList, id: \.self) { entry in Text(entry).tag(entry as String?) }

                }.pickerStyle(.menu)

                HStack(spacing: 16) {

                    Button("打开目录") { guard let entry = selectedGameEntry else { statusText = "⚠️请选择游戏"; return }; openGameFolder(entry) }

                    Button("启动游戏") { launchGame() }.buttonStyle(.borderedProminent)

                }

                let tools = toolsForGame()

                if !tools.isEmpty {

                    VStack(spacing: 8) {

                        Text("绑定的修改器").font(.subheadline)

                        Picker("", selection: $selectedToolId) {

                            Text("--选择--").tag(nil as String?)

                            ForEach(tools, id: \.toolId) { tool in Text(tool.toolName).tag(tool.toolId as String?) }

                        }.pickerStyle(.menu)

                        Button("▶ 启动修改器") { launchModifier() }.disabled(selectedToolId == nil)

                    }

                }

                Spacer()

                ScrollView {

                    Text(statusText)

                        .foregroundColor(.secondary)

                        .font(.system(size: 11))

                        .textSelection(.enabled)

                }

                .frame(maxHeight: 100)

            }

            .padding(30)

            .tabItem { Label("启动", systemImage: "play") }

            .tag(0)

            // ✅ 传入共享 library

            DownloadView(showAppDetail: $showAppDetail, selectedGame: $selectedGame, library: sharedLibrary, statusText: statusText)

                .tabItem { Label("下载", systemImage: "square.and.arrow.down") }

                .tag(1)

            // MARK: 管理

            VStack(spacing: 20) {

                Text("游戏管理").font(.title).bold()

                HStack(spacing: 12) {

                    Button("导入游戏") { importGame() }

                    Button("导入修改器") { importModifier() }

                    Button("导出存档") { exportSaveData() }

                    Button("导入存档") { importSaveData() }

                }

                VStack(alignment: .leading) {

                    Text("游戏列表").font(.headline).padding(.bottom, 4)

                    if gameList.isEmpty { Text("暂无游戏").foregroundColor(.secondary).font(.subheadline) }

                    else {

                        ScrollView {

                            VStack(spacing: 8) {

                                ForEach(gameList, id: \.self) { entry in

                                    HStack {

                                        Text(entry); Spacer()

                                        Button("在访达中显示") { openGameFolder(entry) }

                                        Button("移除") { removeGame(entry) }

                                    }

                                }

                            }

                        }.frame(maxHeight: 180)

                    }

                }

                Divider()

                VStack(alignment: .leading) {

                    Text("修改器列表").font(.headline).padding(.bottom, 4)

                    if toolList.isEmpty { Text("暂无修改器").foregroundColor(.secondary).font(.subheadline) }

                    else {

                        ScrollView {

                            VStack(spacing: 8) {

                                ForEach(toolList, id: \.toolId) { tool in

                                    HStack {

                                        Text(tool.toolName); Spacer()

                                        Button("在访达中显示") {

                                            let url = URL(fileURLWithPath: tool.toolRealPath)

                                            if FileManager.default.fileExists(atPath: url.path) { NSWorkspace.shared.activateFileViewerSelecting([url]) }

                                            else { statusText = "❌修改器文件已被移动或删除" }

                                        }

                                        Button("移除") { removeTool(tool) }

                                    }

                                }

                            }

                        }.frame(maxHeight: 150)

                    }

                }

                Spacer()

                ScrollView {

                    Text(statusText).foregroundColor(.secondary)

                }

                .frame(maxHeight: 100)

            }

            .padding(30)

            .tabItem { Label("管理", systemImage: "folder") }

            .tag(2)

            // MARK: 设置

            ScrollView {

                VStack(spacing: 20) {

                    Text("设置").font(.title).bold()

                    Text("数据目录: \(appSupport.path)").font(.system(size: 11))

                    Button("打开数据文件夹") { NSWorkspace.shared.open(appSupport) }

                    Divider()

                    Text("运行引擎(Wine)").font(.headline)

                    VStack(spacing: 10) {

                        HStack {

                            Button("在线下载安装") { downloadWine() }.disabled(downloader.isDownloading)

                            Button("手动选择安装包") { manualInstall() }

                        }

                        Text("（如您自己使用的引擎安装包无法正常玩游戏，请更换在线下载安装）")

                            .font(.caption).foregroundColor(.secondary)

                        if downloader.isDownloading {

                            HStack {

                                ProgressView(value: downloader.progress).frame(width: 200)

                                Text(String(format: "%.0f%%", downloader.progress * 100)).font(.caption)

                            }

                        }

                        Text(wineReady ? "✅已就绪" : "⚠️未安装")

                        if !wine64Path.isEmpty { Text("Wine: \(wine64Path)").font(.system(size: 10)).foregroundColor(.secondary) }

                    }

                    Divider()

                    Text("偏好设置").font(.headline)

                    VStack(spacing: 10) {

                        Toggle("新游戏默认独立Bottle", isOn: $defaultSeparateBottle)

                        Toggle("Wine调试日志（开启可能导致游戏掉帧）", isOn: $wineDebug)

                    }

                    Divider()

                    Text("防冻结设置").font(.headline)

                    VStack(spacing: 10) {

                        Toggle("系统保活 (Caffeinate)", isOn: $enableKeepAlive)

                        Toggle("强制 OpenGL 渲染 (彻底防后台卡死，或兼容老游戏渲染问题)", isOn: $forceOpenGLRender)

                    }

                    Divider()

                    Text("维护").font(.headline)

                    HStack(spacing: 12) {

                        Button("清空全局Bottle") {

                            let alert = NSAlert()

                            alert.messageText = "确认清空？"

                            alert.informativeText = "存档和注册表会丢失"

                            alert.addButton(withTitle: "确认")

                            alert.addButton(withTitle: "取消")

                            if alert.runModal() == .alertFirstButtonReturn {

                                do { if FileManager.default.fileExists(atPath: globalBottle.path) { try FileManager.default.removeItem(at: globalBottle) }; statusText = "✅已清空" }

                                catch { statusText = "❌清空失败: \(error.localizedDescription)" }

                            }

                        }.foregroundColor(.red)

                        Button("重置全部数据") {

                            let alert = NSAlert()

                            alert.messageText = "确认重置？"

                            alert.informativeText = "所有配置将删除"

                            alert.addButton(withTitle: "确认")

                            alert.addButton(withTitle: "取消")

                            if alert.runModal() == .alertFirstButtonReturn {

                                terminateRunningProcesses()

                                do {

                                    if FileManager.default.fileExists(atPath: appSupport.path) { try FileManager.default.removeItem(at: appSupport) }

                                    gameList.removeAll(); toolList.removeAll(); selectedGameEntry = nil; selectedToolId = nil; wineReady = false; wine64Path = ""

                                    statusText = "✅已重置，请重启"

                                } catch { statusText = "❌重置失败: \(error.localizedDescription)" }

                            }

                        }.foregroundColor(.red)

                    }

                    Divider()

                    Text("关于启动器").font(.headline)

                    VStack(spacing: 10) {

                        Text("当前版本:9.0")

                            .font(.caption).foregroundColor(.secondary)

                        HStack(spacing: 12) {

                            Button("关于我们工作室") { openExactResourceLink(ResourceLinkConfig.link1) }

                            Button("Github发布页面") { openExactResourceLink(ResourceLinkConfig.link2) }

                            Button("反馈bug") { openExactResourceLink(ResourceLinkConfig.link3) }

                        }

                        .frame(maxWidth: .infinity)

                        Button("用户帮助") { showHelp = true }

                    }

                    Spacer()

                    ScrollView {

                        Text(statusText)

                            .foregroundColor(.secondary)

                            .font(.system(size: 11))

                            .textSelection(.enabled)

                    }

                    .frame(maxHeight: 100)

                }

            }

            .padding(30)

            .tabItem { Label("设置", systemImage: "gearshape") }

            .tag(3)

        }

        .id(resetID)   // ✅ 全局重置视图身份

        .frame(minWidth: 720, minHeight: 620)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

        .toolbar {

            ToolbarItem(placement: .automatic) {

                HStack(spacing: 8) {

                    // 停止按钮：只杀进程（不变）

                    GlassActionButton(systemIcon: "stop.fill", tintColor: .red, isEnabled: hasRunningWineProcess) {

                        terminateRunningProcesses()

                    }

                    // ✅ 刷新按钮：清缓存 + 重置视图 + 重载数据（不动进程）

                    GlassActionButton(systemIcon: "arrow.triangle.2.circlepath", tintColor: .blue, isEnabled: true) {

                        // 1. 清空图片缓存

                        URLCache.shared.removeAllCachedResponses()



                        // 2. 重新加载所有数据

                        sharedLibrary.load(manualRefresh: true)

                        refreshGames()

                        loadTools()

                        wineReady = checkWineReady()

                        // 3. 刷新 Wine 进程状态（保留原有功能）

                        syncWineProcessState(showMessage: true)

                        // 4. 重置选中状态（回到干净状态）

                        selectedGameEntry = nil

                        selectedToolId = nil



                        // 5. 日志反馈

                        appendStatus("🔄 已执行全局刷新（缓存已清空，数据已重载）")

                    }

                }

                .padding(.trailing, 0)

            }

        }

        .sheet(isPresented: $showHelp) {

            HelpView()

        }

        // 已移除 .sheet(isPresented: $showAppDetail)，因为现在由 DownloadView 自己管理

        .onAppear {

            refreshGames()

            loadTools()

            wineReady = checkWineReady()

            NotificationCenter.default.addObserver(forName: NSApplication.willTerminateNotification, object: nil, queue: .main) { _ in cleanupBeforeTermination() }

        }

        .onChange(of: gameList) { _, newList in

            if let selected = selectedGameEntry, !newList.contains(selected) { selectedGameEntry = nil; selectedToolId = nil }

        }

        .onChange(of: selectedGameEntry) { _, _ in selectedToolId = nil }

    }

}

// MARK: - 下载页组件（使用共享 library）

struct DownloadView: View {

    @Binding var showAppDetail: Bool

    @Binding var selectedGame: GameItem?

    @ObservedObject var library: RemoteGameLibrary

    @State private var showAllApps = false

    @State private var detailGame: GameItem? = nil

    @State private var searchText = ""

    @State private var isSearching = false

    var statusText: String

    // ✅ 缓存随机数据（只在数据刷新时更新）

    @State private var topBannerItems: [(game: GameItem, index: Int)] = []

    @State private var favoriteGames: [GameItem] = []

    @State private var selectedGames: [GameItem] = []

    @State private var hotGames: [GameItem] = []

    @State private var tweetGames: [GameItem] = []

    @State private var newGames: [GameItem] = []

    var filteredItems: [GameItem] {

        if searchText.isEmpty {

            return library.items

        } else {

            return library.items.filter {

                $0.name.localizedCaseInsensitiveContains(searchText) ||

                String($0.id).localizedCaseInsensitiveContains(searchText)

            }

        }

    }

    // ✅ 重新生成随机选择（只在 library.items 变化或手动刷新时调用）

    private func regenerateRandomSelections() {

        let items = library.items

        guard !items.isEmpty else {

            topBannerItems = []

            favoriteGames = []

            selectedGames = []

            hotGames = []

            tweetGames = []

            newGames = []

            return

        }

        let shuffled = items.shuffled()

        let count = min(8, shuffled.count)

        topBannerItems = (0..<count).map { i in

            let game = shuffled[i]

            let index = [4,5,6,7,8].randomElement()!

            return (game, index)

        }

        favoriteGames = items.shuffled()

        selectedGames = items.shuffled()

        hotGames = items.shuffled()

        tweetGames = items.shuffled()

        newGames = items.shuffled()

    }

    var body: some View {

        ZStack(alignment: .top) {

            // loading 和错误提示

            VStack {

                if library.isLoading {

                    ProgressView("正在拉取游戏库…")

                        .controlSize(.small)

                }

                if let err = library.errorMessage, library.items.isEmpty {

                    Text(err)

                        .foregroundColor(.red)

                    Button("重试加载") {

                        library.load(manualRefresh:true)

                    }

                }

            }

            .padding(.top,80)

            ScrollView {

                VStack(alignment: .leading, spacing: 20) {

                    Color.clear.frame(height: 80)

                    // ✅ 顶部大图 - 使用缓存数据（图文绑定）

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            if topBannerItems.isEmpty {

                                ForEach(0..<8, id: \.self) { _ in

                                    TopBannerCardView(onTap: {})

                                }

                            } else {

                                ForEach(topBannerItems.indices, id: \.self) { idx in

                                    let item = topBannerItems[idx]

                                    let game = item.game

                                    let index = item.index

                                    TopBannerCardView(

                                        imageURL: game.adImageURL(for: index) ?? "",

                                        title: game.subtitle(for: index) ?? game.name,

                                        onTap: {

                                            detailGame = game

                                        }

                                    )

                                }

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    .frame(height: 300)

                    HStack {

                        Text("为你推荐").font(.title3).bold()

                        Spacer()

                        Button("查看全部") { showAllApps = true }

                            .buttonStyle(.plain)

                            .foregroundColor(.blue)

                    }

                    .padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(library.items) { item in

                            CompactAppGridItem(

                                link: item.link,

                                name: item.name,

                                subtitle: item.subtitle,

                                imageURL: item.icon ?? "",

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 小图标区域（8个） - 使用缓存

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = favoriteGames.count >= 8 ? Array(favoriteGames.prefix(8)) : favoriteGames

                            ForEach(display) { item in

                                SmallAppItem(

                                    imageURL: item.icon ?? "",

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 我们喜爱的APP和游戏 - 使用缓存

                    Text("我们喜爱的APP和游戏").font(.title3).bold().padding(.leading)

                    let displayedFavorites = favoriteGames.count >= 9 ? Array(favoriteGames.prefix(9)) : favoriteGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(displayedFavorites) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            ResponsiveAppCard(

                                imageURL: imageURL,

                                name: item.name,

                                subtitle: item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 精选 - 使用缓存

                    Text("精选").font(.title3).bold().padding(.leading)

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = selectedGames.count >= 4 ? Array(selectedGames.prefix(4)) : selectedGames

                            ForEach(display) { item in

                                let previews = item.previews ?? []

                                let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                                let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                                SmallAppItem(

                                    imageURL: imageURL,

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 热门佳作 - 使用缓存

                    Text("热门佳作").font(.title3).bold().padding(.leading)

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(spacing: 15) {

                            let display = hotGames.count >= 5 ? Array(hotGames.prefix(5)) : hotGames

                            ForEach(display) { item in

                                let previews = item.previews ?? []

                                let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                                let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                                SmallAppItem(

                                    imageURL: imageURL,

                                    name: item.name,

                                    onTap: {

                                        detailGame = item

                                    }

                                )

                            }

                        }

                        .padding(.horizontal, 10)

                    }

                    // ✅ 今日推荐 - 使用缓存

                    Text("今日推荐").font(.title3).bold().padding(.leading)

                    let displayedTweets = tweetGames.count >= 6 ? Array(tweetGames.prefix(6)) : tweetGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 20)], spacing: 20) {

                        ForEach(displayedTweets) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            TweetItem(

                                imageURL: imageURL,

                                title: item.subtitle9 ?? item.name,

                                subtitle: item.subtitle10 ?? item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    // ✅ 新品推荐 - 使用缓存

                    Text("新品推荐").font(.title3).bold().padding(.leading)

                    let displayedNew = newGames.count >= 6 ? Array(newGames.prefix(6)) : newGames

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(displayedNew) { item in

                            let previews = item.previews ?? []

                            let adPreviews = previews.count > 5 ? Array(previews.suffix(5)) : previews

                            let imageURL = adPreviews.isEmpty ? "" : adPreviews.randomElement()!

                            ResponsiveAppCard(

                                imageURL: imageURL,

                                name: item.name,

                                subtitle: item.subtitle,

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                    HStack {

                        Text("为你推荐").font(.title3).bold()

                        Spacer()

                        Button("查看全部") { showAllApps = true }

                            .buttonStyle(.plain)

                            .foregroundColor(.blue)

                    }

                    .padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                        ForEach(library.items) { item in

                            CompactAppGridItem(

                                link: item.link,

                                name: item.name,

                                subtitle: item.subtitle,

                                imageURL: item.icon ?? "",

                                onTap: {

                                    detailGame = item

                                }

                            )

                        }

                    }

                }

                .padding(30)

            }

            .padding(30)

            .sheet(isPresented: $showAllApps) {

                AllAppsListView()

            }

            // ✅ 搜索框（覆盖层）

            VStack(spacing: 0) {

                HStack {

                    Image(systemName: "magnifyingglass")

                        .foregroundColor(.secondary)

                    TextField("搜索游戏名称", text: $searchText, onEditingChanged: { editing in

                        withAnimation(.easeInOut(duration: 0.15)) {

                            isSearching = editing && !searchText.isEmpty

                        }

                    })

                    .textFieldStyle(.plain)

                    .onChange(of: searchText) { _, newValue in

                        withAnimation(.easeInOut(duration: 0.15)) {

                            isSearching = !newValue.isEmpty

                        }

                    }

                    if !searchText.isEmpty {

                        Button(action: {

                            searchText = ""

                            isSearching = false

                        }) {

                            Image(systemName: "xmark.circle.fill")

                                .foregroundColor(.secondary)

                        }

                        .buttonStyle(.plain)

                    }

                }

                .padding(10)

                .background(.ultraThinMaterial)

                .cornerRadius(10)

                .padding(.horizontal, 30)

                .padding(.top, 10)

                if isSearching && !filteredItems.isEmpty {

                    ScrollView {

                        VStack(alignment: .leading, spacing: 4) {

                            ForEach(filteredItems) { item in

                                HStack {

                                    if let url = URL(string: item.icon ?? "") {

                                        CachedAsyncImage(url: url) { phase in

                                            switch phase {

                                            case .success(let image):

                                                image.resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                            default:

                                                Image("placeholder").resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                            }

                                        }

                                    } else {

                                        Image("placeholder").resizable().scaledToFill().frame(width: 30, height: 30).cornerRadius(6)

                                    }

                                    VStack(alignment: .leading, spacing: 2) {

                                        Text(item.name).font(.headline)

                                        Text(item.subtitle).font(.caption).foregroundColor(.secondary)

                                    }

                                    Spacer()

                                    Text(item.subtitle)

                                        .font(.caption)

                                        .foregroundColor(.secondary)

                                        .lineLimit(1)

                                }

                                .padding(.horizontal, 12)

                                .padding(.vertical, 8)

                                .contentShape(Rectangle())

                                .onTapGesture {

                                    detailGame = item

                                    searchText = ""

                                    isSearching = false

                                }

                                Divider()

                            }

                        }

                        .padding(.vertical, 4)

                    }

                    .frame(maxHeight: 250)

                    .background(.regularMaterial)

                    .cornerRadius(10)

                    .padding(.horizontal, 30)

                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)

                } else if isSearching && filteredItems.isEmpty && !searchText.isEmpty {

                    HStack {

                        Text("未找到匹配的游戏")

                            .foregroundColor(.secondary)

                            .padding()

                        Spacer()

                    }

                    .frame(maxWidth: .infinity)

                    .background(.regularMaterial)

                    .cornerRadius(10)

                    .padding(.horizontal, 30)

                    .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)

                }

                Spacer()

            }

            .padding(.bottom, 0)

        }

        .sheet(item: $detailGame) { game in

            AppDetailView(game: game)

        }

        .onAppear {

            library.load(manualRefresh: false)

            regenerateRandomSelections()

        }

        .onChange(of: library.items) { _, _ in

            regenerateRandomSelections()

        }

    }

}

extension GameItem: Equatable {}//布丁

// MARK: - GameItem 扩展（用于图文绑定）

extension GameItem {

    func subtitle(for index: Int) -> String? {

        switch index {

        case 4: return subtitle4

        case 5: return subtitle5

        case 6: return subtitle6

        case 7: return subtitle7

        case 8: return subtitle8

        default: return nil

        }

    }

    func adImageURL(for index: Int) -> String? {

        let adOffset = index - 3  // 4->1, 5->2, 6->3, 7->4, 8->5

        guard let previews = previews, previews.count >= 5 + adOffset else { return nil }

        return previews[previews.count - 5 + (adOffset - 1)]

    }

}

// MARK: - V9.1.1 远程图片缓存与缩略图解码

private final class RemoteImagePipeline {
    static let shared = RemoteImagePipeline()

    private let memoryCache = NSCache<NSURL, NSImage>()
    private let lock = NSLock()
    private var inFlight: [URL: [(Result<NSImage, Error>) -> Void]] = [:]
    private let session: URLSession

    private init() {
        memoryCache.countLimit = 180
        memoryCache.totalCostLimit = 220 * 1024 * 1024

        let diskCache = URLCache(
            memoryCapacity: 96 * 1024 * 1024,
            diskCapacity: 512 * 1024 * 1024,
            diskPath: "YesPVZLauncherRemoteImages"
        )
        let configuration = URLSessionConfiguration.default
        configuration.urlCache = diskCache
        configuration.requestCachePolicy = .returnCacheDataElseLoad
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 60
        configuration.httpMaximumConnectionsPerHost = 6
        session = URLSession(configuration: configuration)
    }

    func cachedImage(for url: URL) -> NSImage? {
        memoryCache.object(forKey: url as NSURL)
    }

    func load(
        _ url: URL,
        maxPixelSize: CGFloat = 2400,
        completion: @escaping (Result<NSImage, Error>) -> Void
    ) {
        if let image = cachedImage(for: url) {
            completion(.success(image))
            return
        }

        lock.lock()
        if inFlight[url] != nil {
            inFlight[url]?.append(completion)
            lock.unlock()
            return
        }
        inFlight[url] = [completion]
        lock.unlock()

        var request = URLRequest(url: url)
        request.cachePolicy = .returnCacheDataElseLoad
        request.timeoutInterval = 20

        session.dataTask(with: request) { [weak self] data, _, error in
            guard let self else { return }

            let result: Result<NSImage, Error>
            if let error {
                result = .failure(error)
            } else if let data, let image = self.downsample(data: data, maxPixelSize: maxPixelSize) {
                let cost = max(1, Int(image.size.width * image.size.height * 4))
                self.memoryCache.setObject(image, forKey: url as NSURL, cost: cost)
                result = .success(image)
            } else {
                result = .failure(NSError(
                    domain: "YesPVZLauncher.RemoteImage",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: "图片数据无法解析"]
                ))
            }

            self.lock.lock()
            let callbacks = self.inFlight.removeValue(forKey: url) ?? []
            self.lock.unlock()

            DispatchQueue.main.async {
                callbacks.forEach { $0(result) }
            }
        }.resume()
    }

    func prefetch(_ urls: [URL]) {
        for url in urls.prefix(24) {
            if cachedImage(for: url) != nil { continue }
            load(url, maxPixelSize: 1400) { _ in }
        }
    }

    private func downsample(data: Data, maxPixelSize: CGFloat) -> NSImage? {
        let options: [CFString: Any] = [
            kCGImageSourceShouldCache: false
        ]
        guard let source = CGImageSourceCreateWithData(data as CFData, options as CFDictionary) else {
            return NSImage(data: data)
        }

        let downsampleOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
        ]

        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(
            source,
            0,
            downsampleOptions as CFDictionary
        ) else {
            return NSImage(data: data)
        }

        return NSImage(
            cgImage: cgImage,
            size: NSSize(width: cgImage.width, height: cgImage.height)
        )
    }
}

private final class CachedImageLoader: ObservableObject {
    @Published var phase: AsyncImagePhase = .empty

    private var representedURL: URL?

    func load(url: URL?) {
        guard representedURL != url else { return }
        representedURL = url

        guard let url else {
            phase = .empty
            return
        }

        if let cached = RemoteImagePipeline.shared.cachedImage(for: url) {
            phase = .success(Image(nsImage: cached))
            return
        }

        phase = .empty
        RemoteImagePipeline.shared.load(url) { [weak self] result in
            guard let self, self.representedURL == url else { return }
            switch result {
            case .success(let image):
                self.phase = .success(Image(nsImage: image))
            case .failure(let error):
                self.phase = .failure(error)
            }
        }
    }
}

private struct CachedAsyncImage<Content: View>: View {
    let url: URL?
    let content: (AsyncImagePhase) -> Content

    @StateObject private var loader = CachedImageLoader()

    init(url: URL?, @ViewBuilder content: @escaping (AsyncImagePhase) -> Content) {
        self.url = url
        self.content = content
    }

    var body: some View {
        content(loader.phase)
            .onAppear { loader.load(url: url) }
            .onChange(of: url) { _, newURL in
                loader.load(url: newURL)
            }
    }
}

// macOS 触控板两指横向滑动支持。事件仍返回系统，不阻断普通鼠标/键盘操作。
private struct HorizontalScrollSwipeMonitor: NSViewRepresentable {
    let onPrevious: () -> Void
    let onNext: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPrevious: onPrevious, onNext: onNext)
    }

    func makeNSView(context: Context) -> NSView {
        let view = NSView(frame: .zero)
        DispatchQueue.main.async { context.coordinator.start() }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        context.coordinator.onPrevious = onPrevious
        context.coordinator.onNext = onNext
    }

    static func dismantleNSView(_ nsView: NSView, coordinator: Coordinator) {
        coordinator.stop()
    }

    final class Coordinator {
        var onPrevious: () -> Void
        var onNext: () -> Void
        private var monitor: Any?
        private var accumulatedX: CGFloat = 0
        private var lastTrigger = Date.distantPast

        init(onPrevious: @escaping () -> Void, onNext: @escaping () -> Void) {
            self.onPrevious = onPrevious
            self.onNext = onNext
        }

        func start() {
            guard monitor == nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                guard let self else { return event }

                let x = event.scrollingDeltaX
                let y = event.scrollingDeltaY
                guard abs(x) > abs(y), abs(x) > 0.1 else { return event }

                accumulatedX += x
                let now = Date()
                guard now.timeIntervalSince(lastTrigger) > 0.28 else { return event }

                if accumulatedX <= -55 {
                    accumulatedX = 0
                    lastTrigger = now
                    onNext()
                } else if accumulatedX >= 55 {
                    accumulatedX = 0
                    lastTrigger = now
                    onPrevious()
                }

                if event.phase == .ended || event.momentumPhase == .ended {
                    accumulatedX = 0
                }
                return event
            }
        }

        func stop() {
            if let monitor {
                NSEvent.removeMonitor(monitor)
                self.monitor = nil
            }
        }

        deinit { stop() }
    }
}

// MARK: - 放大图片后的 Mac 触控板平移监听
// 仅在图片已经放大时启用。
// 这里不负责翻页，只把两指滚动增量累加到当前图片位置，
// 因此不会出现上一版那种“重新落指后跳回头部”的问题。
private struct ZoomedImageTrackpadPanMonitor: NSViewRepresentable {
    let isEnabled: Bool
    let onScroll: (CGFloat, CGFloat) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(isEnabled: isEnabled, onScroll: onScroll)
    }

    func makeNSView(context: Context) -> NSView {
        let view = NSView(frame: .zero)
        DispatchQueue.main.async {
            context.coordinator.start()
        }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        context.coordinator.isEnabled = isEnabled
        context.coordinator.onScroll = onScroll
    }

    static func dismantleNSView(_ nsView: NSView, coordinator: Coordinator) {
        coordinator.stop()
    }

    final class Coordinator {
        var isEnabled: Bool
        var onScroll: (CGFloat, CGFloat) -> Void
        private var monitor: Any?

        init(isEnabled: Bool, onScroll: @escaping (CGFloat, CGFloat) -> Void) {
            self.isEnabled = isEnabled
            self.onScroll = onScroll
        }

        func start() {
            guard monitor == nil else { return }

            monitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                guard let self, self.isEnabled else { return event }

                let dx = event.scrollingDeltaX
                let dy = event.scrollingDeltaY

                guard abs(dx) > 0.01 || abs(dy) > 0.01 else {
                    return event
                }

                // 在放大状态下，两指滚动只移动当前图片，不交给外层分页 ScrollView。
                self.onScroll(dx, dy)
                return nil
            }
        }

        func stop() {
            if let monitor {
                NSEvent.removeMonitor(monitor)
                self.monitor = nil
            }
        }

        deinit {
            stop()
        }
    }
}

// MARK: - App 详情页

struct AppDetailView: View {
    @Environment(\.dismiss) private var dismiss

    let game: GameItem?

    @State private var selectedPreviewIndex: Int? = nil

    // 当前图片缩放状态。
    @State private var previewScale: CGFloat = 1
    @State private var previewLastScale: CGFloat = 1

    // 双击时记录鼠标位置，用它作为放大锚点。
    @State private var previewZoomAnchor: UnitPoint = .center

    // 放大后的图片平移。
    @State private var previewPanOffset: CGSize = .zero
    @State private var previewPanBase: CGSize = .zero

    init(game: GameItem? = nil) {
        self.game = game
    }

    private var detailPreviews: [String] {
        Array((game?.previews ?? []).prefix(5))
    }

    private func resetPreviewTransform(animated: Bool = false) {
        let update = {
            previewScale = 1
            previewLastScale = 1
            previewZoomAnchor = .center
            previewPanOffset = .zero
            previewPanBase = .zero
        }

        if animated {
            withAnimation(.spring(response: 0.26, dampingFraction: 0.86)) {
                update()
            }
        } else {
            update()
        }
    }

    private func openPreview(_ index: Int) {
        guard detailPreviews.indices.contains(index) else { return }
        resetPreviewTransform()
        selectedPreviewIndex = index
    }

    private func closePreview() {
        resetPreviewTransform()
        withAnimation(.easeOut(duration: 0.14)) {
            selectedPreviewIndex = nil
        }
    }

    private func previousPreview() {
        guard previewScale <= 1.01,
              let index = selectedPreviewIndex,
              index > 0 else { return }

        resetPreviewTransform()
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedPreviewIndex = index - 1
        }
    }

    private func nextPreview() {
        guard previewScale <= 1.01,
              let index = selectedPreviewIndex,
              index < detailPreviews.count - 1 else { return }

        resetPreviewTransform()
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedPreviewIndex = index + 1
        }
    }

    private func clampPan(_ proposed: CGSize, size: CGSize) -> CGSize {
        guard previewScale > 1 else { return .zero }

        // 图片显示框本身略小于详情页，按实际显示框估算可拖动范围。
        let imageWidth = max(240, size.width - 120)
        let imageHeight = max(240, size.height - 70)

        let extraX = max(0, imageWidth * (previewScale - 1) / 2)
        let extraY = max(0, imageHeight * (previewScale - 1) / 2)

        // 留一点余量，避免边缘永远贴不出来。
        let maxX = extraX + 32
        let maxY = extraY + 32

        return CGSize(
            width: min(max(proposed.width, -maxX), maxX),
            height: min(max(proposed.height, -maxY), maxY)
        )
    }

    var body: some View {
        ZStack {
            detailPage
                .allowsHitTesting(selectedPreviewIndex == nil)

            if let index = selectedPreviewIndex,
               detailPreviews.indices.contains(index) {
                previewOverlay
                    .transition(.opacity)
                    .zIndex(100)
            }
        }
        .frame(minWidth: 600, minHeight: 500)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(nsColor: .windowBackgroundColor))
        .onChange(of: selectedPreviewIndex) { _, newValue in
            if newValue != nil {
                resetPreviewTransform()
            }
        }
    }

    // MARK: 普通详情页

    private var detailPage: some View {
        HStack(spacing: 0) {
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
                .padding()

                Spacer()
            }
            .frame(width: 60)

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let game {
                        Group {
                            HStack {
                                if let url = URL(string: game.icon ?? "") {
                                    CachedAsyncImage(url: url) { phase in
                                        switch phase {
                                        case .success(let image):
                                            image
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 60, height: 60)
                                                .cornerRadius(12)
                                        default:
                                            Image("placeholder")
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 60, height: 60)
                                                .cornerRadius(12)
                                        }
                                    }
                                } else {
                                    Image("placeholder")
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 60, height: 60)
                                        .cornerRadius(12)
                                }

                                VStack(alignment: .leading) {
                                    Text(game.name)
                                        .font(.title)
                                        .bold()

                                    Text(game.subtitle)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }

                                Spacer()

                                Button("下载") {
                                    if let url = URL(string: game.link) {
                                        NSWorkspace.shared.open(url)
                                    }
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding()

                            Divider()

                            Text(game.subtitle2 ?? game.subtitle)
                                .padding()

                            Divider()

                            if !detailPreviews.isEmpty {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 12) {
                                        ForEach(Array(detailPreviews.enumerated()), id: \.offset) { index, urlString in
                                            Button {
                                                openPreview(index)
                                            } label: {
                                                if let url = URL(string: urlString) {
                                                    CachedAsyncImage(url: url) { phase in
                                                        switch phase {
                                                        case .success(let image):
                                                            image
                                                                .resizable()
                                                                .scaledToFit()
                                                                .frame(height: 200)
                                                                .cornerRadius(12)
                                                        default:
                                                            Image("placeholder")
                                                                .resizable()
                                                                .scaledToFit()
                                                                .frame(height: 200)
                                                                .cornerRadius(12)
                                                        }
                                                    }
                                                } else {
                                                    Image("placeholder")
                                                        .resizable()
                                                        .scaledToFit()
                                                        .frame(height: 200)
                                                        .cornerRadius(12)
                                                }
                                            }
                                            .buttonStyle(.plain)
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                                .padding(.vertical, 8)
                            } else if let url = URL(string: game.icon ?? "") {
                                CachedAsyncImage(url: url) { phase in
                                    switch phase {
                                    case .success(let image):
                                        image
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxHeight: 300)
                                            .cornerRadius(12)
                                    default:
                                        Image("placeholder")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxHeight: 300)
                                            .cornerRadius(12)
                                    }
                                }
                                .padding()
                            } else {
                                Image("placeholder")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxHeight: 300)
                                    .cornerRadius(12)
                                    .padding()
                            }
                        }
                        .id(game.id)
                    } else {
                        HStack {
                            Image("placeholder")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .cornerRadius(12)

                            VStack(alignment: .leading) {
                                Text("应用名称").font(.title).bold()
                                Text("免费，无内购").font(.caption).foregroundColor(.secondary)
                            }

                            Spacer()

                            Button("下载") { }
                                .buttonStyle(.borderedProminent)
                        }
                        .padding()

                        Divider()
                        Text("游戏简介（占位符）").padding()
                        Divider()

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(0..<5, id: \.self) { _ in
                                    Image("placeholder")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxHeight: 200)
                                        .cornerRadius(12)
                                }
                            }
                        }
                        .padding()
                    }
                }
                .padding()
            }
        }
    }

    // MARK: 微信式图片查看器

    @ViewBuilder
    private var previewOverlay: some View {
        GeometryReader { geometry in
            ZStack {
                Color(nsColor: .underPageBackgroundColor)
                    .opacity(0.98)
                    .ignoresSafeArea()

                if #available(macOS 14.0, *) {
                    modernPagedGallery(size: geometry.size)
                } else {
                    fallbackPagedGallery(size: geometry.size)
                }

                galleryNavigationButtons
                    .zIndex(30)

                galleryCloseButton
                    .zIndex(31)

                galleryPageIndicator
                    .zIndex(31)

                // 图片放大以后，Mac 触控板两指滚动 = 移动当前图片。
                ZoomedImageTrackpadPanMonitor(
                    isEnabled: previewScale > 1.01,
                    onScroll: { dx, dy in
                        let proposed = CGSize(
                            width: previewPanOffset.width + dx,
                            height: previewPanOffset.height + dy
                        )
                        let clamped = clampPan(proposed, size: geometry.size)
                        previewPanOffset = clamped
                        previewPanBase = clamped
                    }
                )
                .frame(width: 1, height: 1)
                .allowsHitTesting(false)
                .zIndex(40)
            }
        }
    }

    @available(macOS 14.0, *)
    @ViewBuilder
    private func modernPagedGallery(size: CGSize) -> some View {
        ScrollView(.horizontal) {
            LazyHStack(spacing: 0) {
                ForEach(Array(detailPreviews.enumerated()), id: \.offset) { index, urlString in
                    galleryPage(
                        index: index,
                        urlString: urlString,
                        size: size
                    )
                    .frame(width: size.width, height: size.height)
                    .id(index)
                }
            }
            .scrollTargetLayout()
        }
        .scrollIndicators(.hidden)
        .scrollTargetBehavior(.paging)
        .scrollPosition(id: $selectedPreviewIndex)
        // 关键：图片一旦放大，彻底关闭分页滚动。
        .scrollDisabled(previewScale > 1.01)
    }

    @ViewBuilder
    private func fallbackPagedGallery(size: CGSize) -> some View {
        if let index = selectedPreviewIndex,
           detailPreviews.indices.contains(index) {
            galleryPage(
                index: index,
                urlString: detailPreviews[index],
                size: size
            )
            .frame(width: size.width, height: size.height)
        }
    }

    @ViewBuilder
    private func galleryPage(index: Int, urlString: String, size: CGSize) -> some View {
        ZStack {
            // 灰色空白区点击退出。
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture {
                    closePreview()
                }

            if let url = URL(string: urlString) {
                CachedAsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        galleryLoadedImage(
                            image,
                            pageIndex: index,
                            size: size
                        )

                    case .failure:
                        Image(systemName: "photo.badge.exclamationmark")
                            .font(.system(size: 38))
                            .foregroundColor(.secondary)

                    default:
                        // 无文字、无“高清图片”提示，只保留系统最小加载指示。
                        ProgressView()
                            .controlSize(.small)
                    }
                }
            } else {
                Image("placeholder")
                    .resizable()
                    .scaledToFit()
                    .frame(
                        width: max(240, size.width - 120),
                        height: max(240, size.height - 70)
                    )
            }
        }
    }

    @ViewBuilder
    private func galleryLoadedImage(_ image: Image, pageIndex: Int, size: CGSize) -> some View {
        let isCurrent = pageIndex == selectedPreviewIndex

        let baseImage = image
            .resizable()
            .scaledToFit()
            .frame(
                width: max(240, size.width - 120),
                height: max(240, size.height - 70)
            )
            .scaleEffect(
                isCurrent ? previewScale : 1,
                anchor: isCurrent ? previewZoomAnchor : .center
            )
            .offset(
                x: isCurrent ? previewPanOffset.width : 0,
                y: isCurrent ? previewPanOffset.height : 0
            )
            .shadow(
                color: .black.opacity(0.26),
                radius: 16,
                x: 0,
                y: 6
            )
            // 双击时拿到鼠标位置。
            // 鼠标在哪，previewZoomAnchor 就在哪。
            .highPriorityGesture(
                SpatialTapGesture(count: 2)
                    .onEnded { value in
                        guard isCurrent else { return }

                        if previewScale > 1.01 {
                            resetPreviewTransform(animated: true)
                        } else {
                            let imageWidth = max(240, size.width - 120)
                            let imageHeight = max(240, size.height - 70)

                            let normalizedX = min(
                                max(value.location.x / imageWidth, 0),
                                1
                            )
                            let normalizedY = min(
                                max(value.location.y / imageHeight, 0),
                                1
                            )

                            previewZoomAnchor = UnitPoint(
                                x: normalizedX,
                                y: normalizedY
                            )

                            previewPanOffset = .zero
                            previewPanBase = .zero

                            withAnimation(.spring(response: 0.28, dampingFraction: 0.86)) {
                                previewScale = 2
                                previewLastScale = 2
                            }
                        }
                    }
            )
            // 触控板捏合缩放。
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { value in
                        guard isCurrent else { return }

                        let proposed = previewLastScale * value
                        previewScale = min(max(proposed, 1), 4)

                        if previewScale <= 1.01 {
                            previewPanOffset = .zero
                            previewPanBase = .zero
                        } else {
                            let clamped = clampPan(
                                previewPanOffset,
                                size: size
                            )
                            previewPanOffset = clamped
                            previewPanBase = clamped
                        }
                    }
                    .onEnded { _ in
                        guard isCurrent else { return }

                        if previewScale < 1.06 {
                            resetPreviewTransform(animated: true)
                        } else {
                            previewLastScale = previewScale

                            let clamped = clampPan(
                                previewPanOffset,
                                size: size
                            )
                            previewPanOffset = clamped
                            previewPanBase = clamped
                        }
                    }
            )

        if isCurrent && previewScale > 1.01 {
            baseImage
                // 放大后鼠标拖动 = 移动当前图片。
                // 因为外层 ScrollView 已 scrollDisabled，所以不会再误翻下一页。
                .gesture(
                    DragGesture(minimumDistance: 1)
                        .onChanged { value in
                            let proposed = CGSize(
                                width: previewPanBase.width + value.translation.width,
                                height: previewPanBase.height + value.translation.height
                            )

                            previewPanOffset = clampPan(
                                proposed,
                                size: size
                            )
                        }
                        .onEnded { _ in
                            previewPanBase = previewPanOffset
                        }
                )
        } else {
            baseImage
        }
    }

    private var galleryNavigationButtons: some View {
        HStack {
            Button(action: previousPreview) {
                ZStack {
                    Circle()
                        .fill(Color.black.opacity(0.56))
                        .frame(width: 44, height: 44)

                    Image(systemName: "chevron.left")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .buttonStyle(.plain)
            .disabled((selectedPreviewIndex ?? 0) <= 0 || previewScale > 1.01)
            .opacity((selectedPreviewIndex ?? 0) <= 0 ? 0.28 : (previewScale > 1.01 ? 0.42 : 1))

            Spacer()

            Button(action: nextPreview) {
                ZStack {
                    Circle()
                        .fill(Color.black.opacity(0.56))
                        .frame(width: 44, height: 44)

                    Image(systemName: "chevron.right")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .buttonStyle(.plain)
            .disabled(
                (selectedPreviewIndex ?? 0) >= detailPreviews.count - 1 ||
                previewScale > 1.01
            )
            .opacity(
                (selectedPreviewIndex ?? 0) >= detailPreviews.count - 1
                ? 0.28
                : (previewScale > 1.01 ? 0.42 : 1)
            )
        }
        .padding(.horizontal, 18)
    }

    private var galleryCloseButton: some View {
        VStack {
            HStack {
                Spacer()

                Button(action: closePreview) {
                    ZStack {
                        Circle()
                            .fill(Color.black.opacity(0.60))
                            .frame(width: 38, height: 38)

                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
                .buttonStyle(.plain)
            }

            Spacer()
        }
        .padding(16)
    }

    private var galleryPageIndicator: some View {
        VStack {
            Spacer()

            if let index = selectedPreviewIndex {
                HStack(spacing: 8) {
                    Text("\(index + 1) / \(detailPreviews.count)")
                        .font(.caption.monospacedDigit())

                    if previewScale > 1.01 {
                        Text("\(Int(previewScale * 100))%")
                            .font(.caption.monospacedDigit())
                    }
                }
                .foregroundColor(.primary)
                .padding(.horizontal, 11)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .padding(.bottom, 12)
            }
        }
    }
}

// MARK: - 其他组件（已改为支持动态数据）

struct ResponsiveAppCard: View {

    var imageURL: String = ""

    var name: String = "应用名称"

    var subtitle: String = "免费，无内购"

    var onTap: () -> Void = {}

    var body: some View {

        ZStack(alignment: .bottomLeading) {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image

                            .resizable()

                            .scaledToFill()

                            .frame(height: 120)

                            .clipped()

                            .cornerRadius(10)

                    default:

                        Image("placeholder")

                            .resizable()

                            .scaledToFill()

                            .frame(height: 120)

                            .clipped()

                            .cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder")

                    .resizable()

                    .scaledToFill()

                    .frame(height: 120)

                    .clipped()

                    .cornerRadius(10)

            }

            LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.6)], startPoint: .top, endPoint: .bottom)

                .frame(height: 80)

                .cornerRadius(10)

            VStack(alignment: .leading) {

                Text(name)

                    .font(.headline)

                    .foregroundColor(.white)

                Text(subtitle)

                    .font(.caption)

                    .foregroundColor(.white.opacity(0.8))

            }

            .padding(8)

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct SmallAppItem: View {

    var imageURL: String = ""

    var name: String = "应用名称"

    var onTap: () -> Void = {}

    var body: some View {

        VStack {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFit().frame(height: 60).cornerRadius(10)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(height: 60).cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(height: 60).cornerRadius(10)

            }

            Text(name).font(.caption)

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct TweetItem: View {

    var imageURL: String = ""

    var title: String = "推文标题"

    var subtitle: String = "推文简介"

    var onTap: () -> Void = {}

    var body: some View {

        HStack {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(width: 120, height: 90).cornerRadius(10)

            }

            VStack(alignment: .leading) {

                Text(title).bold()

                Text(subtitle).font(.caption).foregroundColor(.secondary)

            }

            Spacer()

        }

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct CompactAppGridItem: View {

    var link: String = ""

    var name: String = "应用名称"

    var subtitle: String = "免费，无内购"

    var imageURL: String = ""

    var onTap: () -> Void = {}

    var body: some View {

        HStack(spacing: 8) {

            if let url = URL(string: imageURL) {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image.resizable().scaledToFill().frame(width: 40, height: 40).cornerRadius(8)

                    default:

                        Image("placeholder").resizable().scaledToFit().frame(width: 40, height: 40).cornerRadius(8)

                    }

                }

            } else {

                Image("placeholder").resizable().scaledToFit().frame(width: 40, height: 40).cornerRadius(8)

            }

            VStack(alignment: .leading) {

                Text(name).font(.headline)

                Text(subtitle).font(.caption).foregroundColor(.secondary)

            }

            Spacer(minLength: 4)

            Button("下载") {

                if let url = URL(string: link) {

                    NSWorkspace.shared.open(url)

                }

            }

            .buttonStyle(.borderedProminent)

            .controlSize(.small)

        }

        .padding(10)

        .background(Color.gray.opacity(0.05))

        .cornerRadius(12)

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

struct TopBannerCardView: View {

    var imageURL: String = ""

    var title: String = "精选大图"

    var onTap: () -> Void = {}

    var body: some View {

        ZStack(alignment: .bottomLeading) {

            if let url = URL(string: imageURL), !imageURL.isEmpty {

                CachedAsyncImage(url: url) { phase in

                    switch phase {

                    case .success(let image):

                        image

                            .resizable()

                            .scaledToFill()

                            .frame(width: 700, height: 300)

                            .clipped()

                    default:

                        Image("placeholder")

                            .resizable()

                            .scaledToFill()

                            .frame(width: 700, height: 300)

                            .clipped()

                    }

                }

            } else {

                Image("placeholder")

                    .resizable()

                    .scaledToFill()

                    .frame(width: 700, height: 300)

                    .clipped()

            }

            LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.6)], startPoint: .top, endPoint: .bottom)

            Text(title)

                .font(.title)

                .bold()

                .foregroundColor(.white)

                .padding()

        }

        .frame(width: 700, height: 300)

        .cornerRadius(12)

        .contentShape(Rectangle())

        .onTapGesture { onTap() }

    }

}

// MARK: - 帮助视图

struct HelpView: View {

    @Environment(\.dismiss) private var dismiss

    var body: some View {

        VStack(alignment: .leading) {

            Text("帮助中心").font(.title2).bold().padding()

            Divider()

            ScrollView {

                Text("""

                📖 【关于此启动器】

                当前版本: 9.1.5

                本启动器适用于在 macOS 上运行植物大战僵尸的大多数版本。

                感谢/致谢:

                烂矮炮工作室(Lan Apple Studio)：主开发者

                AI:Deepseek(deepseek.com):最终V6,V7,V8,V9的开发辅助、豆包(doula.com/doubao.com)：前期V1,V2的开发辅助、ChatGPT(chatgpt.com):V3,V4,V5,V9.1.1~5的开发辅助

                实用帮助:

                启动时退出且退出码为53通常由Bottle前缀损坏或下载/解压的引擎包不完整导致:请您使用设置里的清空bottle按钮或重置全部数据（保存好您的存档）

                游侠汉化V2及基于此版本的改版的"竖杠/方块"字体问题:V2完全绕过Windows标准GDI，直接调用DirectDraw读取自定义的font.bin和font.dds。在M4芯片上，Wine内部计算Pitch（行跨度）与原生Windows有微小差异，且无法加载第三方dxwrapper/ddraw.dll补丁。结论：无解，只能直接放弃V2，使用V1汉化版或基于V1标准字体的魔改版。

                若你的改版是安装器exe:在Mac上使用第三方解压工具解压或导入游戏后再安装到桌面及其他地方（不要用默认路径,除非你找得到）

                日志太多导致游戏卡死或掉帧:请您关掉设置中的调试日志开关。

                Bug列表:

                      🔴严重/无法修复(属于目前无法解决):

                        1.游侠汉化V2的"竖杠/方块"字体问题:V2完全绕过Windows标准GDI，直接调用DirectDraw读取自定义的font.bin和font.dds。在M4芯片上，Wine内部计算Pitch（行跨度）与原生Windows有微小差异，且无法加载第三方dxwrapper/ddraw.dll补丁。结论：无解，只能直接放弃V2，使用V1汉化版或基于V1标准字体的魔改版。

                        2.退出码:53（Kernel32.dll加载失败）：高频触发，通常由Bottle前缀损坏或下载/解压的引擎包不完整导致。目前无自动修复，只能进设置"清空全局Bottle"并重新手动安装引擎包请提前备份好您的存档。

                        3.特定引擎的"后台失焦冻结"（切后台超过2秒，连音乐都停止）：这是特定Wine引擎的硬伤，Caffeinate和强制OpenGL只能缓解，无法根治。

                      🟡 中等/不稳定（容易引发严重Bug，需谨慎操作或未解决）

                        4.在线下载引擎不稳定：Beta版本链接经常下载失败或解压不完整，残留的损坏文件正是触发"退出码53"的元凶。强烈建议用户使用"手动选择安装包"，不要频繁使用在线下载,最好用的安装包地址:https://github.com/frankea/Whisky/releases/download/v4.5.105-beta.1/Libraries.tar.gz

                      5.存档丢失风险：清空全局Bottle或重置全部数据会直接删除用户存档，做了"导出/导入存档"的功能。

                      6.修改器多开偶发冲突：虽然加了复制修改器到独立Bottle的逻辑，但部分老修改器依赖窗口句柄检测，在多开复制模式下偶尔找不到游戏或导致轻微掉帧，这种属于修改器自身底层逻辑限制。

                      🟢 已解决/轻微（已优化或正常）

                       7.界面按钮命名不清晰（已解决）：管理页的"打开"和"打开位置"全部改成了"在访达中显示"。

                       8.修改器列表倒序（已解决）：去掉了 reversed()，现在从上往下正常排列。

                      9.游戏与修改器共用容器冲突（已解决）：V7加入了修改器自动复制到独立 Bottle 的逻辑，支持多开防冲突。

                       10.日志刷屏导致 UI 卡死（已解决）：加入了日志过滤、防爆内存截断，以及停止按钮的双重保障（优雅终止 + Killall -9）。

                       11.停止按钮没反应/卡死停不下来:和上一报告bug使用同一解决方式

                       12.丢失"新游戏默认独立Bottle"开关（已解决）：在设置界面成功找回并恢复了。

                       13.设置界面窗口限制（已解决）：整个设置页面已改为整体可滚动滑动，日志区域也正常恢复了（短消息居中，长日志自动靠左）。

                       14.按钮排版（已优化）：关于启动器的前三行按钮（关于、GitHub、反馈）已调整为同一行居中，帮助按钮单独放在下一行触发新窗口。

                       15.日志卡死/掉帧（已解决）：加入了精准的关键日志过滤和0.15秒节流，开启调试日志不再直接卡死。

                👋🙏 免责声明：

                本软件仅供学习交流使用，如遇到无法解决的难题，请前往设置界面点击反馈bug按钮反馈bug。

                @B站一个闲的没事的糯米   个人界面:https://space.bilibili.com/3546728525466305?spm_id_from=333.1007.0.0

                """)

                .padding()

                .textSelection(.enabled)

            }

            Divider()

            HStack {

                Spacer()

                Button("关闭") { dismiss() }.buttonStyle(.borderedProminent).padding()

            }

        }

        .frame(minWidth: 500, minHeight: 450)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

    }

}

// MARK: - 全部应用列表

struct AllAppsListView: View {

    @Environment(\.dismiss) private var dismiss

    @StateObject private var library = RemoteGameLibrary()

    @State private var selectedGame: GameItem?  // ✅ 新增，用于弹详情

    var body: some View {

        VStack(spacing: 0) {

            HStack {

                Text("查看全部").font(.title2).bold()

                Spacer()

                Button("关闭") { dismiss() }.buttonStyle(.borderedProminent)

            }

            .padding()

            Divider()

            ScrollView {

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), spacing: 20)], spacing: 20) {

                    ForEach(library.items) { item in

                        CompactAppGridItem(

                            link: item.link,

                            name: item.name,

                            subtitle: item.subtitle,

                            imageURL: item.icon ?? "",

                            onTap: {

                                selectedGame = item  // ✅ 点击后弹出详情

                            }

                        )

                    }

                }

                .padding()

            }

        }

        .frame(minWidth: 800, minHeight: 600)

        .frame(maxWidth: .infinity, maxHeight: .infinity)

        .background(Color(nsColor: .windowBackgroundColor))

        .sheet(item: $selectedGame) { game in

            AppDetailView(game: game)

        }

        .onAppear {

            library.load(manualRefresh: false)

        }

    }

}

// MARK: - 远程游戏库模型

struct GameItem: Codable, Identifiable {

    let id: Int

    let name: String

    let subtitle: String

    let subtitle2: String?

    let subtitle3: String?

    let subtitle4: String?

    let subtitle5: String?

    let subtitle6: String?

    let subtitle7: String?

    let subtitle8: String?

    let subtitle9: String?  // 推文标题

    let subtitle10: String? // 推文简介

    let link: String

    let icon: String?

    let previews: [String]?

}

class RemoteGameLibrary: ObservableObject {

    @Published var items: [GameItem] = []

    @Published var isLoading: Bool = false

    @Published var errorMessage: String?

    private let rawURL = URL(string: "https://raw.githubusercontent.com/nuomi4/YesPVZlauncher/main/games.json")!

    private let cacheFileName = "games_library_cache.json"

    private let cacheLifetime: TimeInterval = 10 * 60 // 10分钟缓存


    private func prefetchIcons(for items: [GameItem]) {
        let urls = items.compactMap { item -> URL? in
            guard let icon = item.icon else { return nil }
            return URL(string: icon)
        }
        RemoteImagePipeline.shared.prefetch(urls)
    }

    private func cacheFilePath() -> URL {

        let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!

        let folder = appSupport.appendingPathComponent("YesPVZLauncher", isDirectory:true)

        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        return folder.appendingPathComponent(cacheFileName)

    }

    private struct LibraryCache: Codable {

        let timestamp: TimeInterval

        let jsonData: Data

    }

    private func loadDiskCache() -> [GameItem]? {

        let path = cacheFilePath()

        guard FileManager.default.fileExists(atPath: path.path) else { return nil }

        do {

            let data = try Data(contentsOf: path)

            let model = try JSONDecoder().decode(LibraryCache.self, from: data)

            let now = Date().timeIntervalSince1970

            if now - model.timestamp < cacheLifetime {

                let decoded = try JSONDecoder().decode([String:[GameItem]].self, from: model.jsonData)

                return decoded["games"]

            }

        } catch {

            print("读取本地缓存失败:\(error)")

        }

        return nil

    }

    private func saveDiskCache(data:Data) {

        let model = LibraryCache(timestamp: Date().timeIntervalSince1970, jsonData: data)

        do {

            let encoded = try JSONEncoder().encode(model)

            try encoded.write(to: cacheFilePath())

        } catch {

            print("写入缓存失败:\(error)")

        }

    }

    func load(manualRefresh:Bool = false) {

        if !manualRefresh, let cache = loadDiskCache() {

            DispatchQueue.main.async {

                self.items = cache
                self.prefetchIcons(for: cache)

            }

        }

        DispatchQueue.main.async {

            self.isLoading = true

            self.errorMessage = nil

        }

        var req = URLRequest(url: rawURL)

        req.timeoutInterval = 8.0

        req.setValue("YesPVZLauncher", forHTTPHeaderField: "User‑Agent")

        let task = URLSession.shared.dataTask(with: req) { [weak self] data, resp, error in

            guard let self = self else { return }

            DispatchQueue.main.async {

                self.isLoading = false

            }

            if let err = error {

                DispatchQueue.main.async {

                    if (err as NSError).code == NSURLErrorTimedOut {

                        self.errorMessage = "网络超时，GitHub访问延迟"

                    } else {

                        self.errorMessage = "加载失败：\(err.localizedDescription)"

                    }

                }

                return

            }

            guard let receivedData = data else {

                DispatchQueue.main.async {

                    self.errorMessage = "没有收到数据"

                }

                return

            }

            do {

                let decoded = try JSONDecoder().decode([String: [GameItem]].self, from: receivedData)

                guard let list = decoded["games"] else {

                    DispatchQueue.main.async {

                        self.errorMessage = "json解析异常"

                    }

                    return

                }

                self.saveDiskCache(data: receivedData)

                DispatchQueue.main.async {

                    self.items = list
                    self.prefetchIcons(for: list)

                }

            } catch {

                DispatchQueue.main.async {

                    self.errorMessage = "解析JSON出错:\(error.localizedDescription)"

                }

            }

        }

        task.resume()

    }

}

#Preview { ContentView() }

