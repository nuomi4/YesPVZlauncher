//
//  YesPVZLauncherApp.swift
//  YesPVZLauncher
//
//  Created by nuomi on 2026/8/20.
//

import SwiftUI

@main
struct YesPVZLauncherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
